#!/bin/bash
# q23: re-measure the last two pre-release feeds on 26.8.1, at N=5 or better.
#
# WHY. A recursive version sweep found two artifacts still feeding live paper
# claims from a pre-release engine, after an earlier top-level sweep had missed
# them:
#   e4decomp  26.8.1.dev24, hidden inside `meta` where the auditor did not look.
#             Feeds the E4 protocol/boundary split quoted as "86--99.8%".
#   tentag    no version at all. It was scraped out of queue36.log because the
#             probe wrote no JSON, so its engine is unrecoverable even in
#             principle. Feeds the ten-tag ingest-cost and last-point claims.
# DECISIONS #42 says every ICDE number comes from a stable release, so both are
# re-measured here rather than re-labelled.
#
# tentag ALSO MOVES N=3 -> N=5. The original ran three reps; five is the
# standard for every other published cell and there is no reason this one is
# the exception.
#
# NO KNOWN-GOOD SCRIPT TO COPY. Neither probe's original launch survives in any
# queue script on this host, so these invocations are RECONSTRUCTED from the
# probes' own CLI rather than copied from an arm that worked. That is the exact
# situation the "verify the arm, not the file" rule warns about, and it cannot
# be avoided here -- so the acceptance checks below are stricter than usual:
# every output must exist, carry a release version, and hold the rep count it
# claims, or the run reports itself unusable.
set -u
OUT=$HOME/q23
mkdir -p "$OUT"
LOG=$OUT/queue.log
EXP=$HOME/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
IMG=dbbench:arcadedb

log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
die() { log "ABORT: $*"; exit 1; }

log "q23 started, pid $$"
cd "$EXP" || die "no experiments dir"

# ---- wait for q22, with a hard deadline -------------------------------------
# 20h: q22's own timeout is 24h but it is expected to finish in ~16h. If this
# deadline is reached, q22 is stuck and q23 should not silently wait forever.
DEADLINE=$(( $(date +%s) + 20*3600 ))
while ! grep -q "Q22-COMPLETE" "$HOME/q22/queue.log" 2>/dev/null; do
  [ "$(date +%s)" -ge "$DEADLINE" ] && die "q22 never completed in 20h"
  sleep 120
done
log "q22 complete"
while [ "$(docker ps -q | wc -l)" -gt 0 ]; do
  [ "$(date +%s)" -ge "$DEADLINE" ] && die "containers still running at deadline"
  sleep 30
done
log "host idle"

VER=$(docker run --rm "$IMG" python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
case "${VER:-}" in
  "")     die "no engine version from $IMG" ;;
  *.dev*) die "F5: $IMG is $VER, a pre-release; that is what this run exists to escape" ;;
esac
log "gate: $IMG is $VER"

# ---- E4 decomposition -------------------------------------------------------
# Two of its three arms (embedded, in-process HTTP over loopback) live inside
# one container; the third needs a separate arcadedb server holding the same
# corpus. Run the two-arm form, which is the one the paper's claim rests on:
# the protocol/boundary split is embedded vs in-process HTTP, and the
# containerised arm only sets the outer bound.
mkdir -p "$EXP/results/e4decomp_2681"
log "START e4 decomposition, REPS=15"
timeout 7200 docker run --rm --name q23_e4decomp \
  --cpuset-cpus 0-11 --memory 12g --memory-swap 12g \
  -v "$EXP:/work" -w /work \
  -e REPS=15 -e ARCADEDB_HEAP=6g -e BENCH_ROLE=engine \
  -e OUT=/work/results/e4decomp_2681/decomp_2681.json \
  "$IMG" python -u deployment_decomp_probe.py --heap 6g \
  >"$OUT/e4decomp.log" 2>&1 \
  && log "  e4decomp ok" || log "  e4decomp FAILED (see e4decomp.log)"

# ---- ten-tag A/B, N=5 -------------------------------------------------------
# The claim is the WITHIN-PROBE ratio between a 1-tag and a 10-tag series key,
# so both arms must come from the same engine, same corpus, same protocol.
mkdir -p "$EXP/results/tentag_2681"
LP=$HOME/bench-data/tsbs/cpu_influx.lp
[ -s "$LP" ] || die "no TSBS corpus at $LP"
for tags in 1 10; do
  for rep in 1 2 3 4 5; do
    while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 15; done
    timeout 3600 docker run --rm --name q23_tentag_t${tags}_r${rep} \
      --cpuset-cpus 0-11 --memory 20g --memory-swap 20g \
      -v "$EXP:/work" -w /work -v "$HOME/bench-data:/data:ro" \
      -e TSBS_LP=/data/tsbs/cpu_influx.lp \
      -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=$tags \
      -e TS_SETTLE_S=0 -e TS_LAST_AB=1 \
      -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
      -e PROBE_OUT="/work/results/tentag_2681/tags${tags}_r${rep}.json" \
      "$IMG" python -u l4_native_probe.py >"$OUT/tentag_t${tags}_r${rep}.log" 2>&1 \
      && log "  tentag tags=$tags rep$rep ok" || log "  tentag tags=$tags rep$rep FAILED"
  done
done

# ---- acceptance -------------------------------------------------------------
log "=== acceptance ==="
python3 - >>"$LOG" 2>&1 <<'PY'
import json, glob, os, re, statistics as st
EXP = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments")

def versions(o, out=None):
    out = set() if out is None else out
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, str) and re.search(r"\d+\.\d+\.\d+", v) and \
               any(t in k.lower() for t in ("version", "wheel", "engine", "lib")):
                out.add(v)
            versions(v, out)
    elif isinstance(o, list):
        for v in o: versions(v, out)
    return out

ok = True
f = os.path.join(EXP, "results", "e4decomp_2681", "decomp_2681.json")
if not os.path.exists(f):
    print("  e4decomp: NO OUTPUT. The E4 split stays on the pre-release; do not report it."); ok = False
else:
    d = json.load(open(f)); v = sorted(versions(d))
    print("  e4decomp: versions %s, arms %s" % (v, sorted(d.get("results", {}))))
    if any(".dev" in x for x in v):
        print("    REJECT: still pre-release."); ok = False

for tags in (1, 10):
    fs = sorted(glob.glob(os.path.join(EXP, "results", "tentag_2681", "tags%d_r*.json" % tags)))
    if len(fs) < 5:
        print("  tentag tags=%d: only %d/5 reps" % (tags, len(fs))); ok = False; continue
    rows = [json.load(open(x)) for x in fs]
    v = sorted({str(r.get("engine_version")) for r in rows})
    ing = [r["ingest_pts_per_s"] for r in rows if isinstance(r.get("ingest_pts_per_s"), (int, float))]
    print("  tentag tags=%d: %d reps, versions %s, ingest median %.6g" % (tags, len(rows), v, st.median(ing) if ing else 0))
    if any(".dev" in x for x in v):
        print("    REJECT: still pre-release."); ok = False
print("  ACCEPTED" if ok else "  NOT USABLE AS MEASURED")
PY

log "Q23-COMPLETE"
