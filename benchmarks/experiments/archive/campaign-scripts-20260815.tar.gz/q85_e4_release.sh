#!/usr/bin/env bash
# q85: re-run E4's protocol/boundary decomposition on the RELEASE (26.8.1).
#
# WHY. The decomposition exists (mini:~/e4decomp) and is the basis for #127,
# but all four of its artifacts carry engine_version 26.8.1.dev24. Folding a
# dev number into the paper is exactly the defect we spent today removing from
# the sparse profile, so the fold waits for release data rather than adding a
# second exception clause.
#
# Chains behind q84 (the sparse re-profile) so the two never share the machine:
# every published number is measured serially on the full cpuset.
set -u
S=$HOME/STATUS.txt
cd ~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments

# Wait for q84 rather than assume it finished.
for i in $(seq 1 480); do
  grep -qa "q84 ALL-DONE" "$S" 2>/dev/null && break
  grep -qa "q84 ABORT\|q84 container DIED\|q84 never reached" "$S" 2>/dev/null && {
    echo "[$(date -Is)] q85 not starting: q84 did not finish cleanly" >> "$S"; exit 1; }
  sleep 30
done
grep -qa "q84 ALL-DONE" "$S" || { echo "[$(date -Is)] q85 gave up waiting for q84" >> "$S"; exit 1; }

ver=$(docker run --rm --entrypoint python dbbench:arcadedb -c \
      'import importlib.metadata as m; print(m.version("arcadedb-embedded"))' 2>/dev/null | tr -d '\r')
if [ "$ver" != "26.8.1" ]; then
  echo "[$(date -Is)] q85 ABORT: image reports '$ver', expected 26.8.1" >> "$S"; exit 1
fi
echo "[$(date -Is)] q85 E4 decomposition START on $ver" >> "$S"

mkdir -p ~/e4decomp_release
OUT=~/e4decomp_release/decomp_full_26.8.1.json
REPS=15 WARMUP=5 ROWS=200000 OUT="$OUT" \
  python3 -u deployment_decomp_probe.py >> ~/q85.log 2>&1
rc=$?
echo "[$(date -Is)] q85 rc=$rc out=$OUT" >> "$S"
[ "$rc" -eq 0 ] && echo "[$(date -Is)] q85 ALL-DONE" >> "$S"
echo "currently: finished" >> "$S"
