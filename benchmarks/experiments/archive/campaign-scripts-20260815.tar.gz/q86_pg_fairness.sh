#!/usr/bin/env bash
# q86: does PostgreSQL's default buffer pool cost it latency in our tabular lanes?
#
# WHY. We set ArcadeDB's heap per scale tier (16g at medium) and left
# PostgreSQL at the image's defaults: 128 MB shared_buffers, 4 MB work_mem.
# Those are start-anywhere numbers, not deploy numbers. Our fairness policy
# says to equalize a default that makes a comparison apples-to-oranges, and
# nobody had checked whether this one does.
#
# NOT a memory fix. Verified on the laptop first: a container given
# shared_buffers=2GB still reports 5 MiB anon, because the pool is POSIX
# shared memory that cgroup v2 files under shmem. The memory column cannot see
# it at any setting. This job answers the LATENCY half only.
#
# DURABILITY UNTOUCHED. fsync and synchronous_commit stay on in both arms.
# The tables disclose that PostgreSQL fsyncs per commit while ArcadeDB groups
# commits, and an arm that relaxed that would be answering a different
# question under this one's name.
#
# BOTH ARMS RE-RUN, including the default one that already has data. An A/B
# whose control was measured weeks earlier is not an A/B; the two arms need to
# be interleaved in one shuffled batch on one machine state. The re-measured
# default arm also serves as a reproducibility check against the existing
# campaign rows. ArcadeDB and DuckDB are unchanged and are not re-run.
set -u
S=$HOME/STATUS.txt
R=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$R" || exit 1
say() { echo "[$(date -Is)] $*" >> "$S"; }

# --- preflight: nobody else on the machine
if [ -n "$(docker ps -q --filter label=dbbench=1)" ]; then
  say "q86 ABORT: dbbench containers already running"; exit 1
fi
grep -q postgres_tuned runner.py || { say "q86 ABORT: checkout has no postgres_tuned arm"; exit 1; }

# --- back up what this job will overwrite.
# raw/ filenames carry lane_backend_workload_rep and NOT scale, so a re-run at
# any scale lands on the same file. runs.jsonl is append-only and the canonical
# rule takes the latest matching row, so the existing postgres cells are about
# to be superseded. Both are recoverable only if copied first. A campaign has
# already been lost on this machine to a command that assumed otherwise.
BK=~/q86-preserve-$(date +%Y%m%dT%H%M%SZ)
mkdir -p "$BK/raw"
cp results/runs.jsonl "$BK/runs.jsonl" 2>/dev/null
cp results/raw/l1_postgres_*.json results/raw/l1tpc_postgres_*.json "$BK/raw/" 2>/dev/null
say "q86 preserved $(ls "$BK/raw" | wc -l) raw rows + runs.jsonl in $BK"

say "q86 START pg buffer-pool fairness A/B"

# --- stage 1: one smoke cell per arm.
# Small scale for speed, and rep 9 so the file names cannot collide with the
# campaign's r1..r5. PAPER_SCALES admits only `medium` for l1, so a small row
# cannot reach a table even though it is appended to runs.jsonl.
#
# The point is not the number. It is that the tuned container comes up under
# the real ready_regex, that the row records what it was launched with, and
# that the new shmem fields are populated. A full run that turns out to have
# written nulls for eight hours is what this stage exists to prevent.
say "q86 smoke: l1 small, rep 9, both pg arms"
python3 -u runner.py --lanes l1 --backends postgres,postgres_tuned \
  --scale small --reps 9 --only-reps 9 --workloads oltp >> ~/q86.log 2>&1
rc=$?
say "q86 smoke rc=$rc"
[ "$rc" -eq 0 ] || { say "q86 ABORT: smoke failed"; echo "currently: q86 aborted" >> "$S"; exit 1; }

python3 - >> ~/q86.log 2>&1 <<'PYEOF'
import json, os, sys
# READ runs.jsonl, NOT raw/. raw/*.json is what the lane script wrote from
# INSIDE the container, so it carries latencies and no memory at all: the
# cgroup sampling happens on the host side, in the runner, and lands only
# here. The first version of this check read raw/ and reported every memory
# field null for two cells that had measured them fine.
p = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/"
                       "benchmarks/experiments/results/runs.jsonl")
rows = [json.loads(l) for l in open(p) if l.strip()]
smoke = [r for r in rows if r.get("lane") == "l1" and r.get("scale") == "small"
         and r.get("rep") == 9 and str(r.get("backend", "")).startswith("postgres")]
by = {}
for r in smoke:
    by[r["backend"]] = r          # last wins
bad = []
for be in ("postgres", "postgres_tuned"):
    r = by.get(be)
    if r is None:
        bad.append(be + ": no rep-9 small row in runs.jsonl")
        continue
    if r.get("rc") != 0 or r.get("error"):
        bad.append("%s: rc=%s error=%s" % (be, r.get("rc"), r.get("error")))
    for f in ("peak_shmem_mib_sum", "peak_owned_mib_sum", "server_peak_shmem_mib"):
        if r.get(f) is None:
            bad.append("%s: %s is null (instrument did not land)" % (be, f))
    print(be)
    print("   read_p50=%s ops/s=%s" % (r.get("read_p50_ms"), r.get("oltp_ops_per_s")))
    print("   anon=%s shmem=%s owned=%s total=%s" % (
        r.get("peak_anon_mib_sum"), r.get("peak_shmem_mib_sum"),
        r.get("peak_owned_mib_sum"), r.get("peak_mib_sum")))
    print("   srv anon=%s shmem=%s file=%s" % (
        r.get("server_peak_anon_mib"), r.get("server_peak_shmem_mib"),
        r.get("server_peak_file_mib")))
    print("   cmd=%s" % r.get("server_cmd"))
t = by.get("postgres_tuned") or {}
cmd = t.get("server_cmd") or ""
if "shared_buffers=3GB" not in cmd:   # small tier: 16g cap -> 12g server -> a quarter
    bad.append("tuned arm: expected shared_buffers=3GB at this tier, got %r" % cmd)
# The whole point of the arm is that the pool actually grew. If shmem does not
# separate the two arms then the flags reached the container and changed
# nothing, and there is no A/B here to run.
d, u = by.get("postgres") or {}, by.get("postgres_tuned") or {}
if d.get("server_peak_shmem_mib") and u.get("server_peak_shmem_mib"):
    if u["server_peak_shmem_mib"] <= d["server_peak_shmem_mib"]:
        bad.append("tuned shmem %s is not above default %s: the pool did not grow"
                   % (u["server_peak_shmem_mib"], d["server_peak_shmem_mib"]))
if bad:
    print("SMOKE-BAD")
    for b in bad:
        print("   ", b)
    sys.exit(1)
print("SMOKE-OK")
PYEOF
if [ $? -ne 0 ]; then
  say "q86 ABORT: smoke rows failed their check (see ~/q86.log)"
  echo "currently: q86 aborted" >> "$S"; exit 1
fi
say "q86 smoke rows OK"

# --- stage 2: the real A/B, both lanes, N=5, both workloads, serial full cpuset
say "q86 l1 medium N=5 START"
python3 -u runner.py --lanes l1 --backends postgres,postgres_tuned \
  --scale medium --reps 5 >> ~/q86.log 2>&1
say "q86 l1 medium rc=$?"

say "q86 l1tpc tpch1 N=5 START"
python3 -u runner.py --lanes l1tpc --backends postgres,postgres_tuned \
  --scale tpch1 --reps 5 >> ~/q86.log 2>&1
say "q86 l1tpc tpch1 rc=$?"

say "q86 ALL-DONE"
echo "currently: finished" >> "$S"
