#!/usr/bin/env bash
set -u
pgrep -x ffmpeg >/dev/null && { echo "SHOW-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "SHOW-ABORT foreign-container"; exit 1; }
cd /home/tk/repos/scipy-bench-repo
git fetch -q origin arcadedb-2026 && git checkout -q origin/arcadedb-2026 -- experiments/ || { echo "SHOW-ABORT pull"; exit 1; }
cd experiments
echo "=== SHOWCASE-BIDI solo $(date -u +%FT%TZ) ==="
docker run --rm --cpuset-cpus 0-7 --memory 8g \
  -v /home/tk/repos/scipy-bench-repo/experiments:/work -w /work \
  -v /home/tk/scipy-bench/data:/data:ro scipy-bench:arcadedb \
  python -u hybrid_showcase.py --data-dir /data/stackoverflow-medium/prepared \
  --vectors-dir /data/stackoverflow-medium/vectors --name stackoverflow-medium --limit 250000 \
  > results/hybrid_bidi_solo.log 2>&1
echo "showcase rc=$?"
echo "SHOWCASE-BIDI-COMPLETE"
