#!/bin/bash
# queue67: the GAV far-endpoint property finding, at the published scale, on mini.
#
# CONFIRMED ALREADY on the laptop at micro (2k persons), dev24:
#   src_prop_only  5.93x     property read from the SOURCE, target anonymous
#   dst_prop_only  3.34x     the SAME single property, read from the TARGET
# and the two published far-endpoint queries reproduced within 0.1x
# (same_city_edges 2.57 vs 2.46, friend_age_by_city 2.46 vs 2.41).
#
# Micro is 2,000 persons. The published OLAP cells are `small` (100k persons,
# ~2M edges): gav_off 381 / 1272 / 1257 ms. This run repeats the probe there,
# so the number that goes upstream is measured at the scale the claim is about,
# on the controlled host, rather than extrapolated from a laptop.
#
# PHASE 2 attaches async-profiler to the GAV-ON arm while it runs
# dst_prop_only in a loop. The source-level claim is that per-row property
# access goes ColumnStore.getValue -> columns.get(String) (a HashMap lookup)
# plus boxing, once per edge, while GraphAnalyticalView.getBucketColumnStore
# ("direct vectorized access") has zero callers. If that is where the time
# goes, those frames are hot. If they are not hot, the source reading is a
# plausible story that the profile does not support, and the issue does not
# get filed on it.
#
# CHAINED behind queue66 with a HARD DEADLINE, per the rule that cost two
# watchers six days: a marker wait with no deadline is not a wait, it is a hang.
set -u
OUT=$HOME/q67
PROF=$HOME/profiling/flame
mkdir -p "$OUT" "$PROF"
say(){ echo "[$(date +%T)] $*"; }

say "queue67 waiting for QUEUE66-DONE (hard deadline 8h)"
for i in $(seq 1 480); do
  grep -qa "QUEUE66-DONE" ~/queue66.log 2>/dev/null && { say "q66 finished"; break; }
  # q66 exits without the marker on its own deadline/guard paths; do not wait
  # for a marker that is never coming.
  if grep -qa "DEADLINE:\|GUARD:\|NEVER-REACHED\|DIED before" ~/queue66.log 2>/dev/null; then
    say "q66 exited on an error path; proceeding anyway once mini is idle"
    break
  fi
  if [ "$i" -eq 480 ]; then
    say "DEADLINE: q66 did not finish in 8h; NOT starting"
    exit 1
  fi
  sleep 60
done

n=$(docker ps -q | wc -l)
[ "$n" -eq 0 ] || { say "GUARD: $n container(s) still running, refusing to co-run"; exit 1; }

# Run from an ISOLATED staging dir, not the checkout. Mini's icde checkout is
# 625 commits behind with 594 dirty files (task #98), and a git operation over
# a live campaign has already cost us tracked result rows once. The probe and
# its two stdlib-only deps are copied in whole, so nothing here depends on the
# checkout's state and nothing here can disturb it.
cd ~/q67work || { say "no ~/q67work staging dir"; exit 1; }
for f in gav_property_probe.py graph_common.py bench_common.py; do
  [ -f "$f" ] || { say "$f not staged in ~/q67work"; exit 1; }
done

# ---------------------------------------------------------------- phase 1
# The published scale. Both arms are built before either is timed and the
# queries are interleaved round-robin, so neither arm can inherit the other's
# warmed JVM (the E4 arm-ordering bias, worth 30pp there).
say "phase 1: gav_property_probe at scale=small (100k persons, ~2M edges), N=5"
say "  build is per-row SQL on both arms; allow ~1-2h"
docker rm -f gav67 >/dev/null 2>&1
timeout 21600 docker run --rm --name gav67 \
  --cpuset-cpus 0-11 --memory 16g --memory-swap 16g \
  -v "$PWD:/work" -w /work \
  -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
  -e PROBE_OUT=/work/q67_gav_small.json \
  icde-bench:arcadedb-srv python -u gav_property_probe.py \
    --scale small --reps 5 --warmup 2 2>&1 | tee "$OUT/phase1.log"

if [ -s ~/q67work/q67_gav_small.json ]; then
  cp ~/q67work/q67_gav_small.json "$OUT/"
  say "phase 1 result copied to $OUT"
else
  say "phase 1 produced NO result file; not proceeding to the profile"
  exit 1
fi

# ---------------------------------------------------------------- phase 2
# Profile the GAV-ON arm running the far-endpoint query. PROBE_PROFILE makes
# the probe build only that arm, hold it, and loop dst_prop_only while the
# profiler is attached.
say "phase 2: profiling the GAV-ON arm on dst_prop_only"
docker rm -f gavprof67 >/dev/null 2>&1
docker run -d --name gavprof67 \
  --cpuset-cpus 0-11 --memory 16g --memory-swap 16g \
  -v "$PWD:/work" -w /work \
  -v "$HOME/profiling/async-profiler-4.0-linux-x64:/prof:ro" -v "$PROF:/pout" \
  -e ARCADEDB_HEAP=8g -e PROBE_PROFILE=dst_prop_only \
  icde-bench:arcadedb-srv python -u gav_property_probe.py \
    --scale small --reps 200 --warmup 2 >/dev/null 2>&1

found=0
for i in $(seq 1 480); do
  docker logs gavprof67 2>&1 | grep -qa "PROFILE-PHASE-START" && { found=1; break; }
  docker ps -q -f name=gavprof67 | grep -q . || {
    say "gavprof67 DIED before the profile phase"; docker logs gavprof67 2>&1 | tail -8; exit 1; }
  sleep 15
done
[ "$found" -eq 1 ] || {
  say "gavprof67 never reached the profile phase in 2h"
  docker logs gavprof67 2>&1 | tail -8; docker rm -f gavprof67 >/dev/null 2>&1; exit 1; }

sleep 5
docker exec gavprof67 /prof/bin/asprof start -e cpu 1 && say "profiling"
sleep 180
docker exec gavprof67 /prof/bin/asprof stop -o collapsed -f /pout/gav67_dst_prop.collapsed 1 \
  && say "collapsed written"
docker rm -f gavprof67 >/dev/null 2>&1

say "=== phase 2: where does far-endpoint property access spend its time? ==="
python3 - <<'PY'
import collections, os
p = os.path.expanduser("~/profiling/flame/gav67_dst_prop.collapsed")
if not os.path.exists(p) or os.path.getsize(p) == 0:
    print("  NO COLLAPSED FILE. Do not report a number."); raise SystemExit
tot = 0
self_ = collections.Counter()
stacks = []
for line in open(p):
    parts = line.rsplit(" ", 1)
    if len(parts) != 2: continue
    stack, n = parts[0], int(parts[1])
    tot += n
    self_[stack.split(";")[-1]] += n
    stacks.append((stack, n))
print(f"  total samples: {tot:,}")
for frame, n in self_.most_common(16):
    print(f"  {100.0*n/tot:6.2f}%  {frame[:76]}")

# The specific claim: per-row property access through the string-keyed column
# map. Sum anywhere in the stack, not just self, since the cost is spread over
# HashMap.get, the boxing, and the getValue frame itself.
def anywhere(*needles):
    return sum(n for s, n in stacks if any(x in s for x in needles))
print()
for label, needles in [
    ("ColumnStore.getValue",        ("ColumnStore.getValue",)),
    ("GraphAnalyticalView.getProperty", ("GraphAnalyticalView.getProperty",)),
    ("GAVVertex property access",   ("GAVVertex.get", "GAVVertex.has")),
    ("HashMap.get under getValue",  ("ColumnStore.getValue;java.util.HashMap.get",)),
    ("boxing (valueOf)",            ("Integer.valueOf", "Long.valueOf", "Double.valueOf")),
    ("record load fallback",        ("GAVVertex.resolve", "lookupByRID")),
    ("getBucketColumnStore",        ("getBucketColumnStore",)),
]:
    print(f"  {label:<34}{100.0*anywhere(*needles)/tot:6.2f}%")
print()
print("  The source claim is that property access is per-row through a")
print("  string-keyed HashMap plus boxing, and that the vectorized API")
print("  (getBucketColumnStore) is never called. A near-zero for the first")
print("  group would REFUTE that and the issue does not get filed on it.")
PY
say "QUEUE67-DONE"
