#!/bin/bash
# The last two dense arms without a warm column: Milvus and sqlite-vec.
# With these, T5's dense block is 9 of 9 rows under one protocol on one engine
# line, and the cold/warm finding rests on six independent comparators instead
# of four.
#
# EVERY server setting below is COPIED from runner.py, not reconstructed. Three
# failures on this lane today all came from me rebuilding a launch from a
# partial read: wrong image (qdrant), missing BENCH_SERVER_HOST (arcsrv), and
# missing defaultDatabases + ARCADEDB_OPTS_MEMORY + the real ready_regex
# (arcsrv again). Copy, do not paraphrase.
#
# COST. Both are cheap, which is why they are worth doing rather than deferring
# to the October freeze:
#   Milvus      142 s build, ~18 ms/query -> ~5 min total
#   sqlite-vec   70 s build, 882 ms/query -> 73 min/pass UNCAPPED
#
# sqlite-vec is therefore CAPPED at 200 queries per pass. The driver puts the
# count in its own output and this script logs it, because a silent cap reads
# as full coverage. sqlite-vec is an exact scan with no ANN index, so it is the
# recall=1.0 baseline; a smaller query sample moves its latency estimate very
# little and cannot change the cold/warm ratio, which is the only thing these
# two arms are being run to establish.
set -u
OUT=~/q7
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "last two dense arms started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
CLIENT_IMG=dbbench:client
DENSE_IMG=dbbench:dense
MILVUS_IMG="milvusdb/milvus@sha256:0ea40276f8111f0183e72c8ee3144f3b9aafcd30571bd947de1ed0d22ee9dd56"

cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }
docker ps -q | grep -q . && { log "ABORT: foreign containers running"; exit 1; }

# ---- A: sqlite-vec (embedded, capped) -------------------------------------
if [ -s "$OUT/mp_sqlitevec_2681.json" ]; then
  log "A: SKIP sqlite-vec (already have it)"
else
  log "A: START sqlite-vec multipass, CAPPED at 200 queries/pass"
  timeout 10800 docker run --rm --name q7_sqlitevec --label dbbench=1 \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$ICDE:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_MP_BACKEND=sqlite_vec_dense -e BENCH_MP_SCALE=deep10m \
    -e BENCH_MP_NQUERIES=200 \
    -e BENCH_ROLE=engine -e PROBE_OUT=/out/mp_sqlitevec_2681.json \
    "$DENSE_IMG" python -u dense_multipass_driver.py > "$OUT/a_sqlitevec.log" 2>&1
  log "A: DONE rc=$?"
fi

# ---- B: Milvus (client-server) --------------------------------------------
if [ -s "$OUT/mp_milvus_2681.json" ]; then
  log "B: SKIP milvus (already have it)"
else
  docker rm -f q7milvus >/dev/null 2>&1
  log "B: starting milvus standalone (digest-pinned, embedded etcd)"
  # server_env, server_volumes, server_cmd and ready_regex copied from
  # runner.py's milvus entry. The embedded-etcd settings are not optional:
  # without DEPLOY_MODE=STANDALONE the image expects an external etcd.
  docker run -d --name q7milvus --cpuset-cpus 0-11 --memory 27g --memory-swap 27g \
    -e DEPLOY_MODE=STANDALONE \
    -e ETCD_USE_EMBED=true \
    -e ETCD_DATA_DIR=/var/lib/milvus/etcd \
    -e ETCD_CONFIG_PATH=/milvus/configs/embedEtcd.yaml \
    -e COMMON_STORAGETYPE=local \
    -v "$ICDE/docker-conf/embedEtcd.yaml:/milvus/configs/embedEtcd.yaml" \
    "$MILVUS_IMG" milvus run standalone >/dev/null \
    || { log "B: ABORT server failed to start"; log "LAST2-COMPLETE"; exit 1; }

  ready=0
  for i in $(seq 1 120); do
    if docker logs q7milvus 2>&1 | grep -qE "Proxy successfully started|successfully started"; then
      ready=1; log "B: milvus up after $((i*5))s"; break
    fi
    docker ps -q -f name=q7milvus | grep -q . || { log "B: server DIED"; break; }
    sleep 5
  done
  if [ $ready -ne 1 ]; then
    docker logs q7milvus 2>&1 | tail -10 | tee -a "$LOG"
    docker rm -f q7milvus >/dev/null 2>&1
    log "B: ABORT milvus never became ready"
  else
    log "B: START milvus multipass"
    timeout 10800 docker run --rm --name q7_milvus \
      --network container:q7milvus \
      --cpuset-cpus 0-11 --memory 9g --memory-swap 9g \
      -v "$ICDE:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
      -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
      -e BENCH_SERVER_HOST=localhost \
      -e BENCH_MP_BACKEND=milvus_dense -e BENCH_MP_SCALE=deep10m \
      -e BENCH_ROLE=client -e PROBE_OUT=/out/mp_milvus_2681.json \
      "$CLIENT_IMG" python -u dense_multipass_driver.py > "$OUT/b_milvus.log" 2>&1
    log "B: DONE rc=$?"
    docker rm -f q7milvus >/dev/null 2>&1
  fi
fi

# ---- Full dense-block summary, all nine arms ------------------------------
python3 - >> "$LOG" 2>&1 <<'PY'
import json, glob, os, statistics as st
rows = []
for d in ("q2","q4","q5","q6","q7"):
    for p in sorted(glob.glob(os.path.expanduser(f"~/{d}/mp_*.json"))):
        try:
            j = json.load(open(p))
        except Exception:
            continue
        if len(j) < 2:
            continue
        w = st.median([r["p50"] for r in j[1:]])
        rows.append((os.path.basename(p)[3:-10], j[0]["build_s"], j[0]["p50"], w,
                     j[0]["p50"]/w, j[0]["recall_at_10"], j[0].get("n_queries")))
print("\nDENSE BLOCK, all arms on 26.8.1, one-build/five-pass")
print("%-22s %9s %8s %8s %7s %8s %6s" % ("arm","build_s","cold50","warm50","c/w","recall","nq"))
for r in sorted(rows, key=lambda x: x[4]):
    print("%-22s %9.1f %8.3f %8.3f %6.2fx %8.4f %6s" % r)
PY

log "LAST2-COMPLETE"
