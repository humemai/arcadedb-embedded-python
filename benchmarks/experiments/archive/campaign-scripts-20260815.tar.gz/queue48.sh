#!/bin/bash
# WALL-clock profiles of both vector query lanes. queue37's wall arms failed.
#
# I passed "-e wall --wall 10ms". async-profiler 4.0's event list is
# cpu|alloc|nativemem|lock|cache-misses; there is no "wall" event. Wall-clock
# profiling is enabled by the standalone --wall <interval> flag. Rather than
# swap one guess for another, this tries the candidate spellings and uses
# whichever actually starts, reporting which one worked.
#
# Why it matters: every profile we have is -e cpu, which is blind to blocking
# (page faults, lock waits, I/O). The paper publishes p50 and p99, and nothing
# has ever profiled the quantity it publishes.
set -u
PROF=$HOME/profiling/async-profiler-4.0-linux-x64
OUT=$HOME/profiling/flame
exec >> "$HOME/profiling/queue48.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue48 waiting for QUEUE47-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE47-DONE" "$HOME/profiling/queue47.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue47.sh" >/dev/null || { say "queue47 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
say "engine: ${VER:-UNKNOWN}"

# $1 mode, $2 memory, $3 heap, $4 build-wait minutes
wall_lane() {
  local mode=$1 mem=$2 heap=$3 waitmin=$4
  local name=wall48_$mode
  guard
  docker rm -f $name >/dev/null 2>&1
  local extra=""
  [ "$mode" = "sparse" ] && extra="-e BENCH_SPARSE_SOURCE=bigann -e BENCH_SPARSE_DATA=/data/bigann"
  [ "$mode" = "dense" ]  && extra="-e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32"
  docker run -d --name $name --cpuset-cpus 0-11 --memory "$mem" --memory-swap "$mem" \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -v "$PROF:/prof:ro" -v "$OUT:/pout" \
    -e MODE=$mode -e PROFILE_SECS=900 -e ARCADEDB_HEAP="$heap" $extra \
    icde-bench:arcadedb python -u profile_query_driver.py >/dev/null \
    || { say "$mode failed to start"; return 1; }

  local n=$((waitmin * 6)) ready=0
  for i in $(seq 1 $n); do
    docker logs $name 2>&1 | grep -qa "QUERY-PHASE-START" && { ready=1; break; }
    docker ps -q -f name=$name | grep -q . || { say "$mode DIED"; docker logs $name 2>&1 | tail -5; return 1; }
    sleep 10
  done
  [ $ready -eq 1 ] || { say "$mode never reached the query phase"; docker rm -f $name >/dev/null 2>&1; return 1; }
  sleep 20

  # Try each candidate until one starts.
  local started=""
  for spec in "--wall 10ms" "--wall 10000000" "-e wall"; do
    if docker exec $name /prof/bin/asprof start $spec 1 >/dev/null 2>&1; then
      started="$spec"; break
    fi
  done
  if [ -z "$started" ]; then
    say "$mode: no wall syntax accepted; tried --wall 10ms, --wall 10000000, -e wall"
    docker logs $name 2>&1 | tail -3
    docker rm -f $name >/dev/null 2>&1; return 1
  fi
  say "$mode: wall profiling started with '$started'"
  sleep 240
  docker exec $name /prof/bin/asprof stop -o collapsed \
    -f "/pout/${mode}_wall_${VER}.collapsed" 1 >/dev/null 2>&1 \
    && say "$mode wall profile written" || say "$mode wall stop FAILED"
  docker rm -f $name >/dev/null 2>&1
}

wall_lane sparse 20g 8g  25  || say "sparse wall lane failed"
wall_lane dense  36g 24g 120 || say "dense wall lane failed"

say "=== wall profiles: where the LATENCY goes ==="
python3 - <<'PY'
import collections, glob, os
for p in sorted(glob.glob("/home/tk/profiling/flame/*_wall_*.collapsed")):
    c = collections.Counter(); tot = 0
    for line in open(p, errors="ignore"):
        st, _, v = line.rpartition(" ")
        try: v = int(v)
        except ValueError: continue
        tot += v; c[st.split(";")[-1]] += v
    if not tot:
        print(f"\n== {os.path.basename(p)}: EMPTY"); continue
    print(f"\n== {os.path.basename(p)}  ({tot:,} samples)")
    for f, v in c.most_common(12):
        print(f"   {100*v/tot:5.1f}%  {f.split('/')[-1][:60]}")
    # The point of a wall profile: what shows up here that CPU sampling cannot see.
    blocked = sum(v for st, v in c.items()
                  if any(s in st for s in ("park", "Unsafe", "wait", "Lock", "read", "Socket")))
    print(f"   -> blocking-ish frames: {100*blocked/tot:.1f}% "
          f"(invisible to the -e cpu profiles)")
PY
say "QUEUE48-DONE"
