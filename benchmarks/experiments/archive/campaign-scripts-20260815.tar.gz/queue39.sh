#!/bin/bash
# GAV ablation on the SciPy corpus (Cross Validated), matching the ICDE SF10
# ablation in shape.
#
# Why a second ablation rather than citing the first: the ICDE run is LDBC SF10
# and the SciPy paper's graph numbers are Cross Validated. The sentence needing
# support ("the GAV ... accelerates ArcadeDB's analytical traversals") sits in
# the SciPy paper, so it needs a number from the SciPy corpus. Borrowing across
# corpora is the exact error we had to correct once already.
#
# Image is scipy-bench:arcadedb (26.8.1.dev20). The paper states its graph lane
# was published on dev2 and discloses that dev20 reproduces it within spread, so
# an ablation on dev20 is consistent with what the paper already says.
set -u
exec >> "$HOME/profiling/queue39.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue39 waiting for QUEUE36-DONE"
for i in $(seq 1 900); do
  grep -qa "QUEUE36-DONE" "$HOME/profiling/queue36.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue36.sh" >/dev/null || { say "queue36 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/scipy-bench/experiments || die "no scipy experiments dir"
grep -q 'BENCH_GAV' graph_bench.py || die "BENCH_GAV switch not staged in graph_bench.py"
say "BENCH_GAV switch present"

OUT=$HOME/profiling/scipy_gav; mkdir -p "$OUT" results
for gav in 1 0; do
  LAB=with; [ "$gav" = "0" ] && LAB=without
  OK=0
  for rep in 1 2 3 4 5; do
    guard
    timeout 5400 docker run --rm --cpuset-cpus 0-7 --memory 32g --memory-swap 32g \
      -e ARCADEDB_HEAP=16g -e BENCH_GAV="$gav" \
      -v "$PWD:/work" -w /work -v "$HOME/scipy-bench/data:/data:ro" \
      scipy-bench:arcadedb python -u graph_bench.py \
        --backend arcadedb --workload olap \
        --data /data/stackoverflow-medium/prepared \
        --out "/work/results/gav_${LAB}_r${rep}.json" \
      > "$OUT/${LAB}_r${rep}.log" 2>&1
    rc=$?; [ $rc -eq 0 ] && OK=$((OK+1))
    [ $rc -ne 0 ] && grep -aE "^ABORT|Traceback|Error|error" "$OUT/${LAB}_r${rep}.log" | head -3
    say "SCIPY-GAV-$LAB r$rep rc=$rc"
  done
  say "SCIPY-GAV-$LAB-OK $OK/5"
done

say "=== comparison ==="
python3 - <<'PY'
import json, glob, statistics
def load(lab):
    rs = []
    for f in sorted(glob.glob(f"/home/tk/scipy-bench/experiments/results/gav_{lab}_r*.json")):
        try: rs.append(json.load(open(f)))
        except Exception: pass
    return rs
a, b = load("with"), load("without")
if not a or not b:
    print(f"  incomplete: with={len(a)} without={len(b)}")
else:
    keys = sorted(k for k in a[0] if k.endswith("_ms") or k == "olap_ms")
    print(f"  with    n={len(a)}")
    print(f"  without n={len(b)}")
    for k in keys:
        try:
            av = statistics.median([r[k] for r in a])
            bv = statistics.median([r[k] for r in b])
        except Exception:
            continue
        print(f"  {k}: with {av:.1f} ms, without {bv:.1f} ms, without/with = {bv/av:.2f}x")
    g = [r.get("gav_build_s", 0) for r in a]
    print(f"  gav build: {statistics.median(g):.2f} s")
PY
say "QUEUE39-DONE"
