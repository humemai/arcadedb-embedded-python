#!/usr/bin/env bash
set -u
while pgrep -f deep10m_chain.sh >/dev/null; do sleep 300; done
cd /home/tk/repos/arcadedb-icde
git fetch -q origin icde-2027 && git checkout origin/icde-2027 -- paper-icde/experiments/ || { echo "FILL-ABORT sync"; exit 1; }
cd paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "FILL-ABORT ffmpeg"; exit 1; }
python3 - << PYEOF
import json
p = "results/runs.jsonl"
rows = [json.loads(l) for l in open(p)]
bad = ("arcadedb_dense_server", "qdrant_dense", "milvus_dense")
keep = [r for r in rows if not (r.get("scale") == "deep10m" and r.get("backend") in bad)]
open(p, "w").writelines(json.dumps(r) + "\n" for r in keep)
print("purged", len(rows) - len(keep), "dead server-topology rows")
PYEOF
echo "=== DEEP-10M server-topology refill $(date -u +%FT%TZ) ==="
BENCH_DENSE_DATA=/data/dense BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l3d --scale deep10m --reps 5 --tier sweep --workers 1 \
  --backends arcadedb_dense_server,qdrant_dense,milvus_dense
echo "rc=$?"
echo "DEEP10M-FILL-COMPLETE"
