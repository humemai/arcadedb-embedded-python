#!/bin/bash
# Resume queue60's sparse re-measure once the dense fairness work is done.
#
# queue60 was stopped at 2 of 10 medium cells so queue61 and queue62 could run
# first. That was a priority call, not a cancellation: the dense lane has
# three published defects (protocol, memory envelope, and the ranking
# uncertainty they create) while the sparse re-measure improves numbers that
# are already correct. Same total wall clock, dense answers ~11 h sooner.
#
# queue60 is resumable by construction: run_cell skips any cell whose output
# already exists, so relaunching it re-runs only medium reps 2-5 of each arm
# and leaves the 22 completed cells alone.
set -u
exec >> "$HOME/profiling/queue63.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }

for prev in queue61 queue62; do
  # Match on the script path without the leading "./" so this pattern cannot
  # match the launching shell's own command line, which is how an earlier
  # pkill -f killed its own ssh session.
  if pgrep -f "bash ./$prev.sh" > /dev/null 2>&1; then
    say "$prev running; waiting"
    while pgrep -f "bash ./$prev.sh" > /dev/null 2>&1; do sleep 60; done
    say "$prev finished"
  fi
done
while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done

say "resuming queue60 (skips the 22 cells already on disk)"
cd ~ && bash ./queue60.sh
say "QUEUE63-DONE (queue60 resumed and finished)"
