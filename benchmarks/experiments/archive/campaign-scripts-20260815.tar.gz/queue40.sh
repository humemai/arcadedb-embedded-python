#!/bin/bash
# Replace T5's server dense row with a current-line measurement.
#
# The published cell (build 13.3k) was measured on a server image built
# 07-25 23:58 UTC, which sits between the bounded-build-cache commit
# (0d1bca913a, 07-23) and its auto-sizing fix (5d9f9ff72f, 07-26). So the
# 13.3k is that regression, not a deployment cost: the embedded row on the
# fixed line builds in 2.7k and the same regression showed there as 11,126 s
# before it was fixed.
#
# One build on the current line, then N=4 warm query passes (pass 1 cold,
# excluded), which is exactly the protocol the embedded rows already use.
# That makes build and query come from one build on one version, which is
# what the current cell does not have.
set -u
VER="${VER:-26.8.1.dev23}"
exec >> "$HOME/profiling/queue40.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue40 waiting for QUEUE38-DONE"
for i in $(seq 1 1400); do
  grep -qa "QUEUE38-DONE" "$HOME/profiling/queue38.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue38.sh" >/dev/null || { say "queue38 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"

OUT=$HOME/profiling/srv_dense_dev23; mkdir -p "$OUT"

# Record what we are actually measuring, since the cell being replaced is
# wrong precisely because its version provenance was not recorded next to it.
docker image inspect arcadedata/arcadedb:26.8.1-SNAPSHOT \
  --format '{{index .RepoDigests 0}}' > "$OUT/server_digest.txt" 2>/dev/null \
  || say "WARN: could not record server digest"
say "server digest: $(cat "$OUT/server_digest.txt" 2>/dev/null)"

guard
timeout 28800 docker run --rm --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
  -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" -v "$OUT:/pout" \
  -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 -e ARCADEDB_HEAP=24g \
  -e BENCH_DENSE_REPS=5 \
  icde-bench:arcadedb python -u l3d_dense.py \
    --backend arcadedb_dense_server --scale deep10m \
    --out "/pout/srv_dense_${VER}.json" \
  > "$OUT/run.log" 2>&1
rc=$?
say "SRV-DENSE rc=$rc"
[ $rc -ne 0 ] && grep -aE "^ABORT|Traceback|Error" "$OUT/run.log" | head -5

python3 - <<'PY'
import json, glob
fs = sorted(glob.glob("/home/tk/profiling/srv_dense_dev23/srv_dense_*.json"))
if not fs:
    print("  no result json")
else:
    d = json.load(open(fs[0]))
    b = d.get("build_s")
    print(f"  build_s = {b}")
    print(f"  p50 = {d.get('query_p50_ms')}  p99 = {d.get('query_p99_ms')}"
          f"  recall = {d.get('recall_at_10')}")
    if isinstance(b, (int, float)):
        # The published cell is 13,349 s; embedded on the fixed line is 2,693 s.
        # Anything near 13k means the regression is NOT what we think it is and
        # the paper's correction has to be withdrawn, so say so loudly.
        print(f"  vs published 13349 s: {13349/b:.2f}x faster" if b else "")
        if b > 9000:
            print("  *** STILL SLOW: the pre-fix-image explanation does not hold ***")
PY
say "QUEUE40-DONE"
