#!/bin/bash
# What does QDRANT actually size its pools to, under our cpuset?
#
# queue64 asked the container, not the engine: it ran `nproc` and
# `grep -c ^processor /proc/cpuinfo` and labelled both "qdrant sees". Those are
# the container's view. They disagree with each other (nproc respects affinity,
# /proc/cpuinfo does not) and neither is Qdrant's thread pool.
#
# Ask Qdrant three ways instead:
#   1. its own telemetry, which reports the configured search/optimizer threads
#   2. the OS thread count of the running process (ground truth: what it started)
#   3. what the container view says, kept only to show the two are different
set -u
IMG=qdrant/qdrant@sha256:75eab8c4ba42096724fdcfde8b4de0b5713d529dde32f285a1f86fdcb2c9e50c
C=qthreads_probe
docker rm -f $C >/dev/null 2>&1
docker run -d --name $C --cpuset-cpus 0-11 --memory 8g $IMG >/dev/null 2>&1
echo "started, waiting for readiness..."
for i in $(seq 1 40); do
  docker exec $C sh -c 'exit 0' 2>/dev/null || break
  code=$(docker exec $C sh -c "wget -qO- http://localhost:6333/readyz 2>/dev/null" 2>/dev/null)
  [ -n "$code" ] && break
  sleep 1
done

echo
echo "=== 1. what the CONTAINER reports (not the engine) ==="
docker exec $C sh -c 'echo "  nproc            : $(nproc 2>/dev/null)"
echo "  nproc --all      : $(nproc --all 2>/dev/null)"
echo "  /proc/cpuinfo    : $(grep -c ^processor /proc/cpuinfo)"' 2>/dev/null

echo
echo "=== 2. what QDRANT reports about its own pools (telemetry) ==="
docker exec $C sh -c 'wget -qO- "http://localhost:6333/telemetry?details_level=3" 2>/dev/null' 2>/dev/null \
  | python3 -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception as e: print('  telemetry unreadable:', e); raise SystemExit
def walk(o, p=''):
    if isinstance(o, dict):
        for k,v in o.items():
            if any(t in k.lower() for t in ('thread','cpu','core','parallel','worker')):
                if not isinstance(v,(dict,list)): print(f'  {p}{k} = {v}')
            walk(v, p+k+'.')
    elif isinstance(o, list):
        for i,v in enumerate(o[:3]): walk(v, p)
walk(d)
" 2>/dev/null || echo "  (no thread fields found in telemetry)"

echo
echo "=== 3. GROUND TRUTH: OS threads the qdrant process actually started ==="
docker exec $C sh -c '
for p in /proc/[0-9]*; do
  comm=$(cat $p/comm 2>/dev/null)
  [ "$comm" = "qdrant" ] || continue
  n=$(ls $p/task 2>/dev/null | wc -l)
  echo "  pid $(basename $p) ($comm): $n OS threads"
done' 2>/dev/null
echo "  distinct thread names (top 12 by count):"
docker exec $C sh -c 'for t in /proc/[0-9]*/task/*/comm; do cat $t 2>/dev/null; done' 2>/dev/null \
  | sort | uniq -c | sort -rn | head -12 | sed 's/^/    /'

docker rm -f $C >/dev/null 2>&1
echo
echo "QDRANT-THREADS-DONE"
