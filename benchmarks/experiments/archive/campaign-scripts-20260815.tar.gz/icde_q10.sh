#!/bin/bash
# q10: everything still owed on the released 26.8.1, in one queue.
#
# REPLACES q9 (icde_freeze_chain.sh), which was killed before it did any work.
# q9 was correct about WHAT to run and wrong about HOW: it invoked runner.py
# without exporting a single data-source variable. runner.py forwards exactly
#   BENCH_SPARSE_SOURCE BENCH_SPARSE_DATA BENCH_GRAPH_SOURCE BENCH_GRAPH_DATA
#   BENCH_DENSE_DATA BENCH_DENSE_M BENCH_TPC_DATA BENCH_TPC_SF
# from its own environment, and forwards NOTHING it was not given. So q9 would
# have:
#   - run l2 on the SYNTHETIC generator at LDBC memory tiers, because
#     l2_graph.py:25 defaults BENCH_GRAPH_SOURCE to "synthetic". Silently. The
#     rows would have looked fine and been incomparable to T3.
#   - failed l1tpc outright, because BENCH_TPC_DATA defaults to /data/tpch and
#     runner.py would have mounted benchmarks/experiments/data (which holds
#     only sparse/) as /data.
# That is the same silent-wrong-corpus class as every other failure this week,
# so the exports below are asserted, not assumed.
#
# SCOPE: the four things not yet on the release.
#   T2 tabular   l1 medium + l1tpc tpch1
#   T3 graph     l2 sf1 + sf10 (the tiers T3 prints, NOT medium)
#   T5 ts block  l4, which was never wired into runner.py and needs the
#                queue68 driver shape
#   T4 licence   the sparse F9 control
# T4 sparse (q8) and T5 dense (q2/q4/q5/q6/q7) are already on 26.8.1.
#
# ORDER IS CHEAP-AND-STALE FIRST. A box reclaimed early still leaves the paper
# better off. l1 medium (~4 h) goes last on purpose.
set -u
OUT=~/q10
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q10 started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

PIN=26.8.1

# ---- Phase 0: wait for q8, WITH A HARD DEADLINE ---------------------------
# A chained wait with no deadline is a hang that looks like patience.
DEADLINE=$(( $(date +%s) + 8*3600 ))
log "waiting for SPARSE-2681-COMPLETE (hard deadline 8 h)"
while ! grep -qa "SPARSE-2681-COMPLETE" ~/q8/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then
    log "ABORT: q8 did not finish within 8 h; not starting on a busy box"
    exit 1
  fi
  sleep 60
done
log "q8 finished"

# Belt and braces: the marker can land a moment before the last container exits.
for _ in $(seq 1 60); do
  docker ps -q | grep -q . || break
  sleep 30
done

# ---- Phase 1: the environment q9 did not set, each one asserted ------------
export BENCH_DATA=$HOME/bench-data        # host side: what runner.py mounts at /data
export BENCH_GRAPH_SOURCE=ldbc            # l2_graph.py defaults to "synthetic"
export BENCH_GRAPH_DATA=/data/ldbc        # ldbc_snb.py:42 reads this
export BENCH_TPC_DATA=/data/tpch
export BENCH_TPC_SF=1
export BENCH_SPARSE_SOURCE=bigann
export BENCH_SPARSE_DATA=/data/bigann

[ -d "$BENCH_DATA/ldbc/sf1" ]  || { log "ABORT: no ldbc/sf1 under $BENCH_DATA"; exit 1; }
[ -d "$BENCH_DATA/ldbc/sf10" ] || { log "ABORT: no ldbc/sf10 under $BENCH_DATA"; exit 1; }
[ -d "$BENCH_DATA/bigann" ]    || { log "ABORT: no bigann under $BENCH_DATA"; exit 1; }
ls "$BENCH_DATA"/tpch/sf1_*.parquet >/dev/null 2>&1 \
  || { log "ABORT: no tpch sf1_*.parquet under $BENCH_DATA"; exit 1; }
[ -f "$BENCH_DATA/tsbs/cpu_influx.lp" ] || { log "ABORT: no tsbs line protocol"; exit 1; }
log "data preflight ok (ldbc sf1+sf10, tpch sf1, bigann, tsbs)"

# F5 gate: what is INSTALLED, not what was asked for.
GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "$PIN" ] || { log "ABORT: image is not $PIN"; exit 1; }

# ---- Phase 2: the runner.py lanes -----------------------------------------
# runner.py owns topologies, cpuset, the memory split, manifests, the watchdog
# and the orphan sweep. This drives it and overrides nothing.
lane() {  # label lane scale backends [timeout_s]
  local label=$1 ln=$2 scale=$3 be=$4 tmo=${5:-21600}
  local marker="$OUT/${label}.done"
  [ -f "$marker" ] && { log "  skip $label (done)"; return; }
  local t0=$(date +%s)
  log "  START $label  lane=$ln scale=$scale backends=$be"
  timeout "$tmo" python3 runner.py --lanes "$ln" --scale "$scale" \
      --backends "$be" --reps 5 --tier paper --workers 0 \
      > "$OUT/${label}.log" 2>&1
  local rc=$? el=$(( $(date +%s) - t0 ))
  if [ $rc -eq 0 ]; then
    touch "$marker"; log "  DONE  $label rc=$rc ${el}s"
  else
    log "  FAIL  $label rc=$rc ${el}s"; tail -15 "$OUT/${label}.log" >> "$LOG"
  fi
}

# l1tpc: oldest pin in the paper (dev3), and cheap.
lane l1tpc_tpch1 l1tpc tpch1 "arcadedb_embedded,arcadedb_server,duckdb"

# l2: the tiers T3 actually prints. NOT the medium tier.
lane l2_sf1  l2 sf1  "arcadedb_graph_embedded,arcadedb_graph_server,ladybug_graph"
lane l2_sf10 l2 sf10 "arcadedb_graph_embedded,arcadedb_graph_server,ladybug_graph"

# E2 hybrid/atomicity: cheap, and a thesis claim rather than a table cell.
lane e2_hybrid e2 e2 "arcadedb_e2"

# ---- Phase 3: L4 time series ----------------------------------------------
# Never wired into runner.py (the placeholder is still at runner.py:285), so it
# needs the queue68 driver shape. EVERY knob below is copied from queue68.sh,
# which produced the rows T5 prints. The only deliberate changes:
#   icde-bench:* -> dbbench:*          (image rename)
#   ~/icde-data  -> ~/bench-data       (data move)
#   -v $OUT:/out and --out /out/...    (queue68 wrote into its work dir; this
#                                       keeps output out of the git checkout,
#                                       which q10's other phases are using)
#
# TS_SETTLE_S=0 ON EVERY ARM, and that is a fairness decision, not laziness.
# queue71 ran the settle A/B: settle=0 gave 435,134/0.88/0.77/2.26 and
# settle=30 gave 431,280/1.13/0.79/2.14, both reproducing the old row
# (431,306/0.85/0.77/2.22). A settle changes nothing, so nobody gets one and
# F4 stays clean.
L4_DONE="$OUT/l4.done"
if [ -f "$L4_DONE" ]; then
  log "  skip l4 (done)"
else
  log "  START l4 (4 arms x 5 reps, rotated)"
  CPUS=0-11
  MEM=20g
  NET=q10net
  docker network rm $NET >/dev/null 2>&1
  docker network create $NET >/dev/null 2>&1 || { log "  l4 ABORT: no network"; }

  # BENCH_HOST is passed EXPLICITLY: run_conditions() reports the real hostname,
  # which inside a container is a random ID. Only the launcher knows this is mini.
  COMMON="--cpuset-cpus $CPUS --memory $MEM --memory-swap $MEM
          -v $ICDE:/work -w /work -v $HOME/bench-data:/data:ro -v $OUT:/out
          -e TSBS_LP=/data/tsbs/cpu_influx.lp -e BENCH_HOST=mini"

  run_doc() {  # backend rep
    local be=$1 rep=$2 img extra=""
    case "$be" in
      arcadedb) img=dbbench:arcadedb; extra="-e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine" ;;
      duckdb)   img=dbbench:duckdb;   extra="-e BENCH_ROLE=engine" ;;
      questdb)  img=dbbench:client;   extra="-e BENCH_ROLE=driver -e QUEST_HOST=q10quest" ;;
    esac
    if [ "$be" = questdb ]; then
      docker rm -f q10quest >/dev/null 2>&1
      docker run -d --name q10quest --network $NET \
        --cpuset-cpus $CPUS --memory $MEM --memory-swap $MEM \
        questdb/questdb:9.1.1 >/dev/null 2>&1
      local ok=0
      for _ in $(seq 1 60); do
        docker exec q10quest sh -c 'nc -z 127.0.0.1 8812' >/dev/null 2>&1 && { ok=1; break; }
        docker ps -q -f name=q10quest | grep -q . || break
        sleep 2
      done
      [ "$ok" = 1 ] || { log "    questdb rep$rep NEVER-READY"; docker rm -f q10quest >/dev/null 2>&1; return 1; }
    fi
    timeout 3600 docker run --rm --name q10_${be}_r${rep} --network $NET \
      $COMMON $extra $img \
      python -u l4_tsbs.py --backend "$be" --out "/out/${be}_r${rep}.json" \
      >>"$OUT/l4_${be}_r${rep}.log" 2>&1
    local rc=$?
    [ "$be" = questdb ] && docker rm -f q10quest >/dev/null 2>&1
    return $rc
  }

  run_native() {  # rep
    local rep=$1
    timeout 3600 docker run --rm --name q10_native_r${rep} \
      $COMMON \
      -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=1 \
      -e TS_SETTLE_S=0 -e TS_LAST_AB=1 \
      -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
      -e PROBE_OUT="/out/native_r${rep}.json" \
      dbbench:arcadedb python -u l4_native_probe.py \
      >>"$OUT/l4_native_r${rep}.log" 2>&1
  }

  ARMS=(arcadedb duckdb questdb native)
  for rep in 1 2 3 4 5; do
    # Rotate the starting arm. Running arm-by-arm to completion is how the dense
    # transport probe produced a 44% claim that reordering cut to 7%: whoever
    # goes first pays the page-cache and JIT warming for everyone after.
    off=$(( (rep - 1) % 4 ))
    order=()
    for k in 0 1 2 3; do order+=("${ARMS[$(( (off + k) % 4 ))]}"); done
    log "    rep$rep order: ${order[*]}"
    for be in "${order[@]}"; do
      if [ "$be" = native ]; then
        run_native "$rep" && log "    native   rep$rep ok" || log "    native   rep$rep FAILED"
      else
        run_doc "$be" "$rep" && log "    ${be} rep$rep ok" || log "    ${be} rep$rep FAILED"
      fi
    done
  done
  docker network rm $NET >/dev/null 2>&1
  touch "$L4_DONE"
  log "  DONE  l4"
fi

# ---- Phase 4: the sparse F9 control ---------------------------------------
# T4's Qdrant/Milvus/Elasticsearch rows are currently carried forward on
# argument alone. F9 says a kept row needs a control, because the host is not
# an invariant. Re-running ONE untouched comparator and having it reproduce
# itself is what licenses keeping the other two.
#
# Driven through runner.py rather than a hand-rolled launch: qdrant_sparse is a
# client_server topology, and reconstructing a server launch from a partial
# read is exactly what cost three runs on 2026-08-04.
lane l3s_qdrant_f9 l3s medium "qdrant_sparse" 36000

# ---- Phase 5: l1 at medium = 20M rows, the tier T2 prints. ~4 h, so last.
lane l1_medium l1 medium "arcadedb_embedded,arcadedb_server,duckdb"

# ---- Phase 6: what landed -------------------------------------------------
python3 - >> "$LOG" 2>&1 <<'PY'
import glob, json, os, collections
print("\nq10: engine versions per lane after the re-pin")
seen = collections.defaultdict(set)
root = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments/results/raw")
for p in glob.glob(os.path.join(root, "*.json")):
    try:
        j = json.load(open(p))
    except Exception:
        continue
    if not isinstance(j, dict):
        continue
    lane = j.get("lane")
    if lane:
        seen[lane].add(str(j.get("engine_version")))
for lane in sorted(seen):
    vers = sorted(seen[lane])
    flag = "  <-- STILL MIXED" if len(vers) > 3 else ""
    print("  %-8s %s%s" % (lane, ", ".join(vers)[:110], flag))

print("\nq10: L4 arms, and whether each row records its own conditions")
CK = ("cpuset", "heap", "mem_cap", "host", "ts_utc", "producer", "role")
files = sorted(glob.glob(os.path.expanduser("~/q10/*_r*.json")))
if not files:
    print("  NO L4 RESULT FILES. Do not report a number.")
for fp in files:
    try:
        r = json.load(open(fp))
    except Exception as e:
        print(f"  {os.path.basename(fp):<22} UNREADABLE {e}")
        continue
    miss = [k for k in CK if r.get(k) in (None, "")]
    ver = r.get("backend_version") or r.get("engine_version")
    tag = "ok" if (not miss and ver) else f"BAD missing={miss or ''} ver={ver!r}"
    print("  %-22s %s" % (os.path.basename(fp), tag))
PY

log "Q10-COMPLETE"

# NOT COVERED HERE, deliberately:
#  - E3 recovery / Raft. Reports as prose numbers and needs a 3-node setup;
#    it gets an attended run.
#  - The dense lane. Already 9/9 on 26.8.1 at a matched 36g envelope.
#  - l3d "small" tier, which fails F7 (ArcadeDB degree 16 vs comparators 32).
#    DEEP-10M is matched at 32 and is the tier T5 prints, so the fix is to drop
#    small rather than spend the box on it. That is a decision, not a run.
