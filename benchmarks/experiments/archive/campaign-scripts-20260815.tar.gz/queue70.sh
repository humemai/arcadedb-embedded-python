#!/bin/bash
# queue70: close the two gaps q67 and q68 left, both harness defects of mine.
#
# GAP 1 (from q68): the questdb arm failed 5/5 with NEVER-READY. My readiness
# probe was `docker exec q68quest sh -c 'nc -z 127.0.0.1 8812'` and the image
# has no nc, no curl and no wget (verified). So the probe could never pass and
# the arm was never even attempted. Fixed by probing from the CLIENT image,
# which has psycopg, over the same docker network: that also tests the thing
# that actually matters (pg-wire accepting a connection) instead of a proxy
# for it.
#
# GAP 2 (from q67): phase 2 produced no flame graph. The container exited
# between `asprof start` and `asprof stop`:
#     Error response from daemon: container ... is not running
#     NO COLLAPSED FILE. Do not report a number.
# Cause is arithmetic, not infrastructure. PROBE_PROFILE ran --reps 200 and
# dst_prop_only takes ~0.40 s at this scale, so the loop had ~80 s of work
# against a 180 s profiling window and ran out. The guard did its job and
# refused to report, which is why this is a re-run and not a retraction.
# Fixed with reps sized from the measured latency: 401 ms x 900 = ~6 min,
# comfortably longer than the 180 s window plus the attach delay.
#
# The timing half of the GAV finding is ALREADY CONFIRMED at the published
# scale by q67 phase 1 (100k persons, 2.1M edges, arms agree on all queries):
#     src_prop_only  5.89x   far endpoint untouched
#     dst_prop_only  3.38x   same query shape, same single property, far end
# so this run is only the mechanism gate. If ColumnStore.getValue and the
# boxing are not hot, the source reading is refuted and nothing gets filed.
set -u
OUT=$HOME/q70
PROF=$HOME/profiling/flame
mkdir -p "$OUT" "$PROF"
say(){ echo "[$(date +%T)] $*"; }

for i in $(seq 1 240); do
  n=$(docker ps -q | wc -l)
  [ "$n" -eq 0 ] && break
  [ "$i" -eq 1 ] && say "waiting for mini to go idle ($n container(s) up)"
  if [ "$i" -eq 240 ]; then say "DEADLINE: mini still busy after 4h"; exit 1; fi
  sleep 60
done
say "mini idle"

CPUS=0-11
NET=q70net

# ------------------------------------------------------------------ gap 1
say "=== questdb arm, N=5, readiness probed from the client image ==="
cd "$HOME/q68work" || { say "no q68work"; exit 1; }
docker network rm $NET >/dev/null 2>&1
docker network create $NET >/dev/null 2>&1

quest_ready() {   # psycopg from the client image: the real check, not a proxy
  docker run --rm --network $NET icde-bench:client python -c "
import sys, time, psycopg
for _ in range(90):
    try:
        psycopg.connect('host=q70quest port=8812 dbname=qdb user=admin password=quest',
                        connect_timeout=3).close()
        sys.exit(0)
    except Exception:
        time.sleep(2)
sys.exit(1)" >/dev/null 2>&1
}

for rep in 1 2 3 4 5; do
  docker rm -f q70quest >/dev/null 2>&1
  docker run -d --name q70quest --network $NET \
    --cpuset-cpus $CPUS --memory 20g --memory-swap 20g \
    questdb/questdb:9.1.1 >/dev/null 2>&1
  if quest_ready; then
    timeout 3600 docker run --rm --name q70_questdb_r${rep} --network $NET \
      --cpuset-cpus $CPUS --memory 20g --memory-swap 20g \
      -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
      -e TSBS_LP=/data/tsbs/cpu_influx.lp -e BENCH_HOST=mini \
      -e BENCH_ROLE=driver -e QUEST_HOST=q70quest \
      icde-bench:client python -u l4_tsbs.py \
        --backend questdb --out "/work/out/questdb_r${rep}.json" \
      >>"$OUT/questdb_r${rep}.log" 2>&1 \
      && say "  questdb rep$rep ok" || say "  questdb rep$rep FAILED"
  else
    say "  questdb rep$rep NEVER-READY (still)"
    docker logs q70quest 2>&1 | tail -5
  fi
  docker rm -f q70quest >/dev/null 2>&1
done
docker network rm $NET >/dev/null 2>&1
cp -r "$HOME/q68work/out" "$OUT/results" 2>/dev/null

python3 - <<'PY'
import glob, json, os, statistics as st
d = os.path.expanduser("~/q68work/out")
rows = []
for fp in sorted(glob.glob(os.path.join(d, "questdb_r*.json"))):
    try: rows.append(json.load(open(fp)))
    except Exception: pass
if not rows:
    print("  questdb: NO RESULTS, T5 keeps its unprovenanced row"); raise SystemExit
def m(k):
    v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
    return st.median(v) if v else float("nan")
r0 = rows[0]
print(f"\n  questdb n={len(rows)}  ingest {m('ingest_pts_per_s'):,.0f}  "
      f"last {m('q_last_ms'):.2f}  1h {m('q_range_ms'):.2f}  12h {m('q_global_ms'):.2f}")
print(f"    host={r0.get('host')} cpuset={r0.get('cpuset')} ver={r0.get('backend_version')}")
print("    old unprovenanced row: 431,306 / 0.85 / 0.77 / 2.22")
print("    DuckDB already reproduced within 4% in q68, so a questdb move")
print("    beyond run-to-run spread would be the surprise, not the norm.")
PY

# ------------------------------------------------------------------ gap 2
say "=== GAV profile, reps sized to outlast the 180s window ==="
cd "$HOME/q67work" || { say "no q67work"; exit 1; }
docker rm -f gavprof70 >/dev/null 2>&1
docker run -d --name gavprof70 \
  --cpuset-cpus $CPUS --memory 16g --memory-swap 16g \
  -v "$PWD:/work" -w /work \
  -v "$HOME/profiling/async-profiler-4.0-linux-x64:/prof:ro" -v "$PROF:/pout" \
  -e ARCADEDB_HEAP=8g -e PROBE_PROFILE=dst_prop_only \
  icde-bench:arcadedb-srv python -u gav_property_probe.py \
    --scale small --reps 900 --warmup 2 >/dev/null 2>&1

found=0
for i in $(seq 1 120); do
  docker logs gavprof70 2>&1 | grep -qa "PROFILE-PHASE-START" && { found=1; break; }
  docker ps -q -f name=gavprof70 | grep -q . || {
    say "gavprof70 DIED before the profile phase"; docker logs gavprof70 2>&1 | tail -8; exit 1; }
  sleep 15
done
[ "$found" -eq 1 ] || { say "never reached the profile phase in 30m"; docker rm -f gavprof70 >/dev/null 2>&1; exit 1; }

sleep 5
docker exec gavprof70 /prof/bin/asprof start -e cpu 1 && say "profiling"
sleep 180
# Check it is STILL alive before stopping: that is exactly what failed in q67,
# and a stop against a dead container is how we got a silent empty file.
if ! docker ps -q -f name=gavprof70 | grep -q .; then
  say "GUARD: container exited during the profile window again; NOT reporting"
  docker logs gavprof70 2>&1 | tail -6; exit 1
fi
docker exec gavprof70 /prof/bin/asprof stop -o collapsed -f /pout/gav70_dst_prop.collapsed 1 \
  && say "collapsed written"
docker rm -f gavprof70 >/dev/null 2>&1

say "=== is far-endpoint property access where the source says it is? ==="
python3 - <<'PY'
import collections, os
p = os.path.expanduser("~/profiling/flame/gav70_dst_prop.collapsed")
if not os.path.exists(p) or os.path.getsize(p) == 0:
    print("  NO COLLAPSED FILE. Do not report a number."); raise SystemExit
tot, self_, stacks = 0, collections.Counter(), []
for line in open(p):
    parts = line.rsplit(" ", 1)
    if len(parts) != 2: continue
    stack, n = parts[0], int(parts[1])
    tot += n; self_[stack.split(";")[-1]] += n; stacks.append((stack, n))
print(f"  total samples: {tot:,}")
for frame, n in self_.most_common(16):
    print(f"  {100.0*n/tot:6.2f}%  {frame[:76]}")
def anywhere(*needles):
    return sum(n for s, n in stacks if any(x in s for x in needles))
print()
for label, needles in [
    ("ColumnStore.getValue",            ("ColumnStore.getValue",)),
    ("GraphAnalyticalView.getProperty", ("GraphAnalyticalView.getProperty",)),
    ("GAVVertex property access",       ("GAVVertex.get", "GAVVertex.has")),
    ("HashMap.get under getValue",      ("ColumnStore.getValue;java.util.HashMap.get",)),
    ("boxing (valueOf)",                ("Integer.valueOf", "Long.valueOf", "Double.valueOf")),
    ("record load fallback",            ("GAVVertex.resolve", "lookupByRID")),
    ("getBucketColumnStore",            ("getBucketColumnStore",)),
]:
    print(f"  {label:<34}{100.0*anywhere(*needles)/tot:6.2f}%")
print()
print("  GATE: the claim is that property access is per-row through a")
print("  string-keyed HashMap plus boxing while getBucketColumnStore (the")
print("  vectorized API) is never called. Near-zero on the first group")
print("  REFUTES it and the issue does not get filed.")
PY
say "QUEUE70-DONE"
