#!/bin/bash
# T4, the sparse lane, on ONE released engine: 26.8.1.
#
# WHY THIS IS THE JOB. An audit of every ICDE lane's artifacts today found not a
# single lane pinned to the release. The sparse lane is the worst and it is the
# paper's centrepiece: its rows carry EIGHT different ArcadeDB versions
# (dev0, dev3, dev5, dev6, dev20, dev21, dev22, dev23). T4 is the money table
# and it is currently a patchwork.
#
# SCOPE. ArcadeDB arms only. The comparators (Qdrant, Milvus, Elasticsearch) did
# not change engine, so they carry forward under the same argument used for the
# SciPy tables.
#
# THE F9 CONTROL IS DELIBERATELY NOT IN THIS QUEUE, and that is a gap, not an
# oversight. Carrying comparator rows forward is only evidenced if one untouched
# comparator is re-run and reproduces itself; that is what made the SciPy
# carry-forward defensible. Qdrant-sparse is a SERVER backend, and adding an
# untested server phase to an unattended four-hour queue is precisely how three
# runs were lost today. It gets its own script, attended, afterwards. Until then
# the sparse comparator rows are carried forward on argument alone.
#
# ORDER IS BY PAPER RISK, not duration. medium (8.84M) is the headline cell and
# is stuck at N=3, so it goes first and finishes even if the box is reclaimed
# early. Then the cheaper tiers.
#
# INVOCATION COPIED VERBATIM from queue60.sh, which is the last script known to
# have produced good sparse rows. Three failures today came from rebuilding a
# launch out of a partial read; the only intended differences here are the image
# tag (icde-bench -> dbbench, the current name) and the data path
# (~/icde-data -> ~/bench-data, which is where bigann lives now). Both verified
# before writing this.
set -u
OUT=~/q8
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "sparse-on-26.8.1 started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
PIN=26.8.1
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

guard() {
  # Never start a cell on a busy box: every number here is a published absolute.
  if docker ps --format '{{.Names}}' | grep -qvE '^$'; then
    log "  guard: containers present, waiting"
    for _ in $(seq 1 60); do
      docker ps -q | grep -q . || return 0
      sleep 30
    done
    log "  guard: still busy after 30 min, continuing anyway"
  fi
}

# F5 gate: what is INSTALLED, not what was asked for.
GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "$PIN" ] || { log "ABORT: image is not $PIN"; exit 1; }

# Contract check before any multi-hour build.
docker run --rm -v "$PWD:/work" -w /work dbbench:arcadedb python -c "
import l3_sparse as L
for k in ('arcadedb_sparse_embedded','arcadedb_sparse_embedded_fp32'):
    assert k in L.BACKENDS, k
print('sparse lane ok')
" 2>&1 | tee -a "$LOG" | grep -q "sparse lane ok" \
  || { log "ABORT: sparse lane contract changed"; exit 1; }

# One cell = one backend, one tier, one rep. Every -v belongs BEFORE the image
# name; a volume flag after it is passed to python instead of docker.
cell() {  # backend label scale heap mem rep
  local be=$1 label=$2 scale=$3 heap=$4 mem=$5 rep=$6
  local out="$OUT/${label}_${scale}_r${rep}.json"
  [ -s "$out" ] && { log "  skip ${label} ${scale} r${rep} (present)"; return; }
  guard
  local t0=$(date +%s)
  log "  START ${label} ${scale} r${rep} (heap $heap, mem $mem)"
  timeout 21600 docker run --rm --name "q8_${label}_${scale}_r${rep}" \
    --cpuset-cpus 0-11 --memory "$mem" --memory-swap "$mem" \
    -v "$PWD:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
    -e BENCH_SPARSE_SOURCE=bigann -e BENCH_SPARSE_DATA=/data/bigann \
    -e ARCADEDB_HEAP="$heap" -e BENCH_ROLE=engine \
    dbbench:arcadedb python -u l3_sparse.py --backend "$be" \
      --scale "$scale" --out "/out/${label}_${scale}_r${rep}.json" \
      > "$OUT/${label}_${scale}_r${rep}.log" 2>&1
  local rc=$? el=$(( $(date +%s) - t0 ))
  if [ -s "$out" ]; then
    log "  DONE  ${label} ${scale} r${rep} rc=$rc ${el}s"
  else
    log "  FAIL  ${label} ${scale} r${rep} rc=$rc ${el}s"
    tail -5 "$OUT/${label}_${scale}_r${rep}.log" >> "$LOG" 2>/dev/null
  fi
}

# ---- Phase A: medium = 8.84M, the headline cell stuck at N=3 --------------
log "PHASE A: medium (8.84M), both arms, N=5  [~18 min/rep, ~3 h]"
for rep in 1 2 3 4 5; do
  cell arcadedb_sparse_embedded      int8 medium 16g 32g "$rep"
  cell arcadedb_sparse_embedded_fp32 fp32 medium 16g 32g "$rep"
done

# ---- Phase B: small (1M) and tiny -----------------------------------------
log "PHASE B: small then tiny, both arms, N=5"
for spec in "small 8g 16g" "tiny 4g 8g"; do
  set -- $spec
  for rep in 1 2 3 4 5; do
    cell arcadedb_sparse_embedded      int8 "$1" "$2" "$3" "$rep"
    cell arcadedb_sparse_embedded_fp32 fp32 "$1" "$2" "$3" "$rep"
  done
done

# ---- Summary --------------------------------------------------------------
python3 - >> "$LOG" 2>&1 <<'PY'
import glob, json, os, statistics as st
print("\nSPARSE LANE on 26.8.1 (bigann, real SPLADE)")
print("  %-5s %-7s %2s %10s %9s %9s %8s" % ("arm","tier","N","build_s","p50_ms","p99_ms","recall"))
for scale in ("tiny","small","medium"):
    for arm in ("int8","fp32"):
        rows=[]
        for fp in sorted(glob.glob(os.path.expanduser(f"~/q8/{arm}_{scale}_r*.json"))):
            try: rows.append(json.load(open(fp)))
            except Exception: pass
        if not rows: continue
        g=lambda k: st.median([r[k] for r in rows if r.get(k) is not None])
        print("  %-5s %-7s %2d %10.1f %9.2f %9.2f %8.4f"
              % (arm, scale, len(rows), g("build_s"), g("query_p50_ms"),
                 g("query_p99_ms"), g("recall_at_10")))
        vs = {str(r.get("engine_version")) for r in rows}
        if len(vs) > 1: print("      MIXED VERSIONS:", vs)
PY

log "SPARSE-2681-COMPLETE"
