#!/bin/bash
# T4's ArcadeDB rows, re-measured whole on one line. Four caveats fall out.
#
# 1. N=3 AT 8.84M. T4's caption reads "N=5 except the 8.84M ArcadeDB row,
#    which is N=3". The two missing reps could never be added, because the
#    first three recorded no cpuset, heap or memory cap and reps under guessed
#    conditions are worse than an honest N=3. Re-measuring all five together
#    under a stated envelope is the only way out, and l3_sparse.py now stamps
#    conditions so this cannot recur.
#
# 2. NO CONDITIONS anywhere in the sparse overlay (the same defect, for every
#    tier). provenance_check has been reporting it for days.
#
# 3. FP32 ABLATION DEFERRED. The caption says "fp32 and server ablations are
#    deferred to re-measurement on the same line". The fp32 arm in the data is
#    dev0/dev3 era. This runs fp32 at all three tiers on dev23, beside int8,
#    which makes the ablation exist. (Server stays deferred; it needs a server
#    container per cell and is a separate job.)
#
# 4. VERSION. T4's ArcadeDB rows are dev22 while T5's are dev20/dev23 and the
#    prose talks about dev23 profiles. Fewer lines in one paper is better.
#
# ENVELOPE, matched per tier to what every comparator got in the campaign
# (read out of runs.jsonl, not guessed):
#     tiny   100k    heap 4g   mem 8g
#     small  1M      heap 8g   mem 16g
#     medium 8.84M   heap 16g  mem 32g
#   cpuset 0-11 throughout. Note this deliberately differs from q57's ad-hoc
#   20g cap: that run was an internally-consistent A/B, this one has to sit in
#   a table beside Qdrant, Milvus and Elasticsearch.
#
# Arms are interleaved within a tier, and tiers run smallest first so a
# contract or capacity failure shows up in minutes rather than after the
# 16-minute medium builds. Each cell is independent; a failure is logged and
# the run continues rather than losing the whole night.
#
# Expect roughly 4.5 h: tiny ~15 min, small ~40 min, medium ~3.5 h.
set -u
exec >> "$HOME/profiling/queue60.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
OUT=results/t4dev23
mkdir -p "$OUT"

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
[ -n "${VER:-}" ] || die "no engine version"
say "engine $VER  (T4 currently prints dev22)"

# Contract check before 4.5 hours of builds. queue39 lost 10/10 cells to a
# flag that did not exist; q51 lost 5/5 to a grep that never matched.
docker run --rm -v "$PWD:/work" -w /work -e BENCH_SPARSE_SOURCE=bigann \
  icde-bench:arcadedb python -c "
import l3_sparse as L
b = L.BACKENDS
for k in ('arcadedb_sparse_embedded', 'arcadedb_sparse_embedded_fp32'):
    assert k in b, 'backend missing: %s' % k
for s in ('tiny', 'small', 'medium'):
    assert s in L.SCALE_DOCS, 'scale missing: %s' % s
src = open('l3_sparse.py').read()
assert 'run_conditions' in src, 'conditions stamping not present in this checkout'
print('contract ok: arms + 3 tiers present, conditions stamping present')
print('  docs per tier:', {s: L.SCALE_DOCS[s] for s in ('tiny','small','medium')})
" || die "sparse lane contract changed"

run_cell() {  # $1 backend, $2 label, $3 scale, $4 heap, $5 mem, $6 rep
  local be=$1 label=$2 scale=$3 heap=$4 mem=$5 rep=$6
  local out="$OUT/${label}_${scale}_r${rep}.json"
  if [ -s "$out" ]; then say "$label $scale rep$rep already present, skipping"; return; fi
  guard
  timeout 21600 docker run --rm --name q60_${label}_${scale}_r${rep} \
    --cpuset-cpus 0-11 --memory "$mem" --memory-swap "$mem" \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_SPARSE_SOURCE=bigann -e BENCH_SPARSE_DATA=/data/bigann \
    -e ARCADEDB_HEAP="$heap" -e BENCH_ROLE=engine \
    icde-bench:arcadedb python -u l3_sparse.py --backend "$be" \
      --scale "$scale" --out "/work/$out" >/dev/null 2>&1 \
    && say "$label $scale rep$rep ok" || say "$label $scale rep$rep FAILED"
}

for spec in "tiny 4g 8g" "small 8g 16g" "medium 16g 32g"; do
  set -- $spec
  scale=$1 heap=$2 mem=$3
  say "--- tier $scale (heap $heap, mem $mem) ---"
  for rep in 1 2 3 4 5; do
    run_cell arcadedb_sparse_embedded      int8 "$scale" "$heap" "$mem" "$rep"
    run_cell arcadedb_sparse_embedded_fp32 fp32 "$scale" "$heap" "$mem" "$rep"
  done
done

say "=== result ==="
python3 - <<'PY'
import glob, json, statistics as st
print(f"  {'arm':5} {'tier':7} {'N':>2}  {'build_s':>9} {'p50_ms':>8} {'p99_ms':>8} "
      f"{'recall':>7}  conditions")
for scale in ("tiny", "small", "medium"):
    for arm in ("int8", "fp32"):
        rows = []
        for fp in sorted(glob.glob(f"results/t4dev23/{arm}_{scale}_r*.json")):
            try:
                rows.append(json.load(open(fp)))
            except Exception:
                pass
        if not rows:
            print(f"  {arm:5} {scale:7}  0  (no reps)")
            continue
        def m(k):
            v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
            return st.median(v) if v else float("nan")
        r0 = rows[0]
        print(f"  {arm:5} {scale:7} {len(rows):2}  {m('build_s'):9.1f} "
              f"{m('query_p50_ms'):8.2f} {m('query_p99_ms'):8.2f} "
              f"{m('recall_at_10'):7.4f}  cpuset={r0.get('cpuset')} "
              f"heap={r0.get('heap')} mem={r0.get('mem_cap')} "
              f"wheel={r0.get('wheel_version')}")
print("\n  T4 prints today (dev22, int8): tiny p50 3.98 / small 11.36 / medium 83.70 ms,")
print("  with the medium row at N=3. If the medium arm above reaches N=5, T4's")
print("  caption exception goes away; if fp32 completes at medium, so does the")
print("  'fp32 ablation deferred' sentence.")
PY
say "QUEUE60-DONE"
