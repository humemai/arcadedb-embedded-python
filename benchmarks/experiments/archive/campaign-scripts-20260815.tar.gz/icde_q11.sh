#!/bin/bash
# q11: TPC-H at SF10, chained behind q10.
#
# WHY. The venue survey (15 accepted ICDE industry papers) found DB/systems
# papers run TPC-H/TPC-DS at 700 GB to 1 TB. Ours is SF1 = 1 GB. A reviewer who
# sees SF1 discounts the whole tabular table regardless of what it says, and the
# sf10_*.parquet files have been sitting on this box the whole time.
#
# SF1 IS KEPT AS THE CONTROL, not replaced. q10 measures SF1 on 26.8.1; this
# measures SF10 on the same engine, same day, same box. Two scales on one
# version is a scaling claim; one scale swapped for another is just a moved
# goalpost.
#
# HONEST ABOUT WHAT THIS SHOWS: our L1 OLAP result is that ArcadeDB is far
# slower than DuckDB on analytics. SF10 makes that MORE visible, not less. It
# is still worth running: being beaten honestly at 10 GB reads better than
# looking like we picked a toy scale to hide behind.
set -u
OUT=~/q11
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q11 started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

# ---- wait for q10, WITH A HARD DEADLINE -----------------------------------
DEADLINE=$(( $(date +%s) + 20*3600 ))
log "waiting for Q17-COMPLETE (hard deadline 20 h)"
while ! grep -qa "Q17-COMPLETE" ~/q17/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then
    log "ABORT: q17 did not finish within 20 h; not starting on a busy box"
    exit 1
  fi
  # q10 can exit on its own abort paths without ever writing the marker.
  if grep -qa "ABORT:" ~/q17/queue.log 2>/dev/null; then
    log "q17 exited on an error path; not chaining behind it"
    exit 1
  fi
  sleep 60
done
log "q17 finished"
for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

# ---- environment, asserted (the defect that killed q9) --------------------
export BENCH_DATA=$HOME/bench-data
export BENCH_TPC_DATA=/data/tpch
export BENCH_TPC_SF=10
ls "$BENCH_DATA"/tpch/sf10_*.parquet >/dev/null 2>&1 \
  || { log "ABORT: no tpch sf10_*.parquet"; exit 1; }
grep -q '"tpch10"' runner.py || { log "ABORT: runner.py has no tpch10 tier"; exit 1; }
log "preflight ok: sf10 parquet present, tpch10 tier registered"

GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "26.8.1" ] || { log "ABORT: image is not 26.8.1"; exit 1; }

t0=$(date +%s)
log "START l1tpc tpch10 (SF10, ~10 GB)"
timeout 36000 python3 runner.py --lanes l1tpc --scale tpch10 \
    --backends "arcadedb_embedded,arcadedb_server,duckdb" \
    --reps 5 --tier paper --workers 0 > "$OUT/l1tpc_tpch10.log" 2>&1
rc=$?; el=$(( $(date +%s) - t0 ))
if [ $rc -eq 0 ]; then log "DONE  l1tpc tpch10 rc=$rc ${el}s"
else log "FAIL  l1tpc tpch10 rc=$rc ${el}s"; tail -20 "$OUT/l1tpc_tpch10.log" >> "$LOG"; fi

python3 - >> "$LOG" 2>&1 <<'PY'
import json, glob, os, collections, statistics as st
root = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments/results/raw")
g = collections.defaultdict(list)
for p in glob.glob(os.path.join(root, "*.json")):
    try: j = json.load(open(p))
    except Exception: continue
    if isinstance(j, dict) and j.get("lane") == "l1tpc":
        g[(j.get("scale"), j.get("backend"), j.get("workload"))].append(j)
print("\nq11: TPC-H SF1 (control) vs SF10")
print("  %-8s %-24s %-6s %2s %12s" % ("scale","backend","wl","N","p50_ms"))
for k in sorted(g, key=lambda x: (str(x[0]), str(x[2]), str(x[1]))):
    rs = g[k]
    v = [r["query_p50_ms"] for r in rs if r.get("query_p50_ms") is not None]
    if not v: continue
    print("  %-8s %-24s %-6s %2d %12.2f" % (k[0], k[1], k[2], len(v), st.median(v)))
PY

log "Q11-COMPLETE"
