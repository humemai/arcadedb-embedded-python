#!/bin/bash
# Re-measure the tabular bulk-ingest paths on mini, with provenance.
#
# Why: the paper prints "Bulk ingest through the bindings' batched path
# reaches 36.7k rows/s [36.5--39.5k]" and that number is not in any tracked
# result file, not in runs.jsonl, not in any overlay, and not in any log on
# this box. async_ingest_probe.py's own docstring says "Smoke on laptop;
# freeze numbers on mini", so the most likely story is that a laptop smoke
# reached the paper, which the protocol forbids: every printed number is
# measured here, serial, cpuset 0-11.
#
# So this does not try to confirm 36.7k. It measures the thing the sentence
# is about, on the right box, N=5, and records the conditions the overlays
# have never recorded (task #113) so the resulting cells can be reproduced
# and extended later. Whatever it says replaces the untraceable figure.
set -u
exec >> "$HOME/profiling/queue51.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue51 waiting for QUEUE50-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE50-DONE" "$HOME/profiling/queue50.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue50.sh" >/dev/null || { say "queue50 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
say "engine: ${VER:-UNKNOWN}"
[ -n "${VER:-}" ] || die "no engine version; refusing to record an unstamped result"

CPUSET=0-11
MEM=24g
HEAP=8g
ROWS=500000
DEST=results/ingest82
mkdir -p "$DEST"

# Contract check before the loop: the probe must still expose the four
# variants the paper's sentence talks about. queue39 died 10/10 on an
# argument that had been renamed, so check the surface, not the intent.
docker run --rm -v "$PWD:/work" -w /work icde-bench:arcadedb \
  python -c "import ast,sys;src=open('async_ingest_probe.py').read();
names={n.name for n in ast.walk(ast.parse(src)) if isinstance(n,ast.FunctionDef)}
need={'serial','async_path','insert_many_path','insert_many_parallel'}
missing=need-names
sys.exit('missing variants: %s' % missing if missing else 0)" \
  || die "async_ingest_probe.py no longer exposes the four variants"
say "contract ok: four ingest variants present"

ok=0
for r in 1 2 3 4 5; do
  guard
  say "rep $r starting (rows=$ROWS heap=$HEAP cpuset=$CPUSET)"
  raw=$(timeout 3600 docker run --rm --name ingest51_r$r \
        --cpuset-cpus $CPUSET --memory $MEM --memory-swap $MEM \
        -v "$PWD:/work" -w /work \
        -e PROBE_ROWS=$ROWS -e ARCADEDB_HEAP=$HEAP -e PROBE_DB_BASE=/tmp/p51 \
        icde-bench:arcadedb python -u async_ingest_probe.py 2>&1 \
        | grep -a '^RESULT ' | tail -1 | sed 's/^RESULT //')
  if [ -z "$raw" ]; then
    say "rep $r produced no RESULT line; not recording"
    continue
  fi
  # Stamp the conditions the overlays have never carried. This is the
  # pattern task #113 wants everywhere: the file says what produced it.
  python3 - "$raw" "$DEST/probe_r$r.json" <<PY
import json, sys
d = json.loads(sys.argv[1])
d.update({"engine_version": "$VER", "cpuset": "$CPUSET", "heap": "$HEAP",
          "mem_cap": "$MEM", "host": "mini", "tier": "paper",
          "lane": "l1ingest", "rep": $r, "n_rows": $ROWS})
json.dump(d, open(sys.argv[2], "w"), indent=1, sort_keys=True)
print("  " + " ".join(f"{k}={v['rows_per_s']}" for k, v in d.items()
                      if isinstance(v, dict) and "rows_per_s" in v))
PY
  ok=$((ok+1))
  say "rep $r recorded"
done

say "=== $ok/5 reps recorded ==="
python3 - <<'PY'
import glob, json, statistics as st
rows = [json.load(open(f)) for f in sorted(glob.glob("results/ingest82/probe_r*.json"))]
if not rows:
    print("  no reps")
else:
    variants = [k for k, v in rows[0].items()
                if isinstance(v, dict) and "rows_per_s" in v]
    print(f"  n={len(rows)} on {rows[0].get('engine_version')}")
    for v in variants:
        s = sorted(r[v]["rows_per_s"] for r in rows)
        okc = all(r[v].get("count_ok") for r in rows)
        print(f"    {v:22} median={st.median(s):10.1f} "
              f"[{min(s):.0f}--{max(s):.0f}]  count_ok={okc}")
    print("  paper says the batched path reaches 36.7k [36.5--39.5k];")
    print("  compare against insert_many / insert_many_parallel above.")
PY
say "QUEUE51-DONE"
