#!/bin/bash
# Measure the retained size of VectorLocationIndex, for ArcadeData/arcadedb#5588.
#
# Third attempt at the #5588 measurement, and the first with the right units.
#
# queue37 armed --live during the QUERY phase, but the location index is
# populated during the BUILD, so the instrument could not see it (211 weight,
# 0 B/vector; the analyzer's zero-check flagged it as "ask again").
#
# queue47 fixed the timing, arming before the build, and got a usable share but
# still not bytes: `-e alloc --live` alone reports SAMPLE COUNTS. Its output was
# 44 stacks totalling 1,024, of which 9.2% attributed to VectorLocationIndex.
# A share is not what the issue asks for.
#
# This run adds --total (weight by bytes rather than samples) and --alloc 64k
# (a fine enough interval that a 45-minute build yields real coverage rather
# than 44 stacks). That is the combination that can actually answer "measured
# heap per live vector".
#
# So: arm the profiler BEFORE the build and keep it running across it, then dump
# while the index is live. That is the only arrangement in which --live can see
# the structure the issue is about.
set -u
PROF=$HOME/profiling/async-profiler-4.0-linux-x64
OUT=$HOME/profiling/flame
exec >> "$HOME/profiling/queue50.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue50 waiting for QUEUE49-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE49-DONE" "$HOME/profiling/queue49.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue49.sh" >/dev/null || { say "queue49 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
say "engine: ${VER:-UNKNOWN}"

N=live50
docker rm -f $N >/dev/null 2>&1
guard
docker run -d --name $N --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
  -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
  -v "$PROF:/prof:ro" -v "$OUT:/pout" \
  -e MODE=dense -e PROFILE_SECS=300 \
  -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 -e ARCADEDB_HEAP=24g \
  icde-bench:arcadedb python -u profile_query_driver.py >/dev/null \
  || die "container failed to start"

# Arm as early as the JVM allows, so the build's allocations are observed.
sleep 45
docker exec $N /prof/bin/asprof start -e alloc --live --total --alloc 64k 1 >/dev/null 2>&1 \
  || { docker rm -f $N >/dev/null 2>&1; die "asprof start (alloc --live) failed"; }
say "live profiler armed before the build (byte-weighted, 64k interval)"

# Ride through the whole build (~45 min) and into the query phase.
ready=0
for i in $(seq 1 480); do
  docker logs $N 2>&1 | grep -qa "QUERY-PHASE-START" && { ready=1; break; }
  docker ps -q -f name=$N | grep -q . || { say "DIED during build"; docker logs $N 2>&1 | tail -6; break; }
  sleep 15
done
[ $ready -eq 1 ] || { docker rm -f $N >/dev/null 2>&1; die "never reached the query phase"; }
say "build finished with the profiler still running; dumping while the index is live"
sleep 30
docker exec $N /prof/bin/asprof stop -o collapsed \
  -f "/pout/dense_livebytes_${VER}.collapsed" 1 >/dev/null 2>&1 \
  && say "live-across-build profile written" || say "asprof stop FAILED"
docker rm -f $N >/dev/null 2>&1

say "=== retained by owner ==="
python3 - <<PYEOF
import collections, glob
fs = sorted(glob.glob("/home/tk/profiling/flame/dense_livebytes_*.collapsed"))
if not fs:
    print("  no profile"); raise SystemExit
p = fs[-1]
tot = 0; owned = collections.Counter()
OWNERS = [("VectorLocationIndex", "location index (#5588)"),
          ("VectorCache", "shared search cache"),
          ("jbellis/jvector", "JVector internals"),
          ("com/arcadedb/index/vector", "other ArcadeDB vector"),
          ("com/arcadedb/engine", "page/storage")]
for line in open(p, errors="ignore"):
    st, _, w = line.rpartition(" ")
    try: w = int(w)
    except ValueError: continue
    tot += w
    for needle, label in OWNERS:
        if needle in st: owned[label] += w; break
    else: owned["(unattributed)"] += w
print(f"  total BYTES {tot:,} ({tot/2**20:,.0f} MiB)")
N = 9990000
for lab, w in owned.most_common():
    print(f"    {100*w/tot:5.1f}%  {w:>14,}  {lab:28s} {w/N:7.1f} B/vector")
loc = owned.get("location index (#5588)", 0)
print(f"\n  #5588: {loc/N:.1f} B per live vector, against ~90 B estimated in the issue")
if loc == 0:
    print("  *** STILL ZERO: --live across the build did not see it either. Do not "
          "report a number; report that this instrument cannot answer it. ***")
PYEOF
say "QUEUE47-DONE"
