#!/bin/bash
# q20: re-measure the native time-series probe on the RELEASE.
#
# WHY. A version sweep found exactly one published cell still measured on a
# pre-release wheel: T5's time-series ArcadeDB row, whose artifacts (ts59) are
# 26.8.1.dev23. Everything else -- sparse_2681, dense_mp_2681, and every lane
# in runs.jsonl -- is on 26.8.1. The paper names one version, so this row
# cannot ship as measured. make_paper_tables now prints a refusal naming it on
# every run; this is the run that clears it.
#
# WHY IT IS NOT JUST queue59 RE-RUN. queue59 did two things that no longer
# hold: it cd'd into ~/repos/humemai/arcadedb-icde/paper-icde/experiments (the
# pre-consolidation path) and it ran `icde-bench:arcadedb`, which is the image
# carrying dev23. The current image is dbbench:arcadedb at 26.8.1 and the
# corpus moved from ~/icde-data to ~/bench-data. Copying the old script
# verbatim would have re-measured dev23 and looked like it worked.
#
# PROTOCOL IS queue59's, unchanged, because the comparators in T5's TS block
# are not being re-run and F4 says the protocol belongs to the lane: same
# cpuset, same 20g cap, same 8g heap, same env, same NOSETTLE arm (settle_s=0),
# same probe. Only the engine and the paths move.
set -u
OUT=$HOME/q20
mkdir -p "$OUT"
LOG=$OUT/queue.log
EXP=$HOME/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
RES=$EXP/results/ts_2681
LP=$HOME/bench-data/tsbs/cpu_influx.lp
IMG=dbbench:arcadedb

log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
die() { log "ABORT: $*"; exit 1; }

log "q20 started, pid $$"

# ---- wait for q19, with a HARD deadline -----------------------------------
# q19 has a 12h internal timeout, so 13h here can only be reached if q19 died
# in a way that left no marker. Never wait forever: a chained job with no
# deadline is a job that silently never runs.
DEADLINE=$(( $(date +%s) + 13*3600 ))
if [ -f "$HOME/q19/queue.log" ]; then
  while ! grep -q "Q19-COMPLETE" "$HOME/q19/queue.log" 2>/dev/null; do
    [ "$(date +%s)" -ge "$DEADLINE" ] && die "q19 never signalled completion in 13h"
    sleep 60
  done
  log "q19 complete"
fi
# and wait for the machine to actually be idle, so F2 (serial) holds
while [ "$(docker ps -q | wc -l)" -gt 0 ]; do
  [ "$(date +%s)" -ge "$DEADLINE" ] && die "containers still running at deadline"
  sleep 30
done
log "host idle"

# ---- gates ----------------------------------------------------------------
[ -s "$LP" ] || die "no TSBS corpus at $LP"
log "corpus $(du -h "$LP" | cut -f1) at $LP"

VER=$(docker run --rm "$IMG" python -m pip show arcadedb-embedded 2>/dev/null \
      | awk '/^Version:/{print $2}')
[ -n "${VER:-}" ] || die "could not read engine version from $IMG"
case "$VER" in
  *.dev*) die "F5: $IMG is $VER, a pre-release. The whole point of this run is
          to get OFF a pre-release; measuring another one would replace one
          unpublishable row with a different unpublishable row." ;;
esac
log "F5 gate: $IMG is $VER"

mkdir -p "$RES"

# ---- the arm --------------------------------------------------------------
run_rep() {
  local rep=$1
  while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 20; done
  timeout 3600 docker run --rm --name ts2681_nosettle_r${rep} \
    --cpuset-cpus 0-11 --memory 20g --memory-swap 20g \
    -v "$EXP:/work" -w /work -v "$HOME/bench-data:/data:ro" \
    -e TSBS_LP=/data/tsbs/cpu_influx.lp \
    -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=1 \
    -e TS_SETTLE_S=0 -e TS_LAST_AB=1 \
    -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
    -e PROBE_OUT="/work/results/ts_2681/nosettle_r${rep}.json" \
    "$IMG" python -u l4_native_probe.py >"$OUT/rep${rep}.log" 2>&1 \
    && log "nosettle rep$rep ok" || log "nosettle rep$rep FAILED (see rep${rep}.log)"
}

for rep in 1 2 3 4 5; do run_rep "$rep"; done

# ---- acceptance -----------------------------------------------------------
# rc=0 is not the acceptance test. The row is only usable if it landed AND it
# is on the release, so check the artifact rather than the exit status.
log "=== result ==="
python3 - "$RES" <<'PY' 2>&1 | tee -a "$LOG"
import json, glob, os, statistics as st, sys
d = sys.argv[1]
rows = []
for fp in sorted(glob.glob(os.path.join(d, "nosettle_r*.json"))):
    try:
        rows.append(json.load(open(fp)))
    except Exception as e:
        print("  unreadable", os.path.basename(fp), e)
if not rows:
    print("  NO ROWS. The tier is still unmeasured; T5's time-series row stays")
    print("  on the pre-release wheel and must not be reported.")
    raise SystemExit(0)
vers = sorted({str(r.get("engine_version")) for r in rows})
print("  reps=%d  versions=%s" % (len(rows), vers))
if any(".dev" in v for v in vers):
    print("  REJECT: still pre-release. Do not fold into T5.")
    raise SystemExit(0)
for f in ("ingest_pts_per_s", "q_last_unbounded_ms", "q_range_ms", "q_global_ms"):
    v = [r[f] for r in rows if isinstance(r.get(f), (int, float))]
    if v:
        print("  %-22s median=%.6g  [%.6g -- %.6g]  n=%d"
              % (f, st.median(v), min(v), max(v), len(v)))
print("  Compare against results/ts59 (dev23) before folding: a large move is")
print("  an engine change to report, not a number to swap in quietly.")
PY

log "Q20-COMPLETE"
