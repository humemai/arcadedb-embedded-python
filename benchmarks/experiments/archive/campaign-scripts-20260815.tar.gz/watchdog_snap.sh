#!/bin/bash
# One-line health snapshot of the mini chain. Printed fields are chosen so that
# a stalled or wedged chain changes NOTHING between polls, while healthy work
# always changes something (log lines grow, or a DONE marker appears).
set -u
Q="34 35 36 39 37 38 40 41 42 43 44 45 46 47 48 49 50"

C=$(docker ps --format '{{.Names}}' | head -1)
if [ -n "$C" ]; then
  LINES=$(docker logs "$C" 2>&1 | wc -l)
  CPU=$(docker stats --no-stream --format '{{.CPUPerc}}' "$C" 2>/dev/null | tr -d '%' | cut -d. -f1)
  [ -z "$CPU" ] && CPU=0
else
  C=NONE; LINES=0; CPU=0
fi

# Alive queue scripts, excluding the forked sampler subshells (same cmdline as
# their parent), so a normal fork does not read as a new job.
ALIVE=$(pgrep -f 'bash \./queue[0-9]+\.sh' 2>/dev/null | while read -r p; do
          [ "$(ps -o ppid= -p "$p" | tr -d ' ')" = "1" ] && echo "$p"; done | wc -l)

DONE=""
for q in $Q; do
  f=$HOME/profiling/queue$q.log
  [ -f "$f" ] && grep -qa "QUEUE${q}-DONE" "$f" && DONE="$DONE$q,"
done

# Total bytes across all chain logs: grows whenever any queue writes anything,
# including a queue that is waiting and logging nothing (it will not grow, which
# is the point).
LOGB=$(cat $HOME/profiling/queue[0-9]*.log 2>/dev/null | wc -c)

DISK=$(df --output=pcent "$HOME" | tail -1 | tr -dc '0-9')
MEMFREE=$(free -g | awk '/^Mem:/{print $7}')

echo "c=$C lines=$LINES cpu=$CPU alive=$ALIVE done=${DONE:-none} logb=$LOGB disk=${DISK}% memfree=${MEMFREE}G"
