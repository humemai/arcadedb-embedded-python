#!/bin/bash
# queue69: close #121 -- the dense comparators were never re-measured at 36g.
#
# THE FINDING. T5's dense block runs ArcadeDB under 36g/24g and every
# comparator under 28g/16g. The envelope was raised on 2026-07-20 for
# ArcadeDB's degree-matched configuration and no comparator was re-run.
#
# MOST OF IT IS ANSWERABLE WITHOUT MEASURING, from peak_anon_mib_sum in
# runs.jsonl. Five of six comparators never came close to their ceiling:
#
#   backend            peak anon   of 28g    can 36g help?
#   qdrant_dense         5.97 GiB   21.3%    no
#   sqlite_vec_dense     7.20 GiB   25.7%    no
#   milvus_dense        10.75 GiB   38.4%    no
#   chroma_dense        12.66 GiB   45.2%    no
#   lancedb_dense       13.81 GiB   49.3%    no
#   duckdb_vss_dense    25.16 GiB   89.8%    PLAUSIBLY YES
#
# and for context ArcadeDB at 36g peaked at 28.30 GiB, which does not fit
# inside the comparators' 28 GiB cap at all. So the envelope was not slack we
# granted ourselves and did not use; it is what the matched-degree
# configuration actually needs.
#
# That leaves exactly ONE open question: does DuckDB-VSS, at 89.8% of its
# cap, behave differently with room? Everything else here is a cheap
# confirmation of what the memory data already says.
#
# SCOPE, and why it is not all six. qdrant and milvus are client_server
# topologies needing a second container, and they are the two LEAST likely to
# be affected (21% and 38%). Running them would cost orchestration to confirm
# what their own peak memory already shows. Stated here rather than silently
# dropped, per the no-silent-caps rule.
#
# ORDER is by evidence-of-need, not convenience, so a partial night still
# answers the question that matters:
#   duckdb_vss (89.8%, 805s build)  <- THE question
#   lancedb    (49.3%, 227s)
#   sqlite_vec (25.7%,  70s)
#   chroma     (45.2%, 3678s)       <- expensive, last, budget-guarded
#
# CHAINED behind queue68 with a HARD DEADLINE.
set -u
OUT=$HOME/q69
WORK=$HOME/q69work
mkdir -p "$OUT" "$WORK/out"
say(){ echo "[$(date +%T)] $*"; }

say "queue69 waiting for QUEUE68-DONE (hard deadline 8h)"
for i in $(seq 1 480); do
  grep -qa "QUEUE69-SKIP-WAIT" "$OUT/override" 2>/dev/null && { say "override"; break; }
  grep -qa "QUEUE68-DONE" ~/queue68.log 2>/dev/null && { say "q68 finished"; break; }
  if grep -qa "DEADLINE:\|GUARD:\|not staged\|NO RESULT FILES" ~/queue68.log 2>/dev/null; then
    say "q68 exited on an error path; proceeding once mini is idle"; break
  fi
  if [ "$i" -eq 480 ]; then say "DEADLINE: q68 did not finish in 8h; NOT starting"; exit 1; fi
  sleep 60
done

n=$(docker ps -q | wc -l)
[ "$n" -eq 0 ] || { say "GUARD: $n container(s) still running, refusing to co-run"; exit 1; }

cd "$WORK" || { say "no $WORK staging dir"; exit 1; }
for f in l3d_dense.py bench_common.py; do
  [ -f "$f" ] || { say "$f not staged in $WORK"; exit 1; }
done

# 36g/24g: ArcadeDB's envelope, which is the whole point. cpuset 0-11 and the
# dev23-era dense image, so the ONLY thing that differs from the published 28g
# rows is the cap.
CPUS=0-11
MEM=36g
START=$(date +%s)
BUDGET=$(( 10 * 3600 ))   # leave the box free by morning

run_be() {  # $1=backend $2=rep
  local be=$1 rep=$2
  timeout 7200 docker run --rm --name q69_${be}_r${rep} \
    --cpuset-cpus $CPUS --memory $MEM --memory-swap $MEM \
    -v "$WORK:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_HOST=mini -e BENCH_ROLE=engine \
    -e ARCADEDB_HEAP=24g \
    icde-bench:dense python -u l3d_dense.py \
      --backend "$be" --scale deep10m --out "/work/out/${be}_36g_r${rep}.json" \
    >>"$OUT/${be}_r${rep}.log" 2>&1
}

# COMPARATOR_M lands at 16 (M//2 of the default 32), which is exactly the m=16
# every published comparator row records. So these rows are directly
# comparable to the 28g ones and differ only in the cap. That is also a live
# check of today's degree-unit fix: if a comparator's recall moves, the fix
# changed the configuration and the run is telling us so.
say "dense comparators at ${MEM} (published rows are 28g), cpuset $CPUS, N=5"
for be in duckdb_vss_dense lancedb_dense sqlite_vec_dense chroma_dense; do
  el=$(( $(date +%s) - START ))
  if [ "$el" -gt "$BUDGET" ]; then
    say "BUDGET: ${el}s elapsed, SKIPPING $be and everything after it"
    say "  (not a silent cap: this backend has no 36g rows and must not be"
    say "   compared against one until it does)"
    break
  fi
  say "--- $be ---"
  for rep in 1 2 3 4 5; do
    run_be "$be" "$rep" && say "  $be rep$rep ok" || say "  $be rep$rep FAILED"
  done
done

cp -r "$WORK/out" "$OUT/results" 2>/dev/null

say "=== 36g vs the published 28g rows ==="
python3 - <<'PY'
import glob, json, os, statistics as st, collections
d = os.path.expanduser("~/q69work/out")
files = sorted(glob.glob(os.path.join(d, "*_36g_r*.json")))
if not files:
    print("  NO RESULT FILES. Do not report a number."); raise SystemExit

# The published 28g medians, from runs.jsonl, pasted so this prints a
# comparison even though mini's checkout is not the source of truth.
PUB28 = {
    "duckdb_vss_dense": (805.2, 2.533, 0.9363, 25.16),
    "lancedb_dense":    (226.6, 2.724, 0.7067, 13.81),
    "sqlite_vec_dense":  (70.3, 882.351, 1.0000, 7.20),
    "chroma_dense":    (3678.5, 0.686, 0.9337, 12.66),
}
g = collections.defaultdict(list)
for fp in files:
    try: r = json.load(open(fp))
    except Exception: continue
    g[r.get("backend", os.path.basename(fp).split("_36g")[0])].append(r)

print(f"  {'backend':<20}{'n':>2} {'build_s':>19} {'p50_ms':>19} {'recall':>17}")
for be, rows in sorted(g.items()):
    def m(k):
        v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
        return st.median(v) if v else float("nan")
    b28, p28, r28, _ = PUB28.get(be, (float("nan"),)*4)
    b, p, rc = m("build_s"), m("query_p50_ms"), m("recall_at_10")
    def d(new, old):
        return f"{new:.3f} ({new/old:+.2f}x)" if old else f"{new:.3f}"
    print(f"  {be:<20}{len(rows):>2} {b:>9.1f} vs {b28:<7.1f} "
          f"{p:>8.3f} vs {p28:<8.3f} {rc:>7.4f} vs {r28:<7.4f}")

print("\n  READ IT THIS WAY:")
print("  * duckdb_vss is the test. At 28g it peaked at 89.8% of its cap, so")
print("    it is the one comparator with a real chance of being constrained.")
print("    A material improvement means T5's dense block understates it and")
print("    the row must be replaced with the 36g measurement.")
print("  * The other three peaked at 26-49% of 28g. They should NOT move.")
print("    If one does, the memory instrument is not measuring what we think")
print("    it measures, which is a bigger problem than the envelope.")
print("  * RECALL should not move for anyone. It is the control: recall is")
print("    set by degree and ef, not by the cap. A recall change means")
print("    today's COMPARATOR_M split altered the configuration rather than")
print("    preserving it, and this run is the thing that catches that.")
PY
say "QUEUE69-DONE"
