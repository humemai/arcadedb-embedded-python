#!/bin/bash
# F6 audit, done to the standard the DuckDB finding established.
#
# queue64 asked each CLIENT LIBRARY what it saw (os.sched_getaffinity in the
# driver container) and concluded the comparators were fine. That answers a
# different question: the driver's view says nothing about how many threads the
# ENGINE started. DuckDB was only caught because the probe happened to print
# PRAGMA threads, which is an engine-side setting.
#
# So ask each engine two ways:
#   A. its own reported setting, where it has one
#   B. GROUND TRUTH: OS threads the server process actually started, from
#      /proc/<pid>/task. A runtime cannot misreport this.
#
# Everything runs pinned to 0-11 (12 CPUs) on a 20-CPU host, so any pool sized
# near 20 is host-derived and any near 12 honours the cpuset.
set -u
CPUSET=0-11
EXPECT=12
say(){ echo "[$(date +%T)] $*"; }
hr(){ echo "------------------------------------------------------------"; }

threads_of(){   # $1=container  $2=process comm to match
  docker exec "$1" sh -c '
    for p in /proc/[0-9]*; do
      c=$(cat $p/comm 2>/dev/null) || continue
      case "$c" in '"$2"'*) echo "$(ls $p/task 2>/dev/null | wc -l)";; esac
    done' 2>/dev/null | sort -rn | head -1
}
names_of(){
  docker exec "$1" sh -c 'for t in /proc/[0-9]*/task/*/comm; do cat $t 2>/dev/null; done' 2>/dev/null \
    | sort | uniq -c | sort -rn | head -6 | sed 's/^/      /'
}
verdict(){  # $1=label $2=count
  local n="$2"
  if [ -z "$n" ]; then echo "    $1: (could not read)"; return; fi
  if [ "$n" -le $((EXPECT + 4)) ]; then echo "    $1: $n  -> consistent with the cpuset"
  else echo "    $1: $n  *** exceeds cpuset ($EXPECT); host-derived, like DuckDB ***"; fi
}

say "F6 sweep: what each ENGINE starts, pinned to $CPUSET ($EXPECT CPUs)"
hr

# ---------- embedded engines (in-process; ask the library) ----------
say "EMBEDDED (in the driver process, so pool == process threads)"
docker run --rm --cpuset-cpus $CPUSET icde-bench:dense python - <<'PY' 2>/dev/null
import os, threading
print(f"    affinity seen by the process: {len(os.sched_getaffinity(0))}")
for mod, probe in [
    ("duckdb",  lambda m: m.connect().execute("SELECT current_setting('threads')").fetchone()[0]),
    ("lancedb", lambda m: os.environ.get("LANCE_IO_THREADS", "(unset; uses default)")),
    ("chromadb",lambda m: "n/a (no thread setting exposed)"),
    ("sqlite_vec", lambda m: "n/a (single-threaded ext)"),
]:
    try:
        m = __import__(mod)
        print(f"    {mod:<12} {probe(m)}")
    except Exception as e:
        print(f"    {mod:<12} ({e.__class__.__name__})")
PY
hr

# ---------- served engines: count real OS threads ----------
run_served(){   # $1=name $2=image $3=comm-prefix $4=extra docker args...
  local name=$1 image=$2 comm=$3; shift 3
  say "SERVED: $name"
  docker rm -f f6probe >/dev/null 2>&1
  if ! docker run -d --name f6probe --cpuset-cpus $CPUSET --memory 8g "$@" "$image" >/dev/null 2>&1; then
    echo "    (failed to start)"; return
  fi
  sleep 18
  verdict "$name OS threads" "$(threads_of f6probe "$comm")"
  echo "    top thread names:"; names_of f6probe
  docker rm -f f6probe >/dev/null 2>&1
  hr
}

run_served elasticsearch "docker.elastic.co/elasticsearch/elasticsearch@sha256:268f65f1b32ea367e49c9be2acab144011b8c66c462c890f6190707743199050" java -e discovery.type=single-node -e xpack.security.enabled=false
run_served neo4j         "neo4j@sha256:4bae36aff76271e27fd6a6ed0835413f86a284cd179cfb1cb7d188f5f7533aca" java -e NEO4J_AUTH=none
run_served milvus        "milvusdb/milvus@sha256:0ea40276f8111f0183e72c8ee3144f3b9aafcd30571bd947de1ed0d22ee9dd56" milvus -e DEPLOY_MODE=STANDALONE

say "F6-SWEEP-DONE"
