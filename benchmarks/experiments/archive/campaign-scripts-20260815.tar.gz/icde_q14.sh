#!/bin/bash
# q14: re-run the WHOLE l4 block with a readiness probe that works.
#
# WHY THE WHOLE BLOCK, not just questdb. l4's protocol rotates the starting arm
# each rep so no engine inherits another's warm page cache. Measuring questdb
# alone later would hand it a cold machine to itself and break the one property
# the rotation exists to guarantee. Four arms together or not at all.
#
# WHAT WENT WRONG IN q10. Its questdb readiness was
#     docker exec q10quest sh -c 'nc -z 127.0.0.1 8812'
# copied from queue68 on the belief that queue68 was known-good. queue68 IS the
# script T5's other three time-series rows came from, but grep its log:
#     questdb rep1 NEVER-READY / rep2 NEVER-READY / rep3 NEVER-READY
# the questdb arm never worked there either. The container stayed up through all
# 60 retries, so it is not a startup failure: `nc` is not in the questdb image.
# Same shape as the arcadedb release image having no curl, found two hours ago.
#
# THE LESSON, recorded because it cost a lane: "copied from a known-good script"
# is only worth anything if the SPECIFIC CODE PATH succeeded there. Verify the
# arm, not the file.
#
# THE FIX depends on nothing inside either image: publish pg-wire on an ephemeral
# host port and let the host's python open a TCP socket to it. No nc, no psycopg,
# no client container. queue71 proved pg-wire does come up (10/10 arms) using an
# external connect; this is the same idea with one fewer dependency.
set -u
OUT=~/q14
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q14 started, pid $$"
ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments

DEADLINE=$(( $(date +%s) + 24*3600 ))
log "waiting for Q13-COMPLETE (hard deadline 24 h)"
while ! grep -qa "Q13-COMPLETE" ~/q13/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then log "ABORT: q13 unfinished after 24 h"; exit 1; fi
  grep -qa "ABORT:" ~/q13/queue.log 2>/dev/null && { log "q13 exited on an error path"; exit 1; }
  sleep 60
done
log "q13 finished"
for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "26.8.1" ] || { log "ABORT: image is not 26.8.1"; exit 1; }
[ -f "$HOME/bench-data/tsbs/cpu_influx.lp" ] || { log "ABORT: no tsbs corpus"; exit 1; }

CPUS=0-11; MEM=20g; NET=q14net
docker network rm $NET >/dev/null 2>&1; docker network create $NET >/dev/null 2>&1
COMMON="--cpuset-cpus $CPUS --memory $MEM --memory-swap $MEM
        -v $ICDE:/work -w /work -v $HOME/bench-data:/data:ro -v $OUT:/out
        -e TSBS_LP=/data/tsbs/cpu_influx.lp -e BENCH_HOST=mini"

quest_ready() {  # $1 = host port
  python3 -c "
import socket, sys, time
for _ in range(90):
    try:
        s = socket.create_connection(('127.0.0.1', $1), timeout=3); s.close(); sys.exit(0)
    except Exception:
        time.sleep(2)
sys.exit(1)" >/dev/null 2>&1
}

run_doc() {  # backend rep
  local be=$1 rep=$2 img extra=""
  case "$be" in
    arcadedb) img=dbbench:arcadedb; extra="-e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine" ;;
    duckdb)   img=dbbench:duckdb;   extra="-e BENCH_ROLE=engine" ;;
    questdb)  img=dbbench:client;   extra="-e BENCH_ROLE=driver -e QUEST_HOST=q14quest" ;;
  esac
  if [ "$be" = questdb ]; then
    docker rm -f q14quest >/dev/null 2>&1
    docker run -d --name q14quest --network $NET --network-alias q14quest \
      -p 0:8812 --cpuset-cpus $CPUS --memory $MEM --memory-swap $MEM \
      questdb/questdb:9.1.1 >/dev/null 2>&1
    local hp
    hp=$(docker port q14quest 8812/tcp | head -1 | sed 's/.*://')
    if [ -z "$hp" ] || ! quest_ready "$hp"; then
      log "    questdb rep$rep NEVER-READY (host port '${hp:-none}')"
      docker logs q14quest 2>&1 | tail -8 >> "$LOG"
      docker rm -f q14quest >/dev/null 2>&1; return 1
    fi
  fi
  timeout 3600 docker run --rm --name q14_${be}_r${rep} --network $NET \
    $COMMON $extra $img \
    python -u l4_tsbs.py --backend "$be" --out "/out/${be}_r${rep}.json" \
    >>"$OUT/l4_${be}_r${rep}.log" 2>&1
  local rc=$?
  [ "$be" = questdb ] && docker rm -f q14quest >/dev/null 2>&1
  return $rc
}

run_native() {  # rep
  timeout 3600 docker run --rm --name q14_native_r${1} $COMMON \
    -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=1 \
    -e TS_SETTLE_S=0 -e TS_LAST_AB=1 \
    -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
    -e PROBE_OUT="/out/native_r${1}.json" \
    dbbench:arcadedb python -u l4_native_probe.py >>"$OUT/l4_native_r${1}.log" 2>&1
}

ARMS=(arcadedb duckdb questdb native)
for rep in 1 2 3 4 5; do
  off=$(( (rep - 1) % 4 )); order=()
  for k in 0 1 2 3; do order+=("${ARMS[$(( (off + k) % 4 ))]}"); done
  log "  rep$rep order: ${order[*]}"
  for be in "${order[@]}"; do
    if [ "$be" = native ]; then
      run_native "$rep" && log "    native   rep$rep ok" || log "    native   rep$rep FAILED"
    else
      run_doc "$be" "$rep" && log "    ${be} rep$rep ok" || log "    ${be} rep$rep FAILED"
    fi
  done
done
docker network rm $NET >/dev/null 2>&1

python3 - >> "$LOG" 2>&1 <<'PY'
import glob, json, os, collections, statistics as st
g = collections.defaultdict(list)
for p in sorted(glob.glob(os.path.expanduser("~/q14/*_r*.json"))):
    try: r = json.load(open(p))
    except Exception: continue
    g[r.get("backend") or os.path.basename(p).split("_r")[0]].append(r)
print("\nq14: L4 on the release, all four arms, rotation intact")
print("  %-12s %2s %14s %10s %10s %12s" % ("arm","N","ingest_pts_s","last_ms","1h_ms","12h_ms"))
def med(rs,k):
    v=[r[k] for r in rs if isinstance(r.get(k),(int,float))]
    return st.median(v) if v else float("nan")
for a in sorted(g):
    rs=g[a]
    print("  %-12s %2d %14.0f %10.2f %10.2f %12.2f" % (a, len(rs),
          med(rs,"ingest_pts_per_s"), med(rs,"q_last_ms"),
          med(rs,"q_range_ms"), med(rs,"q_global_ms")))
print("\n  T5 today: native 1.92M/0.690/4.31/29.86  doc 31.3k/0.520/4.80/1.8k")
print("            duckdb 1.94M/1.40/1.28/4.57      questdb 431.3k/0.850/0.770/2.22")
print("  questdb's row has never been re-measured by us: queue68's arm always")
print("  failed and q10's inherited that bug. This is its first real re-run.")
PY
log "Q14-COMPLETE"
