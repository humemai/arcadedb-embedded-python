#!/bin/bash
# q74: retry of q73 (#124). Three fp32 DEEP-10M builds, one cold pass each.
#
# q73 burned 2h15m and produced nothing because PROBE_OUT was built as
# "/work/$out" where $out was ALREADY an absolute host path, giving
# /work//home/tk/q73/... which does not exist inside the container. All three
# builds SUCCEEDED and were discarded at the final write. q62 got this right by
# keeping the path relative to the mounted working directory; I changed it to an
# absolute path and broke it.
#
# The fix is one line. The guard is the important part: a five-second container
# now proves the output path is writable BEFORE committing 45 minutes to a build.
set -u
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || exit 1
REL=results/q74            # relative to the mount, never absolute
OUT=$HOME/q74; mkdir -p "$OUT" "$REL"
say(){ echo "[$(date +%T)] $*"; }
die(){ say "FATAL: $*"; exit 1; }

for i in $(seq 1 480); do
  n=$(docker ps -q | wc -l); [ "$n" -eq 0 ] && break
  [ "$i" -eq 1 ] && say "waiting for idle ($n container(s))"
  [ "$i" -eq 480 ] && die "busy 8h"
  sleep 60
done
say "mini idle"

# PRE-FLIGHT: prove the container can write where we will ask it to write.
docker run --rm -v "$PWD:/work" -w /work icde-bench:arcadedb \
  python -c "open(\"/work/$REL/.probe\",\"w\").write(\"ok\")" \
  || die "container cannot write /work/$REL - fix the path, do not start a build"
rm -f "$REL/.probe"
say "pre-flight ok: /work/$REL is writable"

[ -f dense_multipass_driver.py ] || die "driver missing"
VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk "/^Version:/{print \$2}")
say "engine $VER"

for rep in 1 2 3; do
  rel="$REL/mp_fp32_r${rep}.json"
  [ -s "$rel" ] && { say "rep$rep present"; continue; }
  say "rep$rep building (~45 min)"
  timeout 43200 docker run --rm --name q74_r${rep} \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_DENSE_QUANT="" -e ARCADEDB_HEAP=24g \
    -e BENCH_MP_BACKEND=arcadedb_dense_embedded -e BENCH_MP_SCALE=deep10m \
    -e BENCH_ROLE=engine -e BENCH_HOST=mini -e PROBE_OUT="/work/$rel" \
    icde-bench:arcadedb python -u dense_multipass_driver.py > "$OUT/r${rep}.log" 2>&1 \
    && { say "rep$rep ok"; cp "$rel" "$OUT/"; } || say "rep$rep FAILED rc=$?"
done

say "=== cold pass, three independent builds ==="
python3 - <<"PY"
import glob, json, os, statistics as st
cold, warm = [], []
for fp in sorted(glob.glob(os.path.expanduser("~/q74/mp_fp32_r*.json"))):
    try: d = json.load(open(fp))
    except Exception: continue
    reps = d if isinstance(d, list) else d.get("reps", [])
    c = [r["p50"] for r in reps if r.get("rep") == 1]
    w = [r["p50"] for r in reps if r.get("rep", 0) >= 2]
    if c: cold.append(c[0])
    if w: warm.append(st.median(w))
if not cold:
    print("  NO COLD SAMPLES. Report nothing."); raise SystemExit
print(f"  n={len(cold)}")
print(f"  cold median {st.median(cold):7.3f}   all {[round(x,3) for x in cold]}")
if warm: print(f"  warm median {st.median(warm):7.3f}   all {[round(x,3) for x in warm]}")
print()
print("  T5 says 4.424 (dev20, one sample). q62 said 8.172 (dev23, one sample).")
print("  Three clustered values replace both. Values spanning both mean the cold")
print("  pass is not a stable measurement and should not be reported as one number.")
PY
say "QUEUE74-DONE"
