#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "M32-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "M32-ABORT foreign"; exit 1; }
echo "=== degree-matched arcade dense N=5 (M=32) $(date -u +%FT%TZ) ==="
BENCH_DENSE_M=32 BENCH_DENSE_DATA=/data/dense BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l3d --scale deep10m --reps 5 --tier sweep --workers 1 \
  --backends arcadedb_dense_embedded,arcadedb_dense_server
echo "rc=$?"
echo "M32-FILL-COMPLETE"
