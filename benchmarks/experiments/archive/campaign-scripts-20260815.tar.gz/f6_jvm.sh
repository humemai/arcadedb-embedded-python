#!/bin/bash
# F6, corrected. The previous sweep counted TOTAL OS threads and flagged
# Elasticsearch (88) and Neo4j (83) as host-derived. That verdict was wrong: a
# JVM server runs dozens of threads regardless of cpuset, so the total says
# nothing about pool sizing.
#
# The question for a JVM is what Runtime.availableProcessors() returns, because
# every stock pool (GC, ForkJoin, and each server's own) is sized from it. On
# Java 11+ that reads the cgroup, so if it returns 12 under our cpuset the
# engine is fitted whatever its thread total looks like.
#
# Asked two ways per engine:
#   A. availableProcessors() as the engine itself reports it (its admin API)
#   B. GC thread count, which the JVM derives from availableProcessors and
#      which is visible without any API: ~5/8 of N for ParallelGCThreads.
set -u
CPUSET=0-11
say(){ echo "[$(date +%T)] $*"; }
hr(){ echo "--------------------------------------------------------"; }

say "F6 corrected: availableProcessors() under cpuset $CPUSET (12 CPUs, host has 20)"
hr

# --- Elasticsearch: _nodes/os reports allocated_processors directly ---
say "elasticsearch"
docker rm -f f6es >/dev/null 2>&1
docker run -d --name f6es --cpuset-cpus $CPUSET --memory 8g \
  -e discovery.type=single-node -e xpack.security.enabled=false \
  docker.elastic.co/elasticsearch/elasticsearch@sha256:268f65f1b32ea367e49c9be2acab144011b8c66c462c890f6190707743199050 \
  >/dev/null 2>&1
for i in $(seq 1 60); do
  out=$(docker exec f6es curl -s localhost:9200/_nodes/os 2>/dev/null)
  [ -n "$out" ] && echo "$out" | grep -q available_processors && break
  sleep 2
done
echo "$out" | python3 -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception: print('    (nodes API unreadable)'); raise SystemExit
for n in d.get('nodes',{}).values():
    os_=n.get('os',{})
    print(f\"    available_processors : {os_.get('available_processors')}   <- what the JVM sees\")
    print(f\"    allocated_processors : {os_.get('allocated_processors')}   <- what ES sizes pools from\")
" 2>/dev/null || echo "    (no answer)"
docker rm -f f6es >/dev/null 2>&1
hr

# --- Neo4j: JVM's own view via the GC thread count it derived ---
say "neo4j"
docker rm -f f6neo >/dev/null 2>&1
docker run -d --name f6neo --cpuset-cpus $CPUSET --memory 8g -e NEO4J_AUTH=none \
  neo4j@sha256:4bae36aff76271e27fd6a6ed0835413f86a284cd179cfb1cb7d188f5f7533aca >/dev/null 2>&1
sleep 25
echo "    GC threads the JVM sized from availableProcessors:"
docker exec f6neo sh -c 'for t in /proc/[0-9]*/task/*/comm; do cat $t 2>/dev/null; done' 2>/dev/null \
  | grep -ciE "^GC Thread" | sed 's/^/      GC Thread#N     : /'
docker exec f6neo sh -c 'for t in /proc/[0-9]*/task/*/comm; do cat $t 2>/dev/null; done' 2>/dev/null \
  | grep -ciE "^G1 Conc" | sed 's/^/      G1 Conc#N       : /'
echo "    (G1 sizes ParallelGCThreads = N for N<=8, else 8 + (N-8)*5/8;"
echo "     so 12 CPUs -> 10 GC threads, 20 CPUs -> 15. That distinguishes them.)"
docker rm -f f6neo >/dev/null 2>&1
hr
say "F6-JVM-DONE"
