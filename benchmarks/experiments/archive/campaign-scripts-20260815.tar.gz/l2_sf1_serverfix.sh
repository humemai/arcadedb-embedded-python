#!/usr/bin/env bash
set -u
while pgrep -f "l2_sf1_chain.sh" >/dev/null; do sleep 120; done
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "SRVFIX-ABORT ffmpeg"; exit 1; }
echo "=== L2 SF1 re-run: arcadedb server (escaping) + neo4j (heap fit) $(date -u +%FT%TZ) ==="
BENCH_GRAPH_SOURCE=ldbc BENCH_GRAPH_DATA=/data/ldbc BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l2 --scale sf1 --reps 5 --backends arcadedb_graph_server,neo4j_graph --tier sweep --workers 2
echo "rc=$?"
echo "L2-SF1-SERVERFIX-COMPLETE"
