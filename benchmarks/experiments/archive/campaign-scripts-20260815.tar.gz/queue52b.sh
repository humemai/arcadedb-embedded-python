#!/bin/bash
# Settle whether queue49's Cypher-vs-SQL ratio is like-for-like.
#
# queue49 measured Cypher 1.7-1.8x SQL MATCH at 2 hops and printed EQUIV-OK.
# That check compared ROW COUNTS only. The profiles then showed
# ImmutableDocument.getPropertyNames at 7.0% on the Cypher side and 0.0% on
# the SQL side, which is what materialising whole vertices looks like when
# only one surface does it.
#
# If the payloads differ, the ratio is not a latency comparison and must not
# be written as one. This runs both surfaces over the same seeds and compares
# what comes back, not how much of it.
set -u
exec >> "$HOME/profiling/queue52b.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue52b waiting for QUEUE51-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE51B-DONE" "$HOME/profiling/queue51b.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue51.sh" >/dev/null || { say "queue51 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
[ -f /tmp/surface_payload_probe.py ] || die "probe not staged"
cp /tmp/surface_payload_probe.py surface_payload_probe.py

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
say "engine: ${VER:-UNKNOWN}"

# Contract check first: queue38 died 4/4 on l2_graph.BACKENDS, which does not
# exist, and queue39 10/10 on a renamed flag. Verify the names before the run.
docker run --rm -v "$PWD:/work" -w /work -e BENCH_GRAPH_SOURCE=ldbc \
  icde-bench:arcadedb python -c "
import l2_graph, ldbc_snb
A = l2_graph.ADAPTERS
assert isinstance(A, dict), 'ADAPTERS is %s, expected dict' % type(A).__name__
assert 'arcadedb_graph_embedded' in A, 'adapter missing from %s' % list(A)
assert hasattr(ldbc_snb,'pick_query_ids'), 'pick_query_ids missing'
print('contract ok:', list(A))" || die "contract check failed"

guard
say "running payload probe (sf1)"
timeout 3600 docker run --rm --name payload52b --cpuset-cpus 0-11 \
  --memory 24g --memory-swap 24g \
  -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
  -e BENCH_GRAPH_SOURCE=ldbc -e BENCH_GRAPH_SCALE=sf1 -e ARCADEDB_HEAP=12g \
  icde-bench:arcadedb python -u surface_payload_probe.py \
  || say "probe exited non-zero"

say "QUEUE52B-DONE"
