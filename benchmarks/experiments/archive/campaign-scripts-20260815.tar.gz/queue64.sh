#!/bin/bash
# #120: does every engine's runtime HONOUR the cpuset, or just receive it?
#
# Equal allocation is not equal honouring. A JVM on Java 11+ reads the cpuset
# for availableProcessors(), so ArcadeDB sizes its pools to 12. Go and Rust
# runtimes have historically read the host's full core count, which here is
# 20 threads against a 12-thread cpuset. An engine that oversubscribes pays
# scheduling overhead we do not, and that would be a fourth asymmetry in our
# favour after the three found on 2026-07-31.
#
# Also captures the per-image client library versions, which the multipass
# driver failed to record for comparator arms (it reports the arcadedb wheel,
# absent from icde-bench:dense, so those rows read "unknown").
#
# Seconds of work, but it starts containers, so it waits for the box like
# everything else rather than perturbing a measured run.
set -u
exec >> "$HOME/profiling/queue64.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }

for prev in queue61 queue62 queue63; do
  if pgrep -f "bash ./$prev.sh" > /dev/null 2>&1; then
    say "$prev running; waiting"
    while pgrep -f "bash ./$prev.sh" > /dev/null 2>&1; do sleep 60; done
  fi
done
while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done

say "=== host ==="
say "nproc on host: $(nproc), cpuset under test: 0-11 (12 threads)"

say "=== JVM (icde-bench:arcadedb) ==="
docker run --rm --cpuset-cpus 0-11 -v "$HOME/repos/humemai/arcadedb-icde/paper-icde/experiments:/w" -w /w \
  icde-bench:arcadedb python -c "
import arcadedb_embedded as a
a.create_database('/tmp/_cs').close()
import jpype
rt = jpype.JClass('java.lang.Runtime').getRuntime()
print('  availableProcessors:', rt.availableProcessors())
print('  arcadedb wheel:', a.__version__)
" 2>/dev/null

say "=== embedded comparators (icde-bench:dense) ==="
docker run --rm --cpuset-cpus 0-11 icde-bench:dense python -c "
import os
print('  os.cpu_count():', os.cpu_count())
print('  len(os.sched_getaffinity(0)):', len(os.sched_getaffinity(0)))
for m in ('chromadb','lancedb','duckdb','sqlite_vec','numpy'):
    try:
        mod=__import__(m); print(f'  {m}:', getattr(mod,'__version__','?'))
    except Exception as e: print(f'  {m}: {e.__class__.__name__}')
import duckdb
print('  duckdb PRAGMA threads:', duckdb.connect().execute('SELECT current_setting(\'threads\')').fetchone()[0])
" 2>/dev/null

say "=== served comparators (icde-bench:client) ==="
docker run --rm --cpuset-cpus 0-11 icde-bench:client python -c "
import os
print('  len(os.sched_getaffinity(0)):', len(os.sched_getaffinity(0)))
for m in ('qdrant_client','pymilvus','elasticsearch','neo4j'):
    try:
        mod=__import__(m); print(f'  {m}:', getattr(mod,'__version__','?'))
    except Exception as e: print(f'  {m}: {e.__class__.__name__}')
" 2>/dev/null

say "=== qdrant server: what does its Rust runtime see? ==="
docker rm -f q64q >/dev/null 2>&1
docker run -d --name q64q --cpuset-cpus 0-11 --memory 8g \
  qdrant/qdrant@sha256:75eab8c4ba42096724fdcfde8b4de0b5713d529dde32f285a1f86fdcb2c9e50c >/dev/null 2>&1
sleep 12
docker exec q64q sh -c 'nproc 2>/dev/null; grep -c ^processor /proc/cpuinfo' 2>/dev/null | sed 's/^/  qdrant sees: /'
docker logs q64q 2>&1 | grep -iE "thread|cpu|core" | head -4 | sed 's/^/  log: /'
docker rm -f q64q >/dev/null 2>&1

say "INTERPRETATION: anything reporting more than 12 is sizing pools to the"
say "host rather than to its cpuset, and pays scheduling we do not. nproc and"
say "/proc/cpuinfo both IGNORE cpuset by design, so they show 20 for everyone;"
say "what matters is sched_getaffinity (the syscall a correct runtime uses)"
say "and each engine's own thread setting."
say "QUEUE64-DONE"
