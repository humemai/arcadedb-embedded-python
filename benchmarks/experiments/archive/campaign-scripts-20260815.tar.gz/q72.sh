#!/bin/bash
# q72: LanceDB best-fair-params sweep. Build once, sweep search-time knobs only.
# Idle-wait first: q70 was measured under contention and produced a story
# instead of a number, so every latency job now waits for an empty box.
set -u
OUT=$HOME/q72; mkdir -p "$OUT"
say(){ echo "[$(date +%T)] $*"; }
for i in $(seq 1 480); do
  n=$(docker ps -q | wc -l)
  [ "$n" -eq 0 ] && break
  [ "$i" -eq 1 ] && say "waiting for idle ($n container(s))"
  [ "$i" -eq 480 ] && { say "DEADLINE: busy 8h, not starting"; exit 1; }
  sleep 60
done
say "mini idle, starting lancedb sweep"
timeout 14400 docker run --rm --name q72_lance \
  --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
  -v "$HOME/q69work:/work" -w /work -v "$HOME/icde-data:/data:ro" \
  -e BENCH_DATA=/data -e BENCH_HOST=mini \
  icde-bench:dense python -u lance_sweep.py --scale deep10m \
    --out /work/out_lance_sweep.json >> "$OUT/sweep.log" 2>&1
say "rc=$? ; results:"
cp $HOME/q69work/out_lance_sweep.json "$OUT/" 2>/dev/null
grep -E "corpus|build |^ *[0-9None]" "$OUT/sweep.log" | tail -15
say "QUEUE72-DONE"
