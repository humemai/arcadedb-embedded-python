#!/bin/bash
# Deep profile of the two vector lanes on released dev23.
#
# Why this exists: every profile we have so far is `-e cpu`, and the July->dev20
# sparse comparison showed the bottleneck MOVES rather than disappears (scan
# 27.8 -> 10.4%, but siftDown 1.2 -> 24.4%). A single instrument on a single
# release is not enough to say where a lane's time goes.
#
# Three instruments per lane, on ONE container each, sequentially, so the build
# is paid once and all three see the identical warm steady state:
#   cpu           where on-CPU time goes
#   wall          where LATENCY goes, including blocking the cpu profile cannot
#                 see (page faults, lock waits, I/O). The paper reports p50/p99;
#                 nothing has ever profiled the thing the paper actually reports.
#   alloc --live  what is RETAINED. The queue32 alloc arm profiled allocation
#                 CHURN and so could not speak to the 29 GiB dense peak at all;
#                 --live is the instrument that can.
set -u
VER="${VER:-26.8.1.dev23}"
PROF=$HOME/profiling/async-profiler-4.0-linux-x64
OUT=$HOME/profiling/flame
exec >> "$HOME/profiling/queue37.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue37 waiting for QUEUE39-DONE"
for i in $(seq 1 900); do
  grep -qa "QUEUE39-DONE" "$HOME/profiling/queue39.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue39.sh" >/dev/null || { say "queue36 gone; proceeding"; break; }
  sleep 60
done
guard
mkdir -p "$OUT"
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"

# dev22 -> dev23 touches only TimeSeries (#5574) and the vector location map
# (#5568); no sparsevector commits. So these numbers compare directly with the
# dev22 T4 rows. Verified in git before queueing, re-asserted here so the log
# carries its own provenance.
GOT=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
[ "$GOT" = "$VER" ] || die "image has '$GOT', expected '$VER' (queue36 should have rebuilt it)"
say "image verified: $GOT"

# ---------------------------------------------------------------- one lane
# $1 = mode (sparse|dense)  $2 = memory cap  $3 = heap  $4 = build-wait minutes
profile_lane() {
  local mode=$1 mem=$2 heap=$3 waitmin=$4
  local name=prof37_$mode
  guard
  docker rm -f $name >/dev/null 2>&1
  local extra=""
  [ "$mode" = "sparse" ] && extra="-e BENCH_SPARSE_SOURCE=bigann -e BENCH_SPARSE_DATA=/data/bigann"
  [ "$mode" = "dense" ]  && extra="-e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32"
  docker run -d --name $name --cpuset-cpus 0-11 --memory "$mem" --memory-swap "$mem" \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -v "$PROF:/prof:ro" -v "$OUT:/pout" \
    -e MODE=$mode -e PROFILE_SECS=1200 -e ARCADEDB_HEAP="$heap" $extra \
    icde-bench:arcadedb python -u profile_query_driver.py >/dev/null || die "$mode container failed to start"

  local n=$((waitmin * 6))
  local ready=0
  for i in $(seq 1 $n); do
    docker logs $name 2>&1 | grep -qa "QUERY-PHASE-START" && { ready=1; break; }
    docker ps -q -f name=$name | grep -q . || { say "$mode DIED during build"; docker logs $name 2>&1 | tail -6; return 1; }
    sleep 10
  done
  [ $ready -eq 1 ] || { say "$mode never reached the query phase in ${waitmin}m"; docker rm -f $name >/dev/null 2>&1; return 1; }
  say "$mode reached steady state"
  sleep 20   # let the warm-up loop settle before the first sample lands

  for spec in "cpu:-e cpu" "wall:-e wall --wall 10ms" "live:-e alloc --live"; do
    local tag=${spec%%:*} args=${spec#*:}
    docker exec $name /prof/bin/asprof start $args 1 >/dev/null 2>&1 \
      || { say "$mode/$tag: asprof start failed"; continue; }
    sleep 180
    if docker exec $name /prof/bin/asprof stop -o collapsed \
         -f "/pout/${mode}_${VER}_${tag}.collapsed" 1 >/dev/null 2>&1; then
      say "$mode/$tag written"
    else
      say "$mode/$tag: asprof stop FAILED"
    fi
    sleep 10
  done

  docker logs $name 2>&1 | grep -a "QUERY-PHASE-END" | tail -1
  docker rm -f $name >/dev/null 2>&1
}

profile_lane sparse 20g 8g  25   || say "sparse lane failed"
profile_lane dense  36g 24g 120  || say "dense lane failed"

say "=== top frames per profile ==="
python3 - <<'PY'
import collections, glob, os
for p in sorted(glob.glob("/home/tk/profiling/flame/*_26.8.1.dev23_*.collapsed")):
    c = collections.Counter(); tot = 0
    for line in open(p):
        st, _, v = line.rpartition(" ")
        try: v = int(v)
        except ValueError: continue
        tot += v; c[st.split(";")[-1]] += v
    if not tot:
        print(f"\n== {os.path.basename(p)}: EMPTY"); continue
    print(f"\n== {os.path.basename(p)}  ({tot:,} samples)")
    for f, v in c.most_common(10):
        print(f"   {100*v/tot:5.1f}%  {f.split('/')[-1][:60]}")
PY
say "QUEUE37-DONE"
