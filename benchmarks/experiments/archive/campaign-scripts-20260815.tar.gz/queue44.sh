#!/bin/bash
# GAV ablation on the SciPy corpus (Cross Validated). queue39 re-issued.
#
# queue39 failed 10/10 in ten seconds with "unrecognized arguments: --out".
# I had written the invocation from assumption rather than from the script:
# graph_bench.py takes --data-dir (not --data), has no --out, and returns its
# payload as a "RESULT {json}" line on stdout, which is how run.py reads it.
# queue39 guarded the BENCH_GAV switch but not the CLI contract, so it verified
# the thing I had changed and not the thing I had guessed.
#
# This version checks the contract before spending any bench time on it.
set -u
exec >> "$HOME/profiling/queue44.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue44 waiting for QUEUE43-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE43-DONE" "$HOME/profiling/queue43.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue43.sh" >/dev/null || { say "queue43 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/scipy-bench/experiments || die "no scipy experiments dir"
grep -q 'BENCH_GAV' graph_bench.py || die "BENCH_GAV switch not staged"

# CONTRACT CHECK: the exact flags, before running anything expensive.
HELP=$(docker run --rm -v "$PWD:/work" -w /work scipy-bench:arcadedb \
         python graph_bench.py --help 2>&1)
for flag in -- --backend --data-dir --workload; do
  [ "$flag" = "--" ] && continue
  echo "$HELP" | grep -q -- "$flag" || die "graph_bench.py does not accept $flag"
done
echo "$HELP" | grep -q -- "--out" && die "graph_bench.py now has --out; this script assumes stdout"
say "CLI contract verified: --backend --data-dir --workload, results on stdout"

OUT=$HOME/profiling/scipy_gav; mkdir -p "$OUT"
run_arm() {
  local gav=$1 lab=$2 rep=$3
  guard
  timeout 5400 docker run --rm --cpuset-cpus 0-7 --memory 32g --memory-swap 32g \
    -e ARCADEDB_HEAP=16g -e BENCH_GAV="$gav" \
    -v "$PWD:/work" -w /work -v "$HOME/scipy-bench/data:/data:ro" \
    scipy-bench:arcadedb python graph_bench.py \
      --backend arcadedb --workload olap \
      --data-dir /data/stackoverflow-medium/prepared \
    > "$OUT/${lab}_r${rep}.log" 2>&1
  local rc=$?
  # Pull the RESULT line out the way run.py does.
  grep -aoE 'RESULT \{.*\}' "$OUT/${lab}_r${rep}.log" | sed 's/^RESULT //' \
    > "$OUT/${lab}_r${rep}.json" 2>/dev/null
  [ -s "$OUT/${lab}_r${rep}.json" ] || { rm -f "$OUT/${lab}_r${rep}.json"; rc=99; }
  say "SCIPY-GAV-$lab r$rep rc=$rc"
  [ "$rc" -ne 0 ] && grep -aE "error|Error|Traceback" "$OUT/${lab}_r${rep}.log" | head -2
  return 0
}

for spec in "1:with" "0:without"; do
  gav=${spec%%:*}; lab=${spec#*:}
  for rep in 1 2 3 4 5; do run_arm "$gav" "$lab" "$rep"; done
  say "SCIPY-GAV-$lab collected $(ls "$OUT"/${lab}_r*.json 2>/dev/null | wc -l)/5"
done

say "=== comparison ==="
python3 - <<'PY'
import json, glob, statistics
def load(lab):
    out = []
    for fp in sorted(glob.glob(f"/home/tk/profiling/scipy_gav/{lab}_r*.json")):
        try: out.append(json.load(open(fp)))
        except Exception: pass
    return out
a, b = load("with"), load("without")
print(f"  with n={len(a)}  without n={len(b)}")
if not a or not b:
    print("  incomplete, nothing to compare"); raise SystemExit
keys = sorted(k for k in a[0] if k.endswith("_ms") or k in ("olap_ms", "suite_ms"))
for k in keys:
    try:
        av = statistics.median([r[k] for r in a]); bv = statistics.median([r[k] for r in b])
    except Exception:
        continue
    print(f"  {k}: with {av:.1f} ms, without {bv:.1f} ms, without/with = {bv/av:.2f}x")
g = [r.get("gav_build_s") for r in a if r.get("gav_build_s")]
if g: print(f"  gav build: {statistics.median(g):.2f} s")
PY
say "QUEUE44-DONE"
