#!/bin/bash
# queue65: does the fp32 dense COLD pass reproduce at 8.172 ms, or was that one
# sample?
#
# q62 measured fp32 DEEP-10M on dev23 at cold 8.172 / warm 0.827. The dev20
# numbers in T5 are cold 4.424 / warm 0.723. Warm moved 14%, which is
# plausible drift. Cold moved +85%, which is not, and it is a single sample on
# each side. int8 went the other way over the same interval (cold 3.010 ->
# 2.399), so a blanket "dev23 is slower" story does not fit either.
#
# The cold pass is the FIRST pass after a build, so a second cold sample needs
# a second build. Three builds, three cold samples, same image and same
# protocol as q62 so the numbers are directly comparable to it.
#
# If cold clusters near 8.2 -> real change between dev20 and dev23, belongs in
# the prose with a bisect (candidates: #5412 cache auto-sizing, #5562
# LSM_VECTOR self-compaction).
# If it scatters across 4-8 -> the cold pass is simply high-variance and BOTH
# published cold numbers are single draws from a wide distribution, which is a
# methodology finding: T5 should not print a cold number at N=1.
set -u
OUT=~/q65
mkdir -p $OUT
say(){ echo "[$(date +%T)] $*"; }

guard(){
  local n
  n=$(docker ps -q | wc -l)
  [ "$n" -eq 0 ] || { say "GUARD: $n container(s) already running, refusing to co-run"; exit 1; }
}

say "queue65: 3 fresh fp32 DEEP-10M builds on dev23, cold pass each"
say "expect ~50 min per rep, ~2.5 h total"

for rep in 1 2 3; do
  out="$OUT/fp32_r${rep}.json"
  src=$HOME/repos/humemai/arcadedb-icde/paper-icde/experiments/q65_fp32_r${rep}.json
  if [ -s "$src" ]; then say "rep$rep present, skipping"; cp "$src" "$out"; continue; fi
  guard
  say "rep$rep: building (the build is ~45 min of it)"
  timeout 14400 docker run --rm --name q65_r${rep} \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$HOME/repos/humemai/arcadedb-icde/paper-icde/experiments:/work" -w /work \
    -v "$HOME/icde-data:/data:ro" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_DENSE_QUANT="" -e ARCADEDB_HEAP=24g \
    -e BENCH_MP_BACKEND=arcadedb_dense_embedded -e BENCH_MP_SCALE=deep10m \
    -e BENCH_ROLE=engine -e PROBE_OUT="/work/q65_fp32_r${rep}.json" \
    icde-bench:arcadedb python -u dense_multipass_driver.py >/dev/null 2>&1 \
    && say "rep$rep ok" || say "rep$rep FAILED"
  [ -s "$src" ] && cp "$src" "$out"
  # the driver writes into /work, which is the checkout; copy out and clear
done

say "=== result ==="
python3 - <<'PY'
import glob, json, os, statistics as st
files = sorted(glob.glob(os.path.expanduser("~/q65/fp32_r*.json")))
seen = {}
for f in files:
    try: d = json.load(open(f))
    except Exception: continue
    seen[os.path.basename(f)] = d
if not seen:
    print("  no result files found"); raise SystemExit
print(f"  {'rep':<14}{'build_s':>9}{'cold_ms':>9}{'warm_ms':>9}{'gain':>7}{'recall':>8}")
colds = []
for k, d in sorted(seen.items()):
    c = d.get("pass1_ms") or d.get("cold_ms")
    w = d.get("passes2_5_ms") or d.get("warm_ms")
    b = d.get("build_s")
    r = d.get("recall")
    if c: colds.append(c)
    print(f"  {k:<14}{b if b else '?':>9}{c if c else '?':>9}{w if w else '?':>9}"
          f"{(c/w if c and w else 0):>7.2f}{r if r else '?':>8}")
if len(colds) >= 2:
    print(f"\n  cold: median {st.median(colds):.3f}  min {min(colds):.3f}  max {max(colds):.3f}  n={len(colds)}")
    print(f"  dev20 T5 cold = 4.424, q62 dev23 cold = 8.172")
    print("  VERDICT: clusters near 8.2 -> real change; scattered 4-8 -> cold is high-variance and N=1 was never enough")
PY
say "QUEUE65-DONE"
