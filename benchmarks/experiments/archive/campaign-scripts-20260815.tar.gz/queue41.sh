#!/bin/bash
# Is dense query latency actually worse on the current line than on dev20?
#
# q34 measured dev22 dense with the dev20 driver (diff verified labels-only),
# same cpuset/heap/memory, and got p50 0.835 [0.799-0.927] against the
# published dev20 row's 0.723 [0.71-0.74]. Non-overlapping ranges. The index is
# structurally identical (graphNodeCount, maxConnections 32, beamWidth 100,
# location-index bytes all equal), so a different index cannot explain it.
#
# Two candidate explanations and no way to separate them from data on disk:
#
#   (a) real: #5516 (e6fd2cc876) fixed LSM_VECTOR in-memory bloat between dev20
#       and dev22, and a memory fix can cost lookup latency.
#   (b) noise: q34 started 60 s after queue33 finished hammering the box, and
#       its spread is 4x wider than dev20's, which is what a thermally or
#       cache-disturbed run looks like rather than what a code change looks
#       like.
#
# So: run both arms back to back on one machine state, same driver, same knobs,
# with a cooldown before each. That is the only thing that separates (a) from
# (b), and until it runs the dev22 dense numbers do NOT go into T5.
#
# Runs last: it rebuilds the image to dev20 and back, which would wreck any
# dev23 job still queued.
set -u
OLD="${OLD:-26.8.1.dev20}"
NEW="${NEW:-26.8.1.dev23}"
COOLDOWN="${COOLDOWN:-600}"
exec >> "$HOME/profiling/queue41.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue41 waiting for QUEUE40-DONE"
for i in $(seq 1 1600); do
  grep -qa "QUEUE40-DONE" "$HOME/profiling/queue40.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue40.sh" >/dev/null || { say "queue40 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
[ -f fp32_dev22_driver.py ] || die "q34's driver missing; nothing to match against"

OUT=$HOME/profiling/dense_ab; mkdir -p "$OUT"

run_arm() {
  local ver=$1 tag=$2
  guard
  sed -i "s/arcadedb-embedded==26\.8\.1\.dev[0-9]*/arcadedb-embedded==$ver/" build_images.sh
  grep -q "arcadedb-embedded==$ver" build_images.sh || { say "pin failed for $ver"; return 1; }
  bash build_images.sh arcadedb > "$OUT/image_${tag}.log" 2>&1 || { say "image build failed for $ver"; return 1; }
  local got
  got=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
  [ "$got" = "$ver" ] || { say "image has '$got', expected '$ver'"; return 1; }
  say "$tag image verified: $got"

  # Same cooldown before each arm, so neither is measured on a hotter box than
  # the other. This is the confound the whole experiment exists to remove.
  say "$tag cooling down ${COOLDOWN}s"
  sleep "$COOLDOWN"

  # One driver for both arms. It is labelled dev22 but only uses the label for
  # output filenames, which q34 verified by diffing it against the dev20
  # original. Passing the tag through keeps the two arms' files apart.
  guard
  timeout 28800 docker run --rm --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" -v "$OUT:/pout" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 -e ARCADEDB_HEAP=24g \
    -e OUT_TAG="$tag" -e PROBE_OUT="/pout/dense_${tag}.json" \
    icde-bench:arcadedb python -u fp32_dev22_driver.py \
    > "$OUT/${tag}.log" 2>&1
  say "$tag rc=$?"
  grep -a "^RESULT" "$OUT/${tag}.log" | tail -5
}

run_arm "$OLD" old || say "old arm failed"
run_arm "$NEW" new || say "new arm failed"

say "=== comparison (warm passes, rep>=2) ==="
python3 - <<'PY'
import json, glob, statistics, re
def warm(tag):
    rs = []
    for fp in glob.glob(f"/home/tk/profiling/dense_ab/{tag}.log"):
        for line in open(fp, errors="ignore"):
            if line.startswith("RESULT "):
                try: rs.append(json.loads(line[7:]))
                except Exception: pass
    return [r for r in rs if r.get("rep", 0) >= 2]
a, b = warm("old"), warm("new")
if not a or not b:
    print(f"  incomplete: old n={len(a)} new n={len(b)}")
else:
    print(f"  {'metric':14s} {'dev20':>22s} {'current':>22s}   verdict")
    for k in ("p50", "p95", "p99", "recall_at_10", "build_s"):
        va = [r[k] for r in a if k in r]; vb = [r[k] for r in b if k in r]
        if not va or not vb: continue
        ma, mb = statistics.median(va), statistics.median(vb)
        # Non-overlapping ranges is the bar for calling it real; anything else
        # is the noise hypothesis surviving.
        overlap = not (max(va) < min(vb) or max(vb) < min(va))
        v = "overlap (noise)" if overlap else f"SEPARATED {mb/ma:.2f}x" if ma else ""
        print(f"  {k:14s} {ma:9.4f} [{min(va):.3f}-{max(va):.3f}] "
              f"{mb:9.4f} [{min(vb):.3f}-{max(vb):.3f}]   {v}")
PY
say "QUEUE41-DONE"
