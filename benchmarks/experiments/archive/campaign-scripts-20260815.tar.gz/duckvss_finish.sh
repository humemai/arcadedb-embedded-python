#!/usr/bin/env bash
set -u
# wait for the in-flight rep to record its timeout, then stop the campaign
until grep -qaE "timeout|-> ok" ~/duckvss_solo.log; do sleep 120; done
pkill -f "runner.py --lanes l3d" 2>/dev/null; sleep 3
docker ps -q --filter "label=icde-bench=1" | xargs -r docker rm -f
grep -qa "\-> ok" ~/duckvss_solo.log && { echo "DVSS finished normally, no unbounded run needed"; echo "DVSS-FINISH-COMPLETE"; exit 0; }
echo "=== DuckDB-VSS unbounded single build (true-build-time footnote) $(date -u +%FT%TZ) ==="
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
timeout 28800 docker run --rm --cpuset-cpus 0-11 --memory 16g --label icde-bench=1 \
  -v $PWD:/work -w /work -v /home/tk/icde-data:/data:ro icde-bench:dense \
  python -u l3d_dense.py --backend duckdb_vss_dense --workload search --scale small --out /tmp/dvss_unbounded.json > /tmp/dvss_unbounded.log 2>&1
echo "unbounded rc=$?"
grep -aoE "\{.*\}" /tmp/dvss_unbounded.log | tail -1 | head -c 300
echo "DVSS-FINISH-COMPLETE"
