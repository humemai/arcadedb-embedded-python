#!/usr/bin/env bash
# W3 staged benchmark runs on mini. Usage: mini_w3.sh <stage>
#   smoke   : small scale, all variants, 1 repeat, low iters  (validate mini)
#   medium  : synthetic medium + SNB sf1, all variants, 5 repeats
#   large   : synthetic large  + SNB sf10, all variants, 5 repeats (headline)
# Locked policy: client + servers pinned to P-cores 0,2,4,6,8,10; workers=1;
# ablation measured via --variable-length-strategy both; timeouts are data.
# NOTE: arcadedb variants are SKIPPED campaign-wide for now (upstream
# changes in flight); run the arcadedb-supplement stages once stable.
# NOTE: each SNB data dir is bound to ONE scale preset (the fixture cache is
# schema-width-specific): sf1 <-> medium, sf10 <-> large.
set -u
export PATH="$HOME/.local/bin:$PATH"
cd "$HOME/repos/cypherglot"

STAGE="${1:?usage: mini_w3.sh <smoke|small|medium|ladybug-medium|large>}"
# 3-way co-run: each worker gets 2 physical P-cores (4 HT threads); the
# dispatcher never co-runs two jobs of the same engine, and the shuffled
# queue permutes co-runner mixes across repeats.
WORKER_CPUSETS="0,1,2,3|4,5,6,7|8,9,10,11"
ROOT="$HOME/w3/$STAGE"
mkdir -p "$ROOT"
# Disk-backed scratch for all python tempfile use: mini's /tmp is a tmpfs
# with a ~1.6 GiB per-user quota, and SIGKILLed jobs leak their temp dirs.
export TMPDIR="$HOME/w3/tmp"
rm -rf "$TMPDIR"
mkdir -p "$TMPDIR"
LOG="$ROOT/driver.log"
log() { echo "[$(date -u +%F' '%H:%M:%S)] $*" | tee -a "$LOG"; }

run_matrix() {
  local label="$1"; shift
  log "=== matrix: $label START ==="
  .venv/bin/python -m scripts.benchmarks.runtime.matrix \
    --workers 3 --worker-cpusets "$WORKER_CPUSETS" \
    --variable-length-strategy both \
    --neo4j-password cypherglot-w3 \
    --output-root "$ROOT/$label/out" --session-root "$ROOT/$label/session" \
    "$@" >>"$LOG" 2>&1
  log "=== matrix: $label EXIT $? ==="
}

case "$STAGE" in
  smoke)
    # 1 repeat, low iterations: validates every engine + docker + pinning.
    run_matrix synthetic-small --scale small --repeats 1 \
      --iterations 10 --warmup 2 --job-timeout-s 1800 \
      --oltp-timeout-ms 10000 --olap-timeout-ms 60000
    # ladybug excluded here: its SNB ingest deterministically exceeds any
    # smoke budget (#645); its machinery is validated in the synthetic half.
    run_matrix snb-sf1 --scale medium --repeats 1 --variant sqlite-indexed --variant sqlite-unindexed --variant turso-indexed --variant turso-unindexed --variant duckdb-indexed --variant duckdb-unindexed --variant postgresql-indexed --variant postgresql-unindexed --variant clickhouse-indexed --variant neo4j-indexed --variant neo4j-unindexed --variant age-indexed --variant age-unindexed \
      --topology ldbc_snb --ldbc-snb-data-dir "$HOME/data/ldbc_snb/sf1" \
      --iterations 5 --warmup 1 --job-timeout-s 5400 \
      --job-timeout-override turso-indexed=1800 --job-timeout-override turso-unindexed=1800 \
      --oltp-timeout-ms 10000 --olap-timeout-ms 120000
    ;;
  small)
    # Paper-grade small point for the F4 scaling curve (smoke only ran 1
    # repeat / 10 iterations). Every engine completes at this scale.
    run_matrix synthetic-small --scale small --repeats 5 --variant sqlite-indexed --variant sqlite-unindexed --variant turso-indexed --variant turso-unindexed --variant duckdb-indexed --variant duckdb-unindexed --variant postgresql-indexed --variant postgresql-unindexed --variant clickhouse-indexed --variant neo4j-indexed --variant neo4j-unindexed --variant age-indexed --variant age-unindexed --variant ladybug-unindexed \
      --iterations 100 --warmup 10 --job-timeout-s 1800 \
      --oltp-timeout-ms 10000 --olap-timeout-ms 60000
    ;;
  medium)
    # 14400 s job budget (2-core envelope slows unindexed scans); turso
    # capped at 3600 s per job — its legitimate work ends before the
    # documented uninterruptible VL wedge, the rest of any budget is burn.
    # Overrides keep turso in the shared shuffled queue (random co-runners).
    run_matrix synthetic-medium --scale medium --repeats 5 --variant sqlite-indexed --variant sqlite-unindexed --variant turso-indexed --variant turso-unindexed --variant duckdb-indexed --variant duckdb-unindexed --variant postgresql-indexed --variant postgresql-unindexed --variant clickhouse-indexed --variant neo4j-indexed --variant neo4j-unindexed --variant age-indexed --variant age-unindexed \
      --iterations 50 --warmup 5 --olap-iterations 20 --olap-warmup 3 --job-timeout-s 14400 \
      --job-timeout-override turso-indexed=3600 --job-timeout-override turso-unindexed=3600 \
      --oltp-timeout-ms 30000 --olap-timeout-ms 300000
    run_matrix snb-sf1 --scale medium --repeats 5 --variant sqlite-indexed --variant sqlite-unindexed --variant turso-indexed --variant turso-unindexed --variant duckdb-indexed --variant duckdb-unindexed --variant postgresql-indexed --variant postgresql-unindexed --variant clickhouse-indexed --variant neo4j-indexed --variant neo4j-unindexed --variant age-indexed --variant age-unindexed \
      --topology ldbc_snb --ldbc-snb-data-dir "$HOME/data/ldbc_snb/sf1" \
      --iterations 50 --warmup 5 --olap-iterations 20 --olap-warmup 3 --job-timeout-s 14400 \
      --job-timeout-override turso-indexed=3600 --job-timeout-override turso-unindexed=3600 \
      --oltp-timeout-ms 30000 --olap-timeout-ms 300000
    ;;
  ladybug-medium)
    # Disclosed budget-extended run: ladybug in PURE DEFAULTS, but the job
    # budget accommodates its one-time ingest (~2.5-3.5 h/repeat; issues #474/
    # #645) so its QUERY data is measured under the same iterations/timeouts
    # as the medium matrix. 5 repeats like everything else. Large stays
    # excluded (ingest ~11 h/repeat + query OOM per #475).
    run_matrix ladybug-synthetic-medium --scale medium --repeats 5 \
      --variant ladybug-unindexed \
      --iterations 50 --warmup 5 --olap-iterations 20 --olap-warmup 3 --job-timeout-s 18000 \
      --oltp-timeout-ms 30000 --olap-timeout-ms 300000
    run_matrix ladybug-snb-sf1 --scale medium --repeats 5 \
      --variant ladybug-unindexed \
      --topology ldbc_snb --ldbc-snb-data-dir "$HOME/data/ldbc_snb/sf1" \
      --iterations 50 --warmup 5 --olap-iterations 20 --olap-warmup 3 --job-timeout-s 18000 \
      --oltp-timeout-ms 30000 --olap-timeout-ms 300000
    ;;
  large)
    # arcadedb: skipped for now (upstream changes in flight); ladybug:
    # excluded at large (ingest exceeds practical budget, #645/#474/#475).
    run_matrix synthetic-large --scale large --repeats 5 --variant sqlite-indexed --variant sqlite-unindexed --variant turso-indexed --variant turso-unindexed --variant duckdb-indexed --variant duckdb-unindexed --variant postgresql-indexed --variant postgresql-unindexed --variant clickhouse-indexed --variant neo4j-indexed --variant neo4j-unindexed --variant age-indexed --variant age-unindexed \
      --iterations 20 --warmup 3 --job-timeout-s 21600 \
      --oltp-timeout-ms 60000 --olap-timeout-ms 600000
    run_matrix snb-sf10 --scale large --repeats 5 --variant sqlite-indexed --variant sqlite-unindexed --variant turso-indexed --variant turso-unindexed --variant duckdb-indexed --variant duckdb-unindexed --variant postgresql-indexed --variant postgresql-unindexed --variant clickhouse-indexed --variant neo4j-indexed --variant neo4j-unindexed --variant age-indexed --variant age-unindexed \
      --topology ldbc_snb --ldbc-snb-data-dir "$HOME/data/ldbc_snb/sf10" \
      --iterations 20 --warmup 3 --job-timeout-s 21600 \
      --oltp-timeout-ms 60000 --olap-timeout-ms 600000
    ;;
  *) echo "unknown stage $STAGE"; exit 2;;
esac

# Leave no stray containers behind.
docker ps -a --format '{{.Names}}' 2>/dev/null \
  | grep -E "^benchmark-|^cypherglot-" \
  | while read -r c; do docker rm -f "$c" >/dev/null 2>&1 && log "cleaned $c"; done
log "=== stage $STAGE COMPLETE ==="
