#!/bin/bash
# q13: the two sparse arms q8 did not re-run.
#
# q8 re-measured arcadedb_sparse_embedded (int8) and _fp32 at all three tiers,
# N=5, on the release. It did NOT touch the other two ArcadeDB sparse arms:
#   arcadedb_sparse_server              the deployment axis
#   arcadedb_sparse_embedded_nocompact  the settle-step ablation
# Both are still on dev-era engines, and F8's own caption says the bars are
# "measured on different releases (26.8.1.dev0 to dev20)". A figure that
# discloses its own version mixing is still a figure that mixes versions, and
# the standing policy is now one released engine everywhere.
#
# WITH THIS, THE SPARSE LANE DECOMPOSES CLEANLY ON ONE ENGINE:
#   embedded            vs embedded_nocompact  -> settle-step cost
#   embedded_nocompact  vs server              -> pure transport
# which is the decomposition the paper's deployment section claims to make and
# currently makes across four different dev builds.
#
# Driven through runner.py: arcadedb_sparse_server is a client_server topology
# and runner.py owns the split envelope, the readiness gate and the manifest.
set -u
OUT=~/q13
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q13 started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

DEADLINE=$(( $(date +%s) + 24*3600 ))
log "waiting for Q12-COMPLETE (hard deadline 24 h)"
while ! grep -qa "Q12-COMPLETE" ~/q12/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then log "ABORT: q12 unfinished after 24 h"; exit 1; fi
  grep -qa "ABORT:" ~/q12/queue.log 2>/dev/null && { log "q12 exited on an error path"; exit 1; }
  sleep 60
done
log "q12 finished"
for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

export BENCH_DATA=$HOME/bench-data
export BENCH_SPARSE_SOURCE=bigann
export BENCH_SPARSE_DATA=/data/bigann
[ -d "$BENCH_DATA/bigann" ] || { log "ABORT: no bigann corpus"; exit 1; }
GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "26.8.1" ] || { log "ABORT: image is not 26.8.1"; exit 1; }

cell() {  # label scale backends timeout
  local label=$1 scale=$2 be=$3 tmo=$4
  local marker="$OUT/${label}.done"
  [ -f "$marker" ] && { log "  skip $label"; return; }
  local t0=$(date +%s)
  log "  START $label (scale=$scale)"
  timeout "$tmo" python3 runner.py --lanes l3s --scale "$scale" \
      --backends "$be" --reps 5 --tier paper --workers 0 \
      > "$OUT/${label}.log" 2>&1
  local rc=$? el=$(( $(date +%s) - t0 ))
  if [ $rc -eq 0 ]; then touch "$marker"; log "  DONE  $label rc=$rc ${el}s"
  else log "  FAIL  $label rc=$rc ${el}s"; tail -15 "$OUT/${label}.log" >> "$LOG"; fi
}

# Cheap tiers first: a reclaimed box still leaves the decomposition possible at
# two of three scales.
ARMS="arcadedb_sparse_server,arcadedb_sparse_embedded_nocompact"
cell l3s_tiny   tiny   "$ARMS" 10800
cell l3s_small  small  "$ARMS" 21600
cell l3s_medium medium "$ARMS" 43200

python3 - >> "$LOG" 2>&1 <<'PY'
import json, glob, os, collections, statistics as st
root = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments/results/raw")
g = collections.defaultdict(list)
for p in glob.glob(os.path.join(root, "*.json")):
    try: j = json.load(open(p))
    except Exception: continue
    if isinstance(j, dict) and j.get("lane") == "l3s":
        g[(j.get("scale"), j.get("backend"))].append(j)
print("\nq13: sparse arms on the release")
print("  %-8s %-38s %2s %10s %s" % ("tier", "arm", "N", "p50_ms", "version"))
for k in sorted(g, key=lambda x: str(x)):
    rs = g[k]
    v = [r["query_p50_ms"] for r in rs if r.get("query_p50_ms") is not None]
    if not v: continue
    vs = sorted({str(r.get("engine_version"))[:22] for r in rs})
    print("  %-8s %-38s %2d %10.2f %s" % (k[0], k[1][:38], len(v), st.median(v), ",".join(vs)))
PY

log "Q13-COMPLETE"
