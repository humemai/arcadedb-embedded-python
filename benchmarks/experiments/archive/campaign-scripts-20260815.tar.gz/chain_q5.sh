#!/bin/bash
# Chain q5 (dense fill) behind q4 (qdrant). Same shape as chain_q4: hard
# deadline plus a died-without-a-marker check, so a dead upstream queue ends
# this instead of parking a process for hours.
set -u
LOG=~/q5/chain.log
mkdir -p ~/q5
say() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
say "chain armed, waiting on q4 (deadline 6h)"
DEADLINE=$(( $(date +%s) + 21600 ))
while :; do
  grep -q "QDRANT-COMPLETE" ~/q4/queue.log 2>/dev/null && { say "q4 complete, starting q5"; break; }
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then
    say "DEADLINE: q4 never completed in 6h. Not starting q5."; exit 1
  fi
  if ! pgrep -f "bash /home/tk/icde_qdrant.sh" >/dev/null 2>&1; then
    say "q4 process gone with no completion marker. Not starting q5."
    tail -5 ~/q4/queue.log 2>/dev/null | tee -a "$LOG"; exit 1
  fi
  sleep 120
done
exec ~/icde_dense_fill.sh
