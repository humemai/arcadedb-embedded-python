#!/usr/bin/env bash
set -u
pgrep -x ffmpeg >/dev/null && { echo "GRAPH-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "GRAPH-ABORT foreign-container"; exit 1; }
L=$(awk "{print int(\$1)}" /proc/loadavg); [ "$L" -gt 2 ] && { echo "GRAPH-ABORT load=$L"; exit 1; }
cd /home/tk/repos/scipy-bench-repo
git fetch -q origin arcadedb-2026 && git checkout -q origin/arcadedb-2026 -- experiments/ || { echo "GRAPH-ABORT pull"; exit 1; }
cd experiments
echo "=== GRAPH-CLEAN: bidirectional graph lane, solo $(date -u +%FT%TZ) ==="
BENCH_DATA=/home/tk/scipy-bench/data python3 -u run.py --datasets tiny,small,medium --lanes graph --reps 5 > results/graph_bidi_clean.log 2>&1
echo "graph rc=$?"
echo "SCIPY-GRAPH-CLEAN-COMPLETE"
