#!/bin/bash
# Sparse int8 vs fp32 at 1M on dev23: two jobs at once.
#
# 1. THE PAPER GAP. T4's caption says "fp32 and server ablations are deferred
#    to re-measurement on the same line". The fp32 arm in the data is dev0/dev3
#    era, so the ablation the caption promises does not currently exist on the
#    published line.
#
# 2. THE MECHANISM QUESTION. The paper's headline loss is sparse query latency
#    (3.9x Qdrant at 1M). Profiles put it in the scoring loop, not the shared
#    substrate (~4% of query CPU), but "scan is 20.5%" does not say WHY. The
#    decisive instrument is -e cache-misses and it is unavailable: this host
#    runs perf_event_paranoid=4, so asprof refuses to start and writes 0 bytes.
#
#    int8 vs fp32 is the discriminator that does not need perf counters.
#    Quantization changes the WEIGHT bytes per posting by 4x while leaving doc
#    ids and list lengths identical. If the scoring loop were bandwidth-bound
#    on posting data, fp32 must be materially slower. If the two arms land on
#    top of each other, bandwidth on weights is not the limiter and the answer
#    is compute or branch behaviour in the DAAT cursor.
#
#    Falsifiable either way, which is the point.
set -u
exec >> "$HOME/profiling/queue57.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
OUT=results/sparse57
mkdir -p "$OUT"

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
[ -n "${VER:-}" ] || die "no engine version"
say "engine $VER"

# Contract check before ~2 hours of builds. queue39 lost 10/10 cells to a flag
# that did not exist; --out is required here too.
docker run --rm -v "$PWD:/work" -w /work -e BENCH_SPARSE_SOURCE=bigann \
  icde-bench:arcadedb python -c "
import re, l3_sparse
s = open('l3_sparse.py').read()
have = set(re.findall(r'add_argument\(\"(--[a-z0-9_]+)\"', s))
need = {'--backend', '--scale', '--out'}
assert not (need - have), 'missing %s' % (need - have)
b = l3_sparse.BACKENDS
for k in ('arcadedb_sparse_embedded', 'arcadedb_sparse_embedded_fp32'):
    assert k in b, 'backend missing: %s' % k
assert 'small' in l3_sparse.SCALE_DOCS, 'scale small missing'
print('contract ok: both arms present, small =', l3_sparse.SCALE_DOCS['small'], 'docs')
" || die "sparse lane contract changed"

run_arm() {  # $1 backend, $2 label, $3 rep
  local be=$1 label=$2 rep=$3
  guard
  timeout 10800 docker run --rm --name sp57_${label}_r${rep} \
    --cpuset-cpus 0-11 --memory 20g --memory-swap 20g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_SPARSE_SOURCE=bigann -e BENCH_SPARSE_DATA=/data/bigann \
    -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
    icde-bench:arcadedb python -u l3_sparse.py --backend "$be" \
      --scale small --out "/work/$OUT/${label}_rep${rep}.json" >/dev/null 2>&1 \
    && say "$label rep$rep ok" || say "$label rep$rep FAILED"
}

# Interleave the arms rather than running each to completion. Running one arm
# fully before the other is how the Cypher-vs-SQL ratio and the transport probe
# both acquired an order artifact today; whichever goes first pays the page
# cache warming for the rest.
for rep in 1 2 3; do
  run_arm arcadedb_sparse_embedded      int8 "$rep"
  run_arm arcadedb_sparse_embedded_fp32 fp32 "$rep"
done

say "=== result ==="
python3 - <<'PY'
import glob, json, os, statistics as st
res = {}
for arm in ("int8", "fp32"):
    rows = []
    for fp in sorted(glob.glob(f"results/sparse57/{arm}_rep*.json")):
        try:
            rows.append(json.load(open(fp)))
        except Exception:
            pass
    if rows:
        res[arm] = rows
        p50 = st.median([r["query_p50_ms"] for r in rows if r.get("query_p50_ms")])
        p99 = st.median([r["query_p99_ms"] for r in rows if r.get("query_p99_ms")])
        bld = st.median([r["build_s"] for r in rows if r.get("build_s")])
        rec = st.median([r["recall_at_10"] for r in rows if r.get("recall_at_10")])
        print(f"  {arm:5} n={len(rows)}  p50={p50:8.2f}ms  p99={p99:8.2f}ms  "
              f"build={bld:8.1f}s  recall={rec:.4f}")
        print(f"        conditions: cpuset={rows[0].get('cpuset')} "
              f"heap={rows[0].get('heap')} role={rows[0].get('role')} "
              f"engine={rows[0].get('engine_version')}")
if "int8" in res and "fp32" in res:
    a = st.median([r["query_p50_ms"] for r in res["int8"]])
    b = st.median([r["query_p50_ms"] for r in res["fp32"]])
    print(f"\n  fp32/int8 p50 ratio = {b/a:.3f}x")
    print("  fp32 carries 4x the weight bytes per posting for identical doc ids")
    print("  and list lengths, so:")
    if b / a > 1.15:
        print(f"  -> fp32 is {b/a:.2f}x slower. Posting-data bandwidth IS a real")
        print("     component of the scoring loop, and shrinking postings is a lever.")
    elif abs(b / a - 1.0) <= 0.15:
        print("  -> the arms land on top of each other. Weight-data bandwidth is")
        print("     NOT the limiter; the cost is compute or branch behaviour in")
        print("     the DAAT cursor, and a smaller posting format would not help.")
    else:
        print(f"  -> fp32 is FASTER ({b/a:.2f}x), which needs explaining before use.")
PY
say "QUEUE57-DONE"
