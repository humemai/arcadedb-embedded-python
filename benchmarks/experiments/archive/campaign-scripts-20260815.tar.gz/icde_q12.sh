#!/bin/bash
# q12: E3, the last lane with no artifacts. Chained behind q11.
#
# e3_recovery.py's own header records why this exists: E3's paper claims trace
# to one hand-written line in CAMPAIGN_2026-07.md because the script only ever
# printed to stdout and those logs are gone. No queue script ever ran it, and
# no Raft harness existed at all. Both halves are now driven and both persist
# per-trial JSON.
#
# THE HARNESS WAS SMOKE-TESTED ON THE LAPTOP FIRST, which caught three defects
# that would each have burned an unattended run:
#   1. readiness probed with `docker exec curl` -- the release image has no
#      curl, so 90 probes returned empty against a perfectly healthy server.
#   2. readiness gated on /api/v1/health, which returns 204 about two seconds
#      in while the election is still VOTING_FOR_ME. Convergence took 10-20 s.
#      Now gated on electionStatus==DONE with a non-null leader.
#   3. "CREATE PROPERTY R.k LONG IF NOT EXISTS" is a parse error. Dropped; the
#      property was never needed.
# The smoke run then completed: leader killed, writes resumed, 50/50
# acknowledged rows present, zero loss.
#
# EXPECT THE FAILOVER NUMBER TO MOVE. The laptop smoke trial measured 12.4 s
# against the paper's "0.2--3.3 s". That is one trial, on a contended laptop,
# at 1 GB heap, under a deliberately stricter definition (client-observed
# unavailability including reconnect, not election time alone). It is not yet
# a contradiction. It IS the reason this had to be re-measured rather than
# carried forward.
set -u
OUT=~/q12
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q12 started, pid $$"

DEADLINE=$(( $(date +%s) + 24*3600 ))
log "waiting for Q10-COMPLETE (hard deadline 24 h)"
while ! grep -qa "Q10-COMPLETE" ~/q10/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then log "ABORT: q10 unfinished after 24 h"; exit 1; fi
  grep -qa "ABORT:" ~/q10/queue.log 2>/dev/null && { log "q10 exited on an error path"; exit 1; }
  sleep 60
done
log "q10 finished"
for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

OUT=$OUT bash ~/e3_run.sh full 2>&1 | tee -a "$LOG"

python3 - >> "$LOG" 2>&1 <<'PY'
import glob, json, os, statistics as st
print("\nE3b failover, 5 trials")
fo, loss = [], []
for p in sorted(glob.glob(os.path.expanduser("~/q12/e3b_trial*.json"))):
    j = json.load(open(p))
    print("  %-18s killed=%-6s failover_s=%-8s acked=%s/%s loss=%s" % (
        os.path.basename(p), j.get("killed_leader"), j.get("failover_s"),
        j.get("acked_present_after"), j.get("acked_before_kill"),
        "NO" if j.get("no_acked_loss") else "YES"))
    if j.get("failover_s") is not None: fo.append(j["failover_s"])
    loss.append(j.get("no_acked_loss"))
if fo:
    print("  failover median %.2fs  range %.2f-%.2f  N=%d" % (
        st.median(fo), min(fo), max(fo), len(fo)))
    print("  PAPER CLAIMS 0.2-3.3 s. Compare before touching the prose.")
print("  acknowledged-write loss in any trial:", "NO" if all(loss) else "YES")

print("\nE3a crash recovery")
for p in sorted(glob.glob(os.path.expanduser("~/q12/e3a_*trial*.json"))):
    j = json.load(open(p))
    print("  %-26s recovery_s=%-7s rows=%-8s contiguous=%s dups=%s wal=%s" % (
        os.path.basename(p), j.get("recovery_s"), j.get("rows"),
        j.get("contiguous"), j.get("max_duplicates"), j.get("wal_flush")))
PY

log "Q12-COMPLETE"
