#!/bin/bash
# q15: l3d "small" (SIFT-1M) re-run MATCHED, chained behind q11.
#
# THE OLD ROW IS MISMATCHED AGAINST US. ArcadeDB built at base-layer degree 16
# while all five comparators built at 32: half the graph connectivity. Degree
# sets recall and latency together, so that row handicaps ArcadeDB.
#
# THE UNIT-SYSTEM TRAP that caused it, worth restating because it is subtle:
# ArcadeDB's maxConnections is a PER-LAYER bound, while hnswlib DOUBLES M at
# the base layer. maxConnections=32 therefore equals comparator M=16. The lane
# handed one constant to both. When the default went 16->32 to fix ArcadeDB's
# own half-degree bug, deep10m was re-run (07-20) and small was not (07-21).
#
# NO CODE CHANGE NEEDED HERE: COMPARATOR_M (default M//2) already feeds the
# hnswlib-family comparators while M feeds ArcadeDB, and rows now record
# degree_param + degree_family. A plain re-run is matched by construction, and
# fairness_check's F7 will say so.
#
# WHY BOTHER, since nothing published reads small: T5's dense block has exactly
# ONE scale point (DEEP-10M), so the paper cannot currently make a dense
# SCALING claim. A matched SIFT-1M row makes it possible. And under the
# one-version hard cut a knowingly-mismatched row should not sit in the store
# at all.
set -u
OUT=~/q15
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q15 started, pid $$"
ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

DEADLINE=$(( $(date +%s) + 30*3600 ))
log "waiting for Q11-COMPLETE (hard deadline 30 h)"
while ! grep -qa "Q11-COMPLETE" ~/q11/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then log "ABORT: q11 unfinished after 30 h"; exit 1; fi
  grep -qa "ABORT:" ~/q11/queue.log 2>/dev/null && { log "q11 exited on an error path"; exit 1; }
  sleep 60
done
log "q11 finished"
for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

export BENCH_DATA=$HOME/bench-data
export BENCH_DENSE_DATA=/data/dense
export BENCH_DENSE_M=32
[ -d "$BENCH_DATA/dense" ] || { log "ABORT: no dense corpus"; exit 1; }
GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "26.8.1" ] || { log "ABORT: image is not 26.8.1"; exit 1; }

t0=$(date +%s)
log "START l3d small, all backends, N=5, BENCH_DENSE_M=32 (comparators get M//2=16)"
timeout 28800 python3 runner.py --lanes l3d --scale small \
    --backends "arcadedb_dense_embedded,arcadedb_dense_server,chroma_dense,lancedb_dense,sqlite_vec_dense,duckdb_vss_dense,qdrant_dense,milvus_dense" \
    --reps 5 --tier paper --workers 0 > "$OUT/l3d_small.log" 2>&1
rc=$?; el=$(( $(date +%s) - t0 ))
[ $rc -eq 0 ] && log "DONE  l3d small rc=$rc ${el}s" || { log "FAIL  l3d small rc=$rc ${el}s"; tail -20 "$OUT/l3d_small.log" >> "$LOG"; }

log "--- F7: is the degree matched now? ---"
python3 fairness_check.py 2>&1 | grep -A9 "F7" | head -14 | tee -a "$LOG"
log "Q15-COMPLETE"
