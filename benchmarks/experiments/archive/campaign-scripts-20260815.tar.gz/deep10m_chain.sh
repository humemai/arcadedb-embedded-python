#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "DEEP-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "DEEP-ABORT foreign-container"; exit 1; }
echo "=== DEEP-10M campaign $(date -u +%FT%TZ) ==="
BENCH_DENSE_DATA=/data/dense BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l3d --scale deep10m --reps 5 --tier sweep --workers 2 \
  || { echo "retrying serial"; BENCH_DENSE_DATA=/data/dense BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
       python3 -u runner.py --lanes l3d --scale deep10m --reps 5 --tier sweep --workers 1; }
echo "campaign rc=$?"
echo "DEEP10M-COMPLETE"
