#!/bin/bash
# Profile the dense build PER PHASE, which is what #5577 now needs.
#
# Measured across three runs, the DEEP-10M build is:
#   ~7%  ArcadeDB ingest
#   ~38% JVector node insertion   (logs "Graph build building: n/N" every 5 s)
#   ~55% something that logs NOTHING, at ~600% CPU, for ~24 minutes
#
# The profile posted on #5577 was one 900 s window armed 5 minutes in, so it
# straddled the insertion/silent boundary and its 30.3% LongAdder figure is a
# blend of two phases in unknown proportion. That is why the whole-build
# extrapolation was withdrawn. This job replaces it with one profile per phase.
#
# The boundary emits no log line, so it is detected as "the progress lines
# stopped growing", which is the only signal there is.
set -u
PROF=$HOME/profiling/async-profiler-4.0-linux-x64
OUT=$HOME/profiling/buildphase
exec >> "$HOME/profiling/queue42.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue42 waiting for QUEUE41-DONE"
for i in $(seq 1 2000); do
  grep -qa "QUEUE41-DONE" "$HOME/profiling/queue41.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue41.sh" >/dev/null || { say "queue41 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
mkdir -p "$OUT"

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
say "engine version under test: ${VER:-UNKNOWN}"

N=bp_phase
docker rm -f $N >/dev/null 2>&1
guard
docker run -d --name $N --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
  -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
  -v "$PROF:/prof:ro" -v "$OUT:/pout" \
  -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 -e ARCADEDB_HEAP=24g \
  icde-bench:arcadedb python -u fp32_dev22_driver.py >/dev/null \
  || die "container failed to start"

progress_lines() { docker logs $N 2>&1 | grep -ac "Graph build building" || true; }

# --- wait for insertion to start -------------------------------------------
say "waiting for insertion to start"
for i in $(seq 1 240); do
  [ "$(progress_lines)" -gt 3 ] && { say "insertion started"; break; }
  docker ps -q -f name=$N | grep -q . || { say "DIED before insertion"; docker logs $N 2>&1 | tail -5; exit 1; }
  sleep 10
done
[ "$(progress_lines)" -gt 3 ] || die "insertion never started"

# --- phase 1: insertion ----------------------------------------------------
# 600 s sits comfortably inside the ~1020 s insertion phase even if arming is late.
docker exec $N /prof/bin/asprof start -e cpu 1 >/dev/null 2>&1 || die "asprof start (insertion)"
say "profiling INSERTION for 600 s"
sleep 600
docker exec $N /prof/bin/asprof stop -o collapsed -f "/pout/insertion_${VER}.collapsed" 1 >/dev/null 2>&1 \
  && say "insertion profile written" || say "insertion profile FAILED"

# --- wait for the boundary -------------------------------------------------
# No log line marks it, so: progress-line count unchanged for 90 s.
say "watching for the insertion/silent boundary"
last=$(progress_lines); still=0
for i in $(seq 1 400); do
  sleep 30
  now=$(progress_lines)
  if [ "$now" = "$last" ]; then still=$((still+1)); else still=0; last=$now; fi
  [ "$still" -ge 3 ] && { say "boundary detected after $now progress lines"; break; }
  docker ps -q -f name=$N | grep -q . || { say "build finished before the boundary was caught"; break; }
done

# --- phase 2: the silent phase ---------------------------------------------
if docker ps -q -f name=$N | grep -q .; then
  docker exec $N /prof/bin/asprof start -e cpu 1 >/dev/null 2>&1 \
    && { say "profiling SILENT phase for 600 s"
         sleep 600
         docker exec $N /prof/bin/asprof stop -o collapsed -f "/pout/silent_${VER}.collapsed" 1 >/dev/null 2>&1 \
           && say "silent profile written" || say "silent profile FAILED"; } \
    || say "asprof start (silent) failed"
else
  say "container exited; no silent-phase profile"
fi

# let the build finish so build_s is recorded
for i in $(seq 1 240); do docker ps -q -f name=$N | grep -q . || break; sleep 30; done
docker logs $N 2>&1 | grep -a "^RESULT" | tail -3
docker rm -f $N >/dev/null 2>&1

say "=== per-phase top frames ==="
python3 - <<'PY'
import collections, glob, os
def top(p, n=8):
    c = collections.Counter(); tot = 0
    for line in open(p, errors="ignore"):
        st, _, v = line.rpartition(" ")
        try: v = int(v)
        except ValueError: continue
        tot += v; c[st.split(";")[-1]] += v
    return c, tot
files = sorted(glob.glob("/home/tk/profiling/buildphase/*.collapsed"))
if not files:
    print("  no profiles written")
for p in files:
    c, tot = top(p)
    if not tot:
        print(f"\n== {os.path.basename(p)}: EMPTY"); continue
    print(f"\n== {os.path.basename(p)}  ({tot:,} samples)")
    for f, v in c.most_common(10):
        print(f"   {100*v/tot:5.1f}%  {f.split('/')[-1][:58]}")
# The question #5577 now turns on: does the silent phase evaluate distances,
# and does VectorCache.get's counter run there too?
for p in files:
    tot = 0; la = 0; sq = 0
    for line in open(p, errors="ignore"):
        st, _, v = line.rpartition(" ")
        try: v = int(v)
        except ValueError: continue
        tot += v
        if "LongAdder" in st: la += v
        if "squareDistance" in st: sq += v
    if tot:
        print(f"\n  {os.path.basename(p)}: LongAdder {100*la/tot:.1f}%, "
              f"squareDistance {100*sq/tot:.1f}%")
PY
say "QUEUE42-DONE"
