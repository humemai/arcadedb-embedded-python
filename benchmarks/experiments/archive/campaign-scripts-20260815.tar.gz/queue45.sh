#!/bin/bash
# Replace T5's server dense row. queue40 re-issued, with both of its faults fixed.
#
# queue40 failed with ModuleNotFoundError: requests. Server-mode benchmarks run
# from icde-bench:client (which carries requests, the drivers and the wire
# clients); icde-bench:arcadedb carries the embedded wheel and nothing else. I
# used the wrong one.
#
# It also exposed the larger problem it was written to fix. The server image on
# this box is still sha256:236ff887..., built 2026-07-25 23:58 UTC, which is
# exactly the image whose build-cache regression makes T5's 13.3k wrong. Re-
# running against it would have reproduced the bad number and called it
# confirmation. So this pulls a current image FIRST and refuses to run if the
# digest has not moved, because an unchanged digest means there is nothing to
# learn.
set -u
OLDDIGEST="sha256:236ff887903368e64d2e06faec7cb5e5a70b9d2464b746b9751a0d006a171cc2"
exec >> "$HOME/profiling/queue45.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue45 waiting for QUEUE44-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE44-DONE" "$HOME/profiling/queue44.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue44.sh" >/dev/null || { say "queue44 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"

say "pulling a current server image"
docker pull -q arcadedata/arcadedb:26.8.1-SNAPSHOT >/dev/null 2>&1 || say "WARN: pull failed, continuing with what is local"
NEW=$(docker image inspect arcadedata/arcadedb:26.8.1-SNAPSHOT --format '{{index .RepoDigests 0}}' 2>/dev/null)
say "server digest now: $NEW"
say "server digest was: arcadedata/arcadedb@$OLDDIGEST"
case "$NEW" in
  *"$OLDDIGEST"*)
    die "server image digest unchanged; the published cell was measured on THIS image, so re-running it proves nothing. Wait for a newer SNAPSHOT." ;;
esac
say "digest moved, the re-measure is meaningful"

# The image must postdate the auto-sizing fix (5d9f9ff72f, 2026-07-26 10:15)
# or we are still on the wrong side of the thing being corrected.
CREATED=$(docker image inspect arcadedata/arcadedb:26.8.1-SNAPSHOT --format '{{.Created}}' 2>/dev/null)
say "server image created: $CREATED"
case "$CREATED" in
  2026-07-2[0-6]*) die "image predates or straddles the 07-26 build-cache fix; not a current line" ;;
esac

OUT=$HOME/profiling/srv_dense_current; mkdir -p "$OUT"
echo "$NEW" > "$OUT/server_digest.txt"
echo "$CREATED" > "$OUT/server_created.txt"

guard
timeout 28800 docker run --rm --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
  -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" -v "$OUT:/pout" \
  -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 -e ARCADEDB_HEAP=24g \
  icde-bench:client python -u l3d_dense.py \
    --backend arcadedb_dense_server --scale deep10m \
    --out "/pout/srv_dense_current.json" \
  > "$OUT/run.log" 2>&1
rc=$?
say "SRV-DENSE rc=$rc"
[ $rc -ne 0 ] && grep -aE "^ABORT|Traceback|Error|ModuleNotFound" "$OUT/run.log" | head -5

python3 - <<'PY'
import json, glob
fs = sorted(glob.glob("/home/tk/profiling/srv_dense_current/srv_dense_current.json"))
if not fs:
    print("  no result json")
else:
    d = json.load(open(fs[0]))
    b = d.get("build_s")
    print(f"  build_s = {b}")
    print(f"  p50 = {d.get('query_p50_ms')}  p99 = {d.get('query_p99_ms')}"
          f"  recall = {d.get('recall_at_10')}")
    if isinstance(b, (int, float)) and b:
        print(f"  published cell is 13,349 s -> this is {13349/b:.2f}x faster")
        print(f"  embedded on the fixed line is 2,693 s -> ratio {b/2693:.2f}x")
        if b > 9000:
            print("  *** STILL SLOW: the pre-fix-image explanation does NOT hold; "
                  "the paper correction must be withdrawn ***")
        elif b < 5000:
            print("  -> consistent with the correction: the 13.3k was the "
                  "build-cache regression, not a deployment cost")
PY
say "QUEUE45-DONE"
