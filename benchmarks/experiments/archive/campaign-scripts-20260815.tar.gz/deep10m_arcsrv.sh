#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "ARCSRV-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "ARCSRV-ABORT foreign-container"; exit 1; }
echo "=== DEEP-10M arcadedb server fill $(date -u +%FT%TZ) ==="
BENCH_DENSE_DATA=/data/dense BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l3d --scale deep10m --reps 5 --tier sweep --workers 1 --backends arcadedb_dense_server
echo "rc=$?"
echo "ARCSRV-COMPLETE"
