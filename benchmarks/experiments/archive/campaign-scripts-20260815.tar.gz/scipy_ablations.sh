#!/bin/bash
# SciPy ablation arms, re-measured on released 26.8.1.
#
# WHY THIS EXISTS
# The paper now says: "Every ArcadeDB number in this paper was measured on one
# released version, arcadedb-embedded 26.8.1, in a single session."  That was
# false when written.  Three ArcadeDB numbers in the prose come from ABLATION
# arms that last night's chain never re-ran, because the chain drove run.py at
# its defaults and the ablations are non-default operating points:
#
#   tabular strict-fsync   ~242 ops/s   (dev2 era)
#   graph   strict-fsync   ~539 ops/s   (dev2 era)
#   graph   GAV off        ~476 ms      (dev20 era, driven BY HAND outside run.py)
#
# The GAV pair is worse than stale.  The prose says ablating the view takes the
# suite "from ~165 ms to ~476 ms", while the graph table's OLAP cell -- the same
# suite, view on -- reads 839.6 ms at every measurement date since July 5.  165
# and 839.6 cannot both be the view-on suite median, so one of them is measuring
# something else.  A hand-driven arm outside the orchestrator is the obvious
# suspect and there is no artifact to check it against.  Re-run both arms
# through run.py and the pair becomes comparable by construction.
#
# TWO HARNESS FIXES SHIPPED WITH THIS RUN (both in the repo, not here):
#   run.py       forwards BENCH_GAV, and honours BENCH_RESULTS_DIR.  The GAV
#                ablation could not previously go through the orchestrator at
#                all, which is how it ended up incomparable.  BENCH_RESULTS_DIR
#                keeps ablation rows OUT of results/runs.jsonl: curation takes
#                the newest row per (lane, backend, dataset, workload, rep), so
#                an ablation appended afterwards would quietly become canonical
#                and put a non-default operating point in the headline table.
#   graph_bench  records `gav` unconditionally.  It used to set the key only
#                when a view was actually built, so the BENCH_GAV=0 row carried
#                no field naming its own arm.
#
# SERIAL.  Every number here is a published absolute.  Tier-2 rules apply even
# though the whole thing takes under an hour.
set -u
OUT=~/q3
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "ablations started, pid $$"

SCIPY=~/scipy-bench/experiments
PIN=26.8.1

cd "$SCIPY" || { log "ABORT: no $SCIPY"; exit 1; }

# Same F5 gate as the main chain: verify what is INSTALLED in the image, not
# what some script asked for.  An ablation measured on a different engine line
# than the arm it is compared against is worse than no ablation.
GOT=$(docker run --rm scipy-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "gate: scipy-bench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "$PIN" ] || { log "ABORT: image is not $PIN"; exit 1; }

# The knobs only reach the container if run.py forwards them.  Fail loudly here
# rather than silently measuring the default arm twice and reporting it as an
# ablation -- that failure mode is invisible in the output.
grep -q 'BENCH_GAV' run.py || { log "ABORT: run.py does not forward BENCH_GAV"; exit 1; }
grep -q 'BENCH_RESULTS_DIR' run.py || { log "ABORT: run.py has no BENCH_RESULTS_DIR"; exit 1; }
log "gate: run.py forwards BENCH_GAV and honours BENCH_RESULTS_DIR"

export BENCH_DATA=~/scipy-bench/data

# ---- A1: graph, view OFF --------------------------------------------------
# medium only: that is the tier the paper's graph table reports.  Both workloads
# run because run.py has no workload filter; OLTP is unaffected by the view and
# is simply ignored downstream.
log "A1: START graph GAV=0 (medium, N=5)"
BENCH_RESULTS_DIR=results_abl_gav0 BENCH_GAV=0 \
  timeout 5400 python3 run.py --datasets medium --lanes graph --backends arcadedb --reps 5 \
  > "$OUT/a1_gav0.log" 2>&1
log "A1: DONE rc=$?"

# ---- A2: graph, strict durability ----------------------------------------
# txWalFlush=2 is per-commit fsync, the contract LadybugDB is on by default.
log "A2: START graph txWalFlush=2 (medium, N=5)"
BENCH_RESULTS_DIR=results_abl_strict BENCH_ARCADE_WAL_FLUSH=2 \
  timeout 7200 python3 run.py --datasets medium --lanes graph --backends arcadedb --reps 5 \
  > "$OUT/a2_graph_strict.log" 2>&1
log "A2: DONE rc=$?"

# ---- A3: tabular, strict durability ---------------------------------------
# Pairs against SQLite synchronous=FULL.  SQLite is unchanged at 3.46.1 and has
# no env knob in the harness, so its strict number carries forward under the
# same F9 argument as the other comparator rows; only the ArcadeDB side moved.
log "A3: START tabular txWalFlush=2 (medium, N=5)"
BENCH_RESULTS_DIR=results_abl_strict BENCH_ARCADE_WAL_FLUSH=2 \
  timeout 7200 python3 run.py --datasets medium --lanes tabular --backends arcadedb --reps 5 \
  > "$OUT/a3_tabular_strict.log" 2>&1
log "A3: DONE rc=$?"

# ---- A4: the hybrid workflow ----------------------------------------------
# The paper's headline end-to-end number (~16 ms warm, vector -> SQL -> Cypher).
# Measured on dev3 and never re-run, so it is the fourth number the
# single-version sentence covers.
#
# Flags copied VERBATIM from the dev3 run (scipy_dev3_showcase.sh): --memory 8g,
# no ARCADEDB_HEAP so the script's own 4g default stands, --limit 250000, same
# corpus and cpuset.  A re-measure that also changes the envelope measures two
# things at once and can attribute neither.  The only difference is the engine,
# which is the point.
log "A4: START hybrid showcase (dev3 flags verbatim: --memory 8g, heap 4g, --limit 250000)"
docker run --rm --cpuset-cpus 0-7 --memory 8g \
  -v "$SCIPY:/work" -w /work -v "$BENCH_DATA:/data:ro" \
  scipy-bench:arcadedb python -u hybrid_showcase.py \
  --data-dir /data/stackoverflow-medium/prepared \
  --vectors-dir /data/stackoverflow-medium/vectors \
  --name stackoverflow-medium --limit 250000 \
  > "$OUT/a4_showcase.log" 2>&1
log "A4: DONE rc=$?"

# ---- Summary --------------------------------------------------------------
# Printed here so the arms are readable without re-deriving them from jsonl by
# hand, which is how the 165-vs-839.6 mismatch survived this long.
python3 - >> "$LOG" 2>&1 <<'PY'
import json, os, statistics
H = os.path.expanduser("~/scipy-bench/experiments")
def load(d):
    p = os.path.join(H, d, "runs.jsonl")
    try:
        return [json.loads(l) for l in open(p) if l.strip()]
    except OSError:
        return []
def med(rows, field, **f):
    v = [r[field] for r in rows
         if all(r.get(k) == w for k, w in f.items()) and r.get(field) is not None]
    return (statistics.median(v), min(v), max(v), len(v)) if v else None
base = load("results")
print("\nABLATION SUMMARY (medium tier, 26.8.1)")
for label, rows, filt, field in [
    ("graph OLAP  view ON  (default arm, last night)", base, dict(lane="graph", backend="arcadedb", dataset="medium", workload="olap"), "olap_total_ms"),
    ("graph OLAP  view OFF (A1)", load("results_abl_gav0"), dict(lane="graph", workload="olap"), "olap_total_ms"),
    ("graph OLTP  async    (default arm, last night)", base, dict(lane="graph", backend="arcadedb", dataset="medium", workload="oltp"), "oltp_ops_per_s"),
    ("graph OLTP  fsync    (A2)", load("results_abl_strict"), dict(lane="graph", workload="oltp"), "oltp_ops_per_s"),
    ("tabular OLTP async   (default arm, last night)", base, dict(lane="tabular", backend="arcadedb", dataset="medium", workload="oltp"), "oltp_ops_per_s"),
    ("tabular OLTP fsync   (A3)", load("results_abl_strict"), dict(lane="tabular", workload="oltp"), "oltp_ops_per_s"),
]:
    m = med(rows, field, **filt)
    print("  %-48s %s" % (label,
          "%9.1f [%.1f-%.1f] n=%d" % m if m else "NO DATA"))
PY

log "ABLATIONS-COMPLETE"
