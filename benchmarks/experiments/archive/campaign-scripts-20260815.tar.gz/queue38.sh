#!/bin/bash
# Profile the two query SURFACES over one graph (open-improvements: the graph
# lanes have no profile at all, and the SciPy "parity" claim is unverified).
#
# The driver runs both surfaces at startup and aborts unless they agree on 20
# seeds AND return non-empty results, so a flame graph can never be produced
# for two queries answering different questions -- or for a query that is fast
# because it returns nothing.
set -u
VER="${VER:-26.8.1.dev23}"
PROF=$HOME/profiling/async-profiler-4.0-linux-x64
OUT=$HOME/profiling/flame
exec >> "$HOME/profiling/queue38.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue38 waiting for QUEUE37-DONE"
for i in $(seq 1 1200); do
  grep -qa "QUEUE37-DONE" "$HOME/profiling/queue37.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue37.sh" >/dev/null || { say "queue37 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
[ -f profile_surface_driver.py ] || die "driver not staged"
mkdir -p "$OUT"

for surface in cypher sql; do
  for q in hop2 hop1; do
    guard
    name=prof38_${surface}_${q}
    docker rm -f $name >/dev/null 2>&1
    docker run -d --name $name --cpuset-cpus 0-11 --memory 24g --memory-swap 24g \
      -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
      -v "$PROF:/prof:ro" -v "$OUT:/pout" \
      -e SURFACE=$surface -e SURFACE_QUERY=$q -e BENCH_GRAPH_SCALE=sf1 \
      -e BENCH_GRAPH_SOURCE=ldbc -e BENCH_LDBC_DATA=/data/ldbc \
      -e BENCH_GAV=0 -e PROFILE_SECS=600 -e ARCADEDB_HEAP=8g \
      icde-bench:arcadedb python -u profile_surface_driver.py >/dev/null \
      || { say "$name failed to start"; continue; }

    ready=0
    for i in $(seq 1 180); do
      docker logs $name 2>&1 | grep -qa "QUERY-PHASE-START" && { ready=1; break; }
      docker logs $name 2>&1 | grep -qa "^ABORT" && { say "$name guard tripped:"; docker logs $name 2>&1 | grep -a "^ABORT" | head -2; break; }
      docker ps -q -f name=$name | grep -q . || { say "$name DIED"; docker logs $name 2>&1 | tail -5; break; }
      sleep 10
    done
    if [ $ready -ne 1 ]; then docker rm -f $name >/dev/null 2>&1; continue; fi

    # The driver prints both surfaces' latency before the profile, so every
    # flame graph carries the number it is explaining.
    docker logs $name 2>&1 | grep -aE "^EQUIV-OK|^LATENCY"
    sleep 15
    docker exec $name /prof/bin/asprof start -e cpu 1 >/dev/null 2>&1 || { say "$name asprof start failed"; docker rm -f $name >/dev/null 2>&1; continue; }
    sleep 240
    docker exec $name /prof/bin/asprof stop -o collapsed \
      -f "/pout/graph_${VER}_${surface}_${q}.collapsed" 1 >/dev/null 2>&1 \
      && say "$surface/$q written" || say "$surface/$q asprof stop FAILED"
    docker rm -f $name >/dev/null 2>&1
  done
done

say "=== top frames ==="
python3 - <<'PY'
import collections, glob, os
for p in sorted(glob.glob("/home/tk/profiling/flame/graph_26.8.1.dev23_*.collapsed")):
    c = collections.Counter(); tot = 0
    for line in open(p):
        st, _, v = line.rpartition(" ")
        try: v = int(v)
        except ValueError: continue
        tot += v; c[st.split(";")[-1]] += v
    if not tot:
        print(f"\n== {os.path.basename(p)}: EMPTY"); continue
    print(f"\n== {os.path.basename(p)}  ({tot:,} samples)")
    for f, v in c.most_common(10):
        print(f"   {100*v/tot:5.1f}%  {f.split('/')[-1][:60]}")
PY
say "QUEUE38-DONE"
