#!/bin/bash
# Host health sampler. Runs ON MINI so it survives the laptop disconnecting;
# the laptop only tails its log. Health data is therefore captured even when
# nobody is watching, which is the whole point of running it here.
#
# Emits ONLY on state change or threshold crossing, plus a heartbeat, because a
# monitor that prints every sample gets muted and a monitor that prints only
# good news is indistinguishable from a dead one.
set -u
LOG=$HOME/mini_health.log
say() { echo "[$(date -Is)] $*" >> "$LOG"; }
say "health sampler started, pid $$"

all_idle=0
last_beat=0
prev_state=""

while true; do
  now=$(date +%s)

  # --- host memory / swap / load ---
  read -r avail_kb < <(awk '/^MemAvailable:/{print $2}' /proc/meminfo)
  avail_g=$(( avail_kb / 1024 / 1024 ))
  swap_used_kb=$(awk '/^SwapTotal:/{t=$2} /^SwapFree:/{f=$2} END{print t-f}' /proc/meminfo)
  swap_g=$(( swap_used_kb / 1024 / 1024 ))
  load=$(awk '{printf "%.1f", $1}' /proc/loadavg)
  disk_g=$(df -BG --output=avail "$HOME" | tail -1 | tr -dc '0-9')

  [ "$avail_g" -lt 4 ]  && say "WARN low memory: ${avail_g}GB available"
  [ "$swap_g" -gt 1 ]   && say "WARN swapping: ${swap_g}GB swap in use (benchmark numbers are suspect)"
  [ "$disk_g" -lt 20 ]  && say "WARN low disk: ${disk_g}GB free on \$HOME"
  awk -v l="$load" 'BEGIN{exit !(l>24)}' && say "WARN load average $load on 12 P-threads"

  # --- containers: stuck detection + approaching their memory cap ---
  running=$(docker ps --format '{{.Names}}' 2>/dev/null | tr '\n' ' ')
  idle_n=0; total_n=0
  if [ -n "${running// /}" ]; then
    while IFS='|' read -r name cpu mem; do
      [ -z "$name" ] && continue
      c=${cpu%\%}
      # A cell pegged near 0% CPU for 5 straight minutes is either finished and
      # not reaped, or wedged. Either way it is not making progress.
      # Count idle containers instead of naming one. A client/server cell has a
      # LEGITIMATELY idle client: during Qdrant green-wait the client polls
      # GET /collections/docs twice a second at 0.2% CPU while the server
      # indexes 8.84M vectors at 200%. Flagging the client there is a false
      # alarm on every served backend, which is how a monitor gets muted.
      if awk -v c="$c" 'BEGIN{exit !(c<2.0)}'; then
        idle_n=$(( idle_n + 1 ))
      fi
      total_n=$(( total_n + 1 ))
      # mem is "used / limit"; warn past 95% of the cap, which is where the
      # OOM killer starts making decisions for us.
      u=$(echo "$mem" | awk '{print $1}' | sed 's/[A-Za-z]//g')
      l=$(echo "$mem" | awk '{print $3}' | sed 's/[A-Za-z]//g')
      uu=$(echo "$mem" | awk '{print $1}' | grep -o '[A-Za-z]*$')
      ll=$(echo "$mem" | awk '{print $3}' | grep -o '[A-Za-z]*$')
      if [ "$uu" = "$ll" ] && [ -n "$u" ] && [ -n "$l" ]; then
        awk -v a="$u" -v b="$l" 'BEGIN{exit !(b>0 && a/b>0.95)}' \
          && say "WARN $name at $mem (>95% of cap, OOM risk)"
      fi
    done < <(docker stats --no-stream --format '{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}' 2>/dev/null)
    # Nothing is progressing only when EVERY container in the cell is idle.
    if [ "$total_n" -gt 0 ] && [ "$idle_n" -eq "$total_n" ]; then
      all_idle=$(( all_idle + 1 ))
      if [ "$all_idle" -eq 5 ]; then
        say "STUCK? all $total_n container(s) idle 5 min: $running"
      fi
    else
      all_idle=0
    fi
  fi

  # --- state change: busy <-> idle ---
  state=$([ -n "${running// /}" ] && echo busy || echo idle)
  if [ "$state" != "$prev_state" ]; then
    say "host is now $state ${running:+($running)}"
    prev_state=$state
  fi

  # --- heartbeat, so silence means dead rather than healthy ---
  if [ $(( now - last_beat )) -ge 1800 ]; then
    say "heartbeat: mem ${avail_g}GB free, swap ${swap_g}GB, load $load, disk ${disk_g}GB, $state"
    last_beat=$now
  fi
  sleep 60
done
