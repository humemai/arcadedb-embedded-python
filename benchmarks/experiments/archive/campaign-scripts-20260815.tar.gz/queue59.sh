#!/bin/bash
# q58 moved every native-TS number a long way (q_global 29.6 -> 11.7 ms) and
# TWO things changed at once: the engine went dev21 -> dev23, and the run
# gained a 30 s settle the dev21 files never had (they carry no settle_s key
# at all). Attributing that delta to the engine would be the #109 mistake
# again, where a stale image was published as a deployment cost.
#
# Worse, it is a FAIRNESS problem, not just an attribution one. Nothing else
# in the TS block settles: DuckDB, QuestDB and ArcadeDB's own document path
# are all measured with no post-ingest quiet period. A settled ArcadeDB row
# next to unsettled comparators flatters us by whatever sealing buys, which
# here looks like a lot.
#
# So measure the settle instead of assuming it. Both arms, same engine, same
# data, interleaved because running one arm to completion before the other is
# how the Cypher ratio and the transport probe both acquired order artifacts.
#
#   settle=0   comparable to every other row in the block -> this is what T5
#              should print until the comparators get their own settle steps
#   settle=30  the ablation, disclosed as an ablation
#
# The difference is the sealing cost, and it is also the size of the unfair
# advantage the q58 numbers would have carried into the table.
set -u
exec >> "$HOME/profiling/queue59.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
OUT=results/ts59
mkdir -p "$OUT"

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
[ -n "${VER:-}" ] || die "no engine version"
say "engine $VER"

run_rep() {  # $1 settle_s, $2 label, $3 rep
  local settle=$1 label=$2 rep=$3
  guard
  timeout 3600 docker run --rm --name ts59_${label}_r${rep} \
    --cpuset-cpus 0-11 --memory 20g --memory-swap 20g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e TSBS_LP=/data/tsbs/cpu_influx.lp \
    -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=1 \
    -e TS_SETTLE_S="$settle" -e TS_LAST_AB=1 \
    -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
    -e PROBE_OUT="/work/$OUT/${label}_r${rep}.json" \
    icde-bench:arcadedb python -u l4_native_probe.py >/dev/null 2>&1 \
    && say "$label rep$rep ok" || say "$label rep$rep FAILED"
}

for rep in 1 2 3 4 5; do
  run_rep 0  nosettle "$rep"
  run_rep 30 settled  "$rep"
done

say "=== result ==="
python3 - <<'PY'
import glob, json, statistics as st
arms = {}
for arm in ("nosettle", "settled"):
    rows = []
    for fp in sorted(glob.glob(f"results/ts59/{arm}_r*.json")):
        try:
            rows.append(json.load(open(fp)))
        except Exception:
            pass
    if rows:
        arms[arm] = rows

def med(rows, k):
    v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
    return st.median(v) if v else None

FIELDS = ("ingest_pts_per_s", "q_last_ms", "q_range_ms", "q_global_ms",
          "q_last_unbounded_ms")
for arm, rows in arms.items():
    print(f"  {arm:9} n={len(rows)} engine={rows[0].get('engine_version')} "
          f"cpuset={rows[0].get('cpuset')} heap={rows[0].get('heap')}")
    for f in FIELDS:
        m = med(rows, f)
        if m is not None:
            print(f"      {f:22} {m:12,.2f}")

if len(arms) == 2:
    a, b = arms["nosettle"], arms["settled"]
    print("\n  settle contribution (settled vs nosettle, same engine/data):")
    for f in FIELDS:
        x, y = med(a, f), med(b, f)
        if x and y:
            print(f"    {f:22} {x:10,.2f} -> {y:10,.2f}   {x/y:5.2f}x")
    print("\n  T5 currently prints the dev21 N=3 row: ingest 1.73M,")
    print("  q_last 4.16, q_range 7.33, q_global 29.56 ms, and those files")
    print("  carry no settle_s key, so they are the NOSETTLE treatment.")
    print("  Compare against nosettle above for the engine-only delta;")
    print("  the settled column is an ablation until the comparators")
    print("  (DuckDB, QuestDB, document path) get settle steps too.")
PY
say "QUEUE59-DONE"
