#!/bin/bash
# q16: the three l1 medium cells the 6-hour wall cut off.
#
# WHAT HAPPENED, and it was a budgeting error rather than a defect. q10's
# lane() wraps each runner.py invocation in `timeout 21600` (6 h). l1 at medium
# is 20M rows x 3 backends x 2 workloads x 5 reps = 30 cells, and it completed
# 27 of them in that window at roughly 800 s per cell. It was still working
# when the wall hit: the container it left behind was at 108% CPU compacting
# LSM indexes with fresh log lines every 30 s. Nothing hung; 6 h was simply too
# small a budget for this lane, and I chose it.
#
# THE ORPHAN. `timeout` kills the SUPERVISOR, not the container it spawned, and
# runner.py is what appends rows to runs.jsonl. So the surviving container's
# result could never reach a table no matter how long it ran. It was reaped
# rather than left to finish, which also freed the box for E3.
#
# ONLY THE OLTP WORKLOAD IS SHORT:
#   arcadedb_embedded oltp  has 2,3,5    -> needs r1, r4
#   duckdb            oltp  has 2,3,4,5  -> needs r1
# Every olap cell and every arcadedb_server cell is already at N=5.
#
# TIMEOUT SET TO 4 h FOR THREE CELLS, deliberately generous. The lesson from
# q10 is that a lane timeout should be derived from cells x observed
# per-cell cost, not picked as a round number.
set -u
OUT=~/q16
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q16 started, pid $$"
ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

DEADLINE=$(( $(date +%s) + 36*3600 ))
log "waiting for Q15-COMPLETE (hard deadline 36 h)"
while ! grep -qa "Q15-COMPLETE" ~/q15/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then log "ABORT: q15 unfinished after 36 h"; exit 1; fi
  grep -qa "ABORT:" ~/q15/queue.log 2>/dev/null && { log "q15 exited on an error path"; exit 1; }
  sleep 60
done
log "q15 finished"
for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

export BENCH_DATA=$HOME/bench-data
GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "26.8.1" ] || { log "ABORT: image is not 26.8.1"; exit 1; }

run() {  # label reps backends
  local label=$1 reps=$2 be=$3
  [ -f "$OUT/${label}.done" ] && { log "  skip $label"; return; }
  local t0=$(date +%s)
  log "  START $label (oltp, reps $reps, $be)"
  timeout 14400 python3 runner.py --lanes l1 --scale medium --workloads oltp \
      --backends "$be" --only-reps "$reps" --reps 5 --tier paper --workers 0 \
      > "$OUT/${label}.log" 2>&1
  local rc=$? el=$(( $(date +%s) - t0 ))
  [ $rc -eq 0 ] && { touch "$OUT/${label}.done"; log "  DONE  $label rc=$rc ${el}s"; } \
                || { log "  FAIL  $label rc=$rc ${el}s"; tail -15 "$OUT/${label}.log" >> "$LOG"; }
}

run rep1 1 "arcadedb_embedded,duckdb"
run rep4 4 "arcadedb_embedded"

python3 - >> "$LOG" 2>&1 <<'PY'
import glob, json, os, collections
R = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments/results/raw")
g = collections.defaultdict(set)
for p in glob.glob(os.path.join(R, "l1_*_medium_r*.json")):
    try: j = json.load(open(p))
    except Exception: continue
    g[(j.get("backend"), j.get("workload"))].add(j.get("rep"))
print("\nq16: is l1 medium at N=5 everywhere now?")
short = 0
for k in sorted(g, key=lambda x: str(x)):
    reps = sorted(r for r in g[k] if r is not None)
    flag = "" if len(reps) >= 5 else "   <-- SHORT"
    if len(reps) < 5: short += 1
    print("  %-22s %-5s N=%d %s%s" % (k[0], k[1], len(reps), reps, flag))
print("  cells short of N=5:", short)
PY
log "Q16-COMPLETE"
