#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
bash build_images.sh client > /tmp/client_build.log 2>&1 || { echo "L2-ABORT client-image"; exit 1; }
echo "client image OK"
docker pull -q neo4j@sha256:4bae36aff76271e27fd6a6ed0835413f86a284cd179cfb1cb7d188f5f7533aca >/dev/null || { echo "L2-ABORT neo4j-pull"; exit 1; }
echo "neo4j image OK"
pgrep -x ffmpeg >/dev/null && { echo "L2-ABORT ffmpeg"; exit 1; }
echo "=== L2 SF1 campaign $(date -u +%FT%TZ) ==="
BENCH_GRAPH_SOURCE=ldbc BENCH_GRAPH_DATA=/data/ldbc BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l2 --scale sf1 --reps 5 --tier sweep --workers 3
echo "campaign rc=$?"
echo "L2-SF1-COMPLETE"
