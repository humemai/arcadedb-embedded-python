#!/bin/bash
# queue38 re-issued: Cypher vs SQL MATCH over one graph.
#
# queue38 died 4/4 on "module 'l2_graph' has no attribute 'BACKENDS'". The
# graph lane exports ADAPTERS keyed by adapter .name; only the sparse and dense
# lanes export BACKENDS. Fixed in the driver (3cba0d138e), together with a
# second defect the fix exposed: l2_graph.main() rebinds THREE names for LDBC,
# and the missing one was pick_query_ids, so the seeds were randrange(n) against
# sparse LDBC long ids.
#
# Contract-checked before any bench time, the way queue44 now is.
set -u
VER="${VER:-26.8.1.dev23}"
PROF=$HOME/profiling/async-profiler-4.0-linux-x64
OUT=$HOME/profiling/flame
exec >> "$HOME/profiling/queue49.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue49 waiting for QUEUE48-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE48-DONE" "$HOME/profiling/queue48.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue48.sh" >/dev/null || { say "queue48 gone; proceeding"; break; }
  sleep 60
done
guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
[ -f /tmp/profile_surface_driver_fixed.py ] || die "corrected driver not staged"
cp /tmp/profile_surface_driver_fixed.py profile_surface_driver.py

# CONTRACT CHECK inside the image, before spending build time on it.
docker run --rm -v "$PWD:/work" -w /work -e BENCH_GRAPH_SOURCE=ldbc \
  icde-bench:arcadedb python -c "
import l2_graph, ldbc_snb
for n in ('ADAPTERS','SCALE_PERSONS','gen_persons','gen_edges','pick_query_ids'):
    assert hasattr(l2_graph, n), 'l2_graph missing ' + n
a = l2_graph.ADAPTERS['arcadedb_graph_embedded']
for m in ('connect','build','post_build','run_cypher'):
    assert hasattr(a, m), 'adapter missing ' + m
assert hasattr(ldbc_snb, 'pick_query_ids'), 'ldbc_snb missing pick_query_ids'
print('CONTRACT-OK')
" 2>&1 | grep -q "CONTRACT-OK" || die "l2_graph contract check failed"
say "contract verified"

# QUERY-TEXT CHECK. queue46 passed every API guard and then died on the SQL
# text itself, which no contract check could have caught. Parse both surfaces
# against the engine before committing an hour of builds to them.
docker run --rm -v "$PWD:/work" -w /work icde-bench:arcadedb python -c "
import tempfile, arcadedb_embedded as a
from profile_surface_driver import SQL_READS, CYPHER_READS
db = a.create_database(tempfile.mkdtemp() + '/db')
db.command('sql', 'CREATE VERTEX TYPE Person')
db.command('sql', 'CREATE PROPERTY Person.id LONG')
db.command('sql', 'CREATE EDGE TYPE KNOWS')
for q, txt in SQL_READS.items():
    db.query('sql', txt.format(id=1)).to_json_list()
    print('sql', q, 'parses')
for q, txt in CYPHER_READS.items():
    db.query('opencypher', txt.format(id=1)).to_json_list()
    print('cypher', q, 'parses')
print('QUERIES-OK')
" 2>&1 | tail -6 | grep -q "QUERIES-OK" || die "query text does not parse against an empty schema"
say "query text verified against the engine"

for surface in cypher sql; do
  for q in hop2 hop1; do
    guard
    name=prof49_${surface}_${q}
    docker rm -f $name >/dev/null 2>&1
    docker run -d --name $name --cpuset-cpus 0-11 --memory 24g --memory-swap 24g \
      -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
      -v "$PROF:/prof:ro" -v "$OUT:/pout" \
      -e SURFACE=$surface -e SURFACE_QUERY=$q -e BENCH_GRAPH_SCALE=sf1 \
      -e BENCH_GRAPH_SOURCE=ldbc -e BENCH_LDBC_DATA=/data/ldbc \
      -e BENCH_GAV=0 -e PROFILE_SECS=600 -e ARCADEDB_HEAP=8g \
      icde-bench:arcadedb python -u profile_surface_driver.py >/dev/null \
      || { say "$name failed to start"; continue; }
    ready=0
    for i in $(seq 1 180); do
      docker logs $name 2>&1 | grep -qa "QUERY-PHASE-START" && { ready=1; break; }
      docker logs $name 2>&1 | grep -qa "^ABORT" && { say "$name guard tripped:"; docker logs $name 2>&1 | grep -a "^ABORT" | head -2; break; }
      docker ps -q -f name=$name | grep -q . || { say "$name DIED"; docker logs $name 2>&1 | tail -6; break; }
      sleep 10
    done
    [ $ready -ne 1 ] && { docker rm -f $name >/dev/null 2>&1; continue; }
    docker logs $name 2>&1 | grep -aE "^EQUIV-OK|^LATENCY"
    sleep 15
    docker exec $name /prof/bin/asprof start -e cpu 1 >/dev/null 2>&1 \
      || { say "$name asprof start failed"; docker rm -f $name >/dev/null 2>&1; continue; }
    sleep 240
    docker exec $name /prof/bin/asprof stop -o collapsed \
      -f "/pout/graph_${VER}_${surface}_${q}.collapsed" 1 >/dev/null 2>&1 \
      && say "$surface/$q written" || say "$surface/$q asprof stop FAILED"
    docker rm -f $name >/dev/null 2>&1
  done
done

say "=== top frames ==="
python3 - <<'PY'
import collections, glob, os
for p in sorted(glob.glob("/home/tk/profiling/flame/graph_26.8.1.dev23_*.collapsed")):
    c = collections.Counter(); tot = 0
    for line in open(p, errors="ignore"):
        st, _, v = line.rpartition(" ")
        try: v = int(v)
        except ValueError: continue
        tot += v; c[st.split(";")[-1]] += v
    if not tot:
        print(f"\n== {os.path.basename(p)}: EMPTY"); continue
    print(f"\n== {os.path.basename(p)}  ({tot:,} samples)")
    for f, v in c.most_common(10):
        print(f"   {100*v/tot:5.1f}%  {f.split('/')[-1][:60]}")
PY
say "QUEUE46-DONE"
