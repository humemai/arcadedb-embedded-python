#!/bin/bash
# E3: durability and failover, with artifacts this time.
#
# WHY THIS EXISTS. e3_recovery.py's own header records the defect: E3's paper
# claims ("recovers in under one second ... across five trials", failover
# "0.2--3.3 s", "251 of 251 rows") trace to one hand-written line in
# CAMPAIGN_2026-07.md, because the script only printed to stdout and those logs
# are gone. No queue script ever ran it, and grepping every python file for
# raft/failover/leader returns only that script, which does not cluster. So the
# most precise numbers in the paper had the least evidence behind them.
#
# EVERY HA SETTING IS COPIED from the engine's own containerised load-test
# template, load-tests/.../ContainersTestTemplate.java:534-543. Deliberate
# differences, both of which REMOVE rather than invent:
#   - no -Darcadedb.server.plugins override. The template names GrpcServerPlugin
#     because those tests exercise gRPC; naming a plugin the release image may
#     not carry is a startup failure, and image defaults are what we want.
#   - heap via ARCADEDB_OPTS_MEMORY, never JAVA_OPTS. Setting JAVA_OPTS drops
#     the image's own defaults, which is how a previous run silently lost ZGC.
#
# MODE: "smoke" = 1 trial, small, for the laptop. "full" = 5 trials, mini.
set -u
MODE=${1:-smoke}
OUT=${OUT:-$HOME/q12}
ICDE=${ICDE:-$HOME/repos/humemai/arcadedb-embedded-python/benchmarks/experiments}
mkdir -p "$OUT"
LOG=$OUT/e3.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }

IMG=arcadedata/arcadedb:26.8.1@sha256:49036720b1678b9c7a6dbf22fc34a812c8d7bed15508c22cbb02c0dddc0ca16a
PASS=playwithdata
NET=e3net
NODES=(e3n1 e3n2 e3n3)
SERVERLIST="e3n1:2434,e3n2:2434,e3n3:2434"
if [ "$MODE" = full ]; then TRIALS=5; HEAP=2G; MEM=3g; CPUS=0-11; ROWS=200
else TRIALS=1; HEAP=1G; MEM=2g; CPUS=0-5; ROWS=50; fi
log "E3 mode=$MODE trials=$TRIALS heap=$HEAP"

cleanup() {
  for n in "${NODES[@]}"; do docker rm -f "$n" >/dev/null 2>&1; done
  docker network rm $NET >/dev/null 2>&1
}
trap cleanup EXIT

start_cluster() {
  cleanup
  docker network create $NET >/dev/null 2>&1
  for n in "${NODES[@]}"; do
    docker run -d --name "$n" --network $NET --network-alias "$n" \
      --cpuset-cpus "$CPUS" --memory "$MEM" --memory-swap "$MEM" \
      -p 0:2480 \
      -e ARCADEDB_OPTS_MEMORY="-Xms$HEAP -Xmx$HEAP" \
      -e JAVA_OPTS="\
-Darcadedb.server.rootPassword=$PASS \
-Darcadedb.server.name=$n \
-Darcadedb.backup.enabled=false \
-Darcadedb.typeDefaultBuckets=10 \
-Darcadedb.ha.enabled=true \
-Darcadedb.ha.quorum=majority \
-Darcadedb.server.readinessRequiresHA=true \
-Darcadedb.ha.raft.port=2434 \
-Darcadedb.ha.serverList=$SERVERLIST" \
      "$IMG" >/dev/null || { log "  $n failed to start"; return 1; }
  done
  # Readiness is the template's: /api/v1/health returns 204 once HA is up.
  # readinessRequiresHA=true means a 204 also means the cluster converged.
  # READINESS IS ELECTION, NOT HEALTH. Measured on this image: /api/v1/health
  # returns 204 about two seconds in, while the Raft election is still
  # VOTING_FOR_ME and ha.leader is null; convergence took 10-20 s. The engine's
  # own load-test template waits on health, and setting
  # readinessRequiresHA=true does not change that, so a health-gated harness
  # starts driving a cluster that has no leader yet. That is exactly what the
  # first run did: it reported "no leader before the kill" on a cluster that
  # was perfectly fine and simply had not voted yet.
  #
  # Gate on the thing we actually depend on: electionStatus DONE with a
  # non-null leader. Probe from the host over the published port, because the
  # release image ships no curl (the run before that one silently failed 90
  # readiness probes against a healthy server for that reason).
  local hp1=$(host_port e3n1)
  local leader=""
  for i in $(seq 1 90); do
    leader=$(python3 -c "
import urllib.request, json, base64
A='Basic '+base64.b64encode(b'root:$PASS').decode()
r=urllib.request.Request('http://localhost:$hp1/api/v1/server?mode=cluster')
r.add_header('Authorization', A)
try:
    j=json.load(urllib.request.urlopen(r,timeout=4))
    ha=j.get('ha') or {}
    if ha.get('electionStatus')=='DONE' and ha.get('leader'):
        print(ha['leader'])
except Exception:
    pass" 2>/dev/null)
    [ -n "$leader" ] && break
    for n in "${NODES[@]}"; do
      docker ps -q -f name="^${n}$" | grep -q . || { log "  $n DIED during startup"; docker logs "$n" 2>&1 | tail -15 | tee -a "$LOG"; return 1; }
    done
    sleep 2
  done
  [ -n "$leader" ] || { log "  cluster never elected a leader in 180s"; docker logs e3n1 2>&1 | tail -20 | tee -a "$LOG"; return 1; }
  log "  leader elected: $leader"
  log "  cluster up (3 nodes, quorum=majority)"
}

host_port() { docker port "$1" 2480/tcp | head -1 | sed 's/.*://'; }

# ---- E3b: failover -------------------------------------------------------
for t in $(seq 1 $TRIALS); do
  res="$OUT/e3b_trial${t}.json"
  [ -s "$res" ] && { log "skip e3b trial$t"; continue; }
  log "e3b trial $t: starting cluster"
  start_cluster || { log "e3b trial $t ABORT (cluster)"; continue; }

  # Create the database on one node; HA replicates it. Doing this over HTTP
  # rather than via defaultDatabases avoids three nodes racing to create the
  # same database at boot.
  p1=$(host_port e3n1)
  curl -s -u "root:$PASS" -H 'Content-Type: application/json' \
    -d '{"command":"create database e3ha"}' \
    "http://localhost:$p1/api/v1/server" >/dev/null 2>&1
  sleep 3

  # Map container names to host ports for the host-side driver.
  P1=$(host_port e3n1); P2=$(host_port e3n2); P3=$(host_port e3n3)
  log "  ports: e3n1=$P1 e3n2=$P2 e3n3=$P3"
  python3 "$(dirname "$0")/e3b_failover.py" \
      --nodes "e3n1=localhost:$P1,e3n2=localhost:$P2,e3n3=localhost:$P3" \
      --password "$PASS" \
      --warmup-rows "$ROWS" --out "$res" 2>&1 | tee -a "$LOG"
  cleanup
done

# ---- E3a: kill -9 crash recovery, both durability contracts ---------------
# e3_recovery.py already persists PROBE_OUT (it was fixed for exactly this
# re-run); it was simply never driven by anything. This is that driver.
# Ingest runs until killed, printing WATERMARK <k> per committed transaction,
# so the harness knows what MUST survive. Both contracts are measured because
# the default (async WAL flush) may legitimately lose a bounded suffix after
# the last flush: that is reported as data, not as failure. Corruption or a
# torn row is failure.
E3A_IMG=dbbench:arcadedb
if docker image inspect "$E3A_IMG" >/dev/null 2>&1; then
  for wf in default 2; do
    for t in $(seq 1 $TRIALS); do
      res="$OUT/e3a_${wf}_trial${t}.json"
      [ -s "$res" ] && { log "skip e3a $wf trial$t"; continue; }
      d=$(mktemp -d "${OUT}/e3a_XXXXXX")
      docker rm -f e3a >/dev/null 2>&1
      envflag=""
      [ "$wf" != default ] && envflag="-e BENCH_ARCADE_WAL_FLUSH=$wf"
      docker run -d --name e3a --cpuset-cpus "$CPUS" --memory "$MEM" --memory-swap "$MEM" \
        -v "$ICDE:/work" -w /work -v "$d:/data-local" $envflag \
        -e ARCADEDB_HEAP=1g -e BENCH_ROLE=engine \
        "$E3A_IMG" python -u e3_recovery.py ingest >/dev/null 2>&1
      # Kill only once real work is committed, otherwise the trial measures
      # startup rather than recovery.
      wm=0
      for i in $(seq 1 120); do
        wm=$(docker logs e3a 2>/dev/null | grep -c "^WATERMARK" || echo 0)
        [ "$wm" -ge 200 ] && break
        docker ps -q -f name='^e3a$' | grep -q . || break
        sleep 1
      done
      if [ "$wm" -lt 200 ]; then
        log "  e3a $wf trial$t: only $wm watermarks, skipping"
        docker rm -f e3a >/dev/null 2>&1; rm -rf "$d"; continue
      fi
      docker logs e3a 2>/dev/null | grep "^WATERMARK" | tail -1 > "$OUT/e3a_${wf}_t${t}.watermark"
      docker kill -s KILL e3a >/dev/null 2>&1
      docker rm -f e3a >/dev/null 2>&1
      docker run --rm --name e3averify --cpuset-cpus "$CPUS" --memory "$MEM" --memory-swap "$MEM" \
        -v "$ICDE:/work" -w /work -v "$d:/data-local" -v "$OUT:/out" $envflag \
        -e ARCADEDB_HEAP=1g -e BENCH_ROLE=engine \
        -e PROBE_OUT="/out/$(basename "$res")" \
        "$E3A_IMG" python -u e3_recovery.py verify 2>&1 | tail -3 | tee -a "$LOG"
      rm -rf "$d"
    done
  done
else
  log "e3a SKIPPED: no $E3A_IMG image on this host (expected on the laptop)"
fi

log "E3-COMPLETE"
