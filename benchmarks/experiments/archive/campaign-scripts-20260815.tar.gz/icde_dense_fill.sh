#!/bin/bash
# Fill the two remaining holes in T5's dense block, so the table is one engine
# line under one protocol instead of a patchwork.
#
# After tonight, T5 has cold AND warm for ArcadeDB fp32/int8, Chroma and
# DuckDB-VSS, cold only for Qdrant/Milvus/LanceDB/sqlite-vec, and warm only for
# the ArcadeDB server row. Two of those gaps are cheap to close:
#
#   B1 LanceDB   227 s build. Embedded, already in dbbench:dense. Gives the
#                warm column for the one comparator whose p99 (441 ms) is wild
#                enough that a second pass is genuinely interesting.
#   B2 srv       The server row is the ONLY row with no cold number at all,
#                which is awkward when the whole point of the restructure is
#                that cold is the matched column. Its image is two days old and
#                predates the release, so it is rebuilt on 26.8.1 first.
#
# NOT doing Milvus or sqlite-vec. Milvus needs a server container and pymilvus
# (client image) for a row whose engine did not change, and sqlite-vec at 882
# ms/query is 73 minutes per pass, five of them, for a row that is off the pace
# by two orders of magnitude. Both keep their cold-only rows and the caption
# says a dash means not-run, not zero-gain.
set -u
OUT=~/q5
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "dense fill started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
PIN=26.8.1
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

docker ps -q | grep -q . && { log "ABORT: host busy"; exit 1; }

# ---- B1: LanceDB, embedded, multipass ------------------------------------
if [ -s "$OUT/mp_lancedb_2681.json" ]; then
  log "B1: SKIP (already have mp_lancedb_2681.json)"
else
  log "B1: START lancedb multipass"
  timeout 10800 docker run --rm --name q5_lancedb --label dbbench=1 \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$ICDE:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_MP_BACKEND=lancedb_dense -e BENCH_MP_SCALE=deep10m \
    -e BENCH_ROLE=engine -e PROBE_OUT=/out/mp_lancedb_2681.json \
    dbbench:dense python -u dense_multipass_driver.py > "$OUT/b1_lancedb.log" 2>&1
  log "B1: DONE rc=$?"
fi

# ---- B2: ArcadeDB server, multipass --------------------------------------
# Rebuild first. The current dbbench:arcadedb-srv predates the release, and a
# server row measured on a different engine line than the embedded rows is
# exactly the F5 violation the whole re-measure exists to remove.
# build_images.sh has no arcadedb-srv target: the image was made ad hoc as a
# python base plus the wheel, whose restored server mode is what it exercises.
# Reproduced here from its own docker history rather than guessed, so the only
# thing that changes against the existing image is the pin.
log "B2: rebuilding dbbench:arcadedb-srv on $PIN"
printf 'FROM python:3.12\nRUN pip install --no-cache-dir "arcadedb-embedded==%s" requests numpy pandas pyarrow\nWORKDIR /work\nCMD ["python3"]\n' "$PIN" > "$OUT/Dockerfile.srv"
if docker build -t dbbench:arcadedb-srv -f "$OUT/Dockerfile.srv" "$OUT" > "$OUT/b2_build.log" 2>&1; then
  log "B2: build ok"
else
  log "B2: build FAILED (see b2_build.log); skipping the server arm"
  tail -15 "$OUT/b2_build.log" >> "$LOG"
  log "DENSE-FILL-COMPLETE"
  exit 0
fi

GOT=$(docker run --rm --entrypoint python dbbench:arcadedb-srv -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "B2: image reports ${GOT:-NONE}"
if [ -n "$GOT" ] && [ "$GOT" != "$PIN" ]; then
  log "B2: ABORT the server arm, image is $GOT not $PIN"
else
  log "B2: START arcadedb server multipass"
  timeout 21600 docker run --rm --name q5_srv --label dbbench=1 \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$ICDE:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_MP_BACKEND=arcadedb_dense_server -e BENCH_MP_SCALE=deep10m \
    -e ARCADEDB_HEAP=24g \
    -e BENCH_ROLE=engine -e PROBE_OUT=/out/mp_srv_2681.json \
    dbbench:arcadedb-srv python -u dense_multipass_driver.py > "$OUT/b2_srv.log" 2>&1
  log "B2: DONE rc=$?"
fi

python3 - >> "$LOG" 2>&1 <<'PY'
import json, glob, os, statistics as st
for p in sorted(glob.glob(os.path.expanduser("~/q5/mp_*.json"))):
    try:
        d = json.load(open(p))
    except Exception as e:
        print("  %-24s UNREADABLE (%s)" % (os.path.basename(p), e)); continue
    if len(d) < 2:
        print("  %-24s only %d pass(es)" % (os.path.basename(p), len(d))); continue
    w = st.median([r["p50"] for r in d[1:]])
    print("  %-24s build %8.1f  cold %7.3f  warm %7.3f  (%.2fx)  recall %.4f  ver %s"
          % (os.path.basename(p), d[0]["build_s"], d[0]["p50"], w,
             d[0]["p50"] / w, d[0]["recall_at_10"], d[0].get("lib_version")))
PY

log "DENSE-FILL-COMPLETE"
