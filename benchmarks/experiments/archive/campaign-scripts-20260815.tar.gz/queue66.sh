#!/bin/bash
# queue66: is BmwScorer.siftDown still a quarter of sparse query CPU on dev24?
#
# open-improvements #8 recorded that the sparse bottleneck MOVED rather than
# went away. Between the July profile and dev20:
#     BmwScorer.siftDown   1.2%  -> 24.4%
#     BmwScorer.scan      27.8%  -> 10.4%
#     jbyte_disjoint_arraycopy 10.6% -> 1.3%
# The scan work upstream did (#5467, #5518) landed, and a quarter of the
# remaining CPU is now the top-K heap sift. That is the strongest unfiled
# issue candidate we have, and it is exactly the shape upstream has taken
# twice before, but it must be re-profiled on the CURRENT engine before it is
# filed: dev20 is four dev releases and one release-candidate ago, and
# #5518's intra-query parallelism changed the scan structure underneath it.
#
# If siftDown is still ~24% on dev24, file it with this profile attached.
# If it has fallen, the finding is stale and #8 gets closed rather than filed,
# which is the outcome that costs upstream nothing.
#
# CHAINED behind queue65 with a HARD DEADLINE. A marker wait with no deadline
# is how two watchers sat for six days on logs that were 0 bytes; if q65 has
# not finished in 4 h this reports and exits rather than waiting forever.
set -u
OUT=$HOME/profiling/flame
mkdir -p "$OUT"
say(){ echo "[$(date +%T)] $*"; }

say "queue66 waiting for QUEUE65-DONE (hard deadline 4h)"
for i in $(seq 1 240); do
  grep -qa "QUEUE65-DONE" ~/queue65.log 2>/dev/null && { say "q65 finished"; break; }
  if [ "$i" -eq 240 ]; then
    say "DEADLINE: q65 did not finish in 4h; NOT starting, mini may be busy"
    exit 1
  fi
  sleep 60
done

n=$(docker ps -q | wc -l)
[ "$n" -eq 0 ] || { say "GUARD: $n container(s) still running, refusing to co-run"; exit 1; }

cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || { say "no experiments dir"; exit 1; }
docker rm -f prof_sparse66 >/dev/null 2>&1

# dev24 image so the profile reflects the engine we are about to pin, not dev23.
say "starting sparse small-tier build (bigann SPLADE); profiling attaches at the query phase"
docker run -d --name prof_sparse66 --cpuset-cpus 0-11 --memory 16g --memory-swap 16g \
  -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
  -v "$HOME/profiling/async-profiler-4.0-linux-x64:/prof:ro" -v "$OUT:/pout" \
  -e MODE=sparse -e PROFILE_SECS=300 -e BENCH_SPARSE_SOURCE=bigann \
  -e BENCH_SPARSE_DATA=/data/bigann -e ARCADEDB_HEAP=8g \
  icde-bench:arcadedb-srv python -u profile_query_driver.py >/dev/null 2>&1

found=0
for i in $(seq 1 240); do   # up to 1h for the small-tier build
  docker logs prof_sparse66 2>&1 | grep -qa "QUERY-PHASE-START" && { found=1; break; }
  docker ps -q -f name=prof_sparse66 | grep -q . || {
    say "sparse66 DIED before the query phase"; docker logs prof_sparse66 2>&1 | tail -8; exit 1; }
  sleep 15
done
[ "$found" -eq 1 ] || {
  say "sparse66 NEVER-REACHED-QUERY-PHASE in 1h; not attaching"
  docker logs prof_sparse66 2>&1 | tail -8; docker rm -f prof_sparse66 >/dev/null 2>&1; exit 1; }

sleep 10
docker exec prof_sparse66 /prof/bin/asprof start -e cpu 1 && say "profiling the query phase"
sleep 240
docker exec prof_sparse66 /prof/bin/asprof stop -o collapsed -f /pout/sparse66_query_cpu.collapsed 1 \
  && say "collapsed written"
docker rm -f prof_sparse66 >/dev/null 2>&1

say "=== top frames (self CPU %) ==="
python3 - <<'PY'
import collections, os
p = os.path.expanduser("~/profiling/flame/sparse66_query_cpu.collapsed")
if not os.path.exists(p) or os.path.getsize(p) == 0:
    print("  NO COLLAPSED FILE. Do not report a number."); raise SystemExit
tot = 0
self_ = collections.Counter()
for line in open(p):
    line = line.rsplit(" ", 1)
    if len(line) != 2: continue
    stack, n = line[0], int(line[1])
    tot += n
    self_[stack.split(";")[-1]] += n
print(f"  total samples: {tot:,}")
for frame, n in self_.most_common(14):
    print(f"  {100.0*n/tot:6.2f}%  {frame[:76]}")
sift = sum(n for f, n in self_.items() if "siftDown" in f)
scan = sum(n for f, n in self_.items() if "BmwScorer.scan" in f)
print(f"\n  siftDown total: {100.0*sift/tot:.2f}%   (dev20 was 24.4%)")
print(f"  BmwScorer.scan: {100.0*scan/tot:.2f}%   (dev20 was 10.4%)")
print("  >=20% siftDown -> file it with this profile; well below -> #8 is stale, close it")
PY
say "QUEUE66-DONE"
