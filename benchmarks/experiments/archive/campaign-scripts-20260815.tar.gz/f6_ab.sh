#!/bin/bash
# F6 A/B: did DuckDB's host-sized thread pool actually cost it anything?
#
# One variable. Same image, same cpuset (0-11, the paper's 12 P-threads), same
# 32g medium-tier cap, same lane script, same workload, alternating arms so any
# thermal or cache drift is spread across both rather than loaded onto one.
#
#   arm "20" = PRAGMA threads=20, the pre-F6 default (host count)
#   arm "12" = PRAGMA threads=12, fitted to the cpuset
set -u
REPS=${REPS:-5}
OUT=~/f6_ab
rm -rf $OUT && mkdir -p $OUT
echo "[$(date +%T)] F6 A/B, $REPS reps per arm, alternating"

for r in $(seq 1 "$REPS"); do
  for arm in 20 12; do
    docker run --rm --cpuset-cpus 0-11 --memory 32g --memory-swap 32g \
      -e BENCH_DUCKDB_THREADS="$arm" \
      -v ~/f6_l1_tabular.py:/work/l1_tabular.py:ro \
      -v $OUT:/work/results \
      -w /work icde-bench:duckdb \
      python l1_tabular.py --backend duckdb --workload olap --scale medium \
        --out /work/results/arm${arm}_r${r}.json >/dev/null 2>&1
    s=$?
    v=$(python3 -c "
import json;d=json.load(open('$OUT/arm${arm}_r${r}.json'));print(f\"{d['olap_total_ms']:9.1f} ms  threads={d.get('engine_threads')} cpuset={d.get('cpuset_cpus')}\")" 2>/dev/null || echo "FAILED rc=$s")
    echo "[$(date +%T)] rep$r arm=$arm  $v"
  done
done

echo
python3 - <<'PY'
import json, glob, statistics as st, os
d = os.path.expanduser("~/f6_ab")
res = {}
for f in glob.glob(d + "/arm*_r*.json"):
    arm = os.path.basename(f).split("_")[0][3:]
    res.setdefault(arm, []).append(json.load(open(f))["olap_total_ms"])
print(f"{'arm':>6} {'n':>3} {'median ms':>11} {'min':>10} {'max':>10}")
for arm in ("20", "12"):
    v = sorted(res.get(arm, []))
    if not v: continue
    print(f"{arm:>6} {len(v):>3} {st.median(v):>11.1f} {v[0]:>10.1f} {v[-1]:>10.1f}")
if len(res.get("20", [])) and len(res.get("12", [])):
    a, b = st.median(res["20"]), st.median(res["12"])
    print(f"\n  threads=20 (pre-F6) vs threads=12 (fitted): {a/b:.3f}x")
    print(f"  delta {a-b:+.1f} ms on a {b:.1f} ms baseline ({100*(a-b)/b:+.1f}%)")
    lo20, hi20 = min(res["20"]), max(res["20"])
    lo12, hi12 = min(res["12"]), max(res["12"])
    overlap = not (hi20 < lo12 or hi12 < lo20)
    print(f"  ranges overlap: {overlap}  -> "
          + ("indistinguishable at this N; the oversubscription cost nothing measurable"
             if overlap else "separable; the oversubscription is real"))
PY
echo "[$(date +%T)] F6-AB-DONE"
