#!/bin/bash
# Re-run the dev23 TS matrix with the settle OUTSIDE the ingest timer.
#
# queue36 measured with the settle inside it, so its ingest_s came out exactly
# SETTLE_S high and ingest_pts_per_s read 72k against dev21's 417k on the same
# corpus and arm. That is a 5.8x regression that does not exist. Its QUERY
# numbers are fine (the settle runs before queries either way), so this job
# exists for the ingest axis.
#
# Deploys the corrected probe first, and refuses to run if the deployed copy
# still has the old shape, because re-running with the same bug would just
# produce the same wrong number more confidently.
set -u
VER="${VER:-26.8.1.dev23}"
exec >> "$HOME/profiling/queue43.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

say "queue43 waiting for QUEUE42-DONE"
for i in $(seq 1 2400); do
  grep -qa "QUEUE42-DONE" "$HOME/profiling/queue42.log" 2>/dev/null && { say "marker seen"; break; }
  pgrep -f "bash \./queue42.sh" >/dev/null || { say "queue42 gone; proceeding"; break; }
  sleep 60
done
guard
D=~/repos/humemai/arcadedb-icde/paper-icde/experiments
cd "$D" || die "no experiments dir"

# The corrected probe is staged at /tmp/l4_native_probe_fixed.py by the laptop.
[ -f /tmp/l4_native_probe_fixed.py ] || die "corrected probe not staged"
cp /tmp/l4_native_probe_fixed.py l4_native_probe.py
grep -q "def settle" l4_native_probe.py || die "deployed probe has no settle() method"
grep -q "b.settle()" l4_native_probe.py || die "deployed probe never calls settle() from the driver"
python3 -c "import ast;ast.parse(open('l4_native_probe.py').read())" || die "deployed probe does not parse"
say "corrected probe deployed and verified"

GOT=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
[ "$GOT" = "$VER" ] || die "image has '$GOT', expected '$VER'"
say "image verified: $GOT"

OUT=$HOME/profiling/dev23_ts_fixed; mkdir -p "$OUT"
for tags in 1 10; do
  for arm in objlist objnp prim; do
    case $arm in
      objlist) NP=0; PR=0 ;;
      objnp)   NP=1; PR=0 ;;
      prim)    NP=1; PR=1 ;;
    esac
    OK=0
    for rep in 1 2 3; do
      guard
      timeout 7200 docker run --rm --cpuset-cpus 0-11 --memory 24g --memory-swap 24g \
        -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" -v "$OUT:/pout" \
        -e ARCADEDB_HEAP=6g -e TS_TAGS="$tags" -e TS_NUMPY="$NP" \
        -e TS_PRIMITIVE="$PR" -e TS_SETTLE_S=30 \
        -e PROBE_OUT="/pout/ts_${VER}_${tags}t_${arm}_r${rep}.json" \
        icde-bench:arcadedb python -u l4_native_probe.py \
        > "$OUT/${tags}t_${arm}_r${rep}.log" 2>&1
      rc=$?; [ $rc -eq 0 ] && OK=$((OK+1))
      [ $rc -ne 0 ] && grep -aE "^ABORT|Traceback|Error" "$OUT/${tags}t_${arm}_r${rep}.log" | head -3
    done
    say "TS ${tags}tag $arm OK $OK/3"
  done
done

say "=== summary, and the sanity check that matters ==="
python3 - <<'PY'
import json, glob, statistics, os
ver = "26.8.1.dev23"
print(f"  {'tags':>4} {'arm':8s} {'ingest pts/s':>13s} {'ingest_s':>9s} {'settle':>7s} {'1h ms':>8s} {'12h ms':>8s}")
rows = {}
for tags in (1, 10):
    for arm in ("objlist", "objnp", "prim"):
        fs = sorted(glob.glob(f"/home/tk/profiling/dev23_ts_fixed/ts_{ver}_{tags}t_{arm}_r*.json"))
        if not fs:
            print(f"  {tags:>4} {arm:8s} (no data)"); continue
        rs = [json.load(open(f)) for f in fs]
        m = lambda k: statistics.median([r[k] for r in rs if k in r])
        rows[(tags, arm)] = m("ingest_pts_per_s")
        print(f"  {tags:>4} {arm:8s} {m('ingest_pts_per_s'):13,.0f} {m('ingest_s'):9.2f} "
              f"{m('settle_s'):7.0f} {m('q_range_ms'):8.2f} {m('q_global_ms'):8.2f}")
# The whole point: ingest_s must no longer be ~SETTLE_S above the dev21 figure.
one = rows.get((1, "objlist"))
if one:
    print(f"\n  1-tag objlist: {one:,.0f} pts/s against dev21's 417,393")
    if one < 150_000:
        print("  *** STILL LOW: the settle is not the whole story, investigate "
              "before reporting anything ***")
for arm in ("objlist", "objnp", "prim"):
    a, b = rows.get((1, arm)), rows.get((10, arm))
    if a and b:
        print(f"  {arm}: ten-tag ingest is {b/a:.2f}x the one-tag arm")
PY
say "QUEUE43-DONE"
