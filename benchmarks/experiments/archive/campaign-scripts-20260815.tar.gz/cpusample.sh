#!/bin/bash
# Record how much of the SAME 12-thread cpuset each engine actually uses.
#
# #120 asks whether every runtime honours the cpuset it is given. This asks
# the complementary question, which turns out to be more interesting: given
# an identical allocation, how much of it does each engine take? Early
# observations differ by 6x (DuckDB-VSS at 1203%, ArcadeDB's sparse build at
# 214% of a 1200% ceiling), which is a real engine property rather than a
# harness defect, but it means an identical allocation is used very
# differently and the paper should say so if any number depends on it.
#
# Reads cgroup counters only, so it perturbs nothing.
OUT=$HOME/profiling/cpu_usage.jsonl
for _i in $(seq 1 3200); do   # ~18 h, comfortably past queue64
  docker stats --no-stream --format '{{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}' 2>/dev/null |
  while IFS=$'\t' read -r name cpu mem; do
    [ -z "$name" ] && continue
    printf '{"ts":"%s","container":"%s","cpu_pct":"%s","mem":"%s"}\n' \
      "$(date -u +%H:%M:%S)" "$name" "$cpu" "$mem" >> "$OUT"
  done
  sleep 20
done
