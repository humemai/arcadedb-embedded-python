#!/bin/bash
# q17: is the paper's 0.2-3.3 s ELECTION time rather than recovery time?
#
# q12 measured client-observed unavailability at median 12.46 s (range
# 9.42-18.54, N=5) against a claim of 0.2-3.3 s, with 200/200 acknowledged
# writes surviving every trial. The claim has no artifact, so nobody can say
# which quantity it measured.
#
# THIS DOES NOT REPLACE ONE NUMBER WITH ANOTHER. The harness now records BOTH
# in the same trial:
#   election_s        kill -> surviving cluster reports a new leader, DONE
#   failover_s        kill -> cluster accepts a write
#   client_overhead_s the difference
# If election_s lands near 0.2-3.3 s then the old figure was election time, the
# paper was measuring a different thing rather than being wrong, and both
# belong in the text with their definitions. If election_s is also ~12 s then
# the old number cannot be reconstructed under any reading and gets replaced.
# Either way the answer is decomposed rather than relocated.
#
# Chained after q14 rather than last: it resolves a paper CLAIM, which outranks
# the scale-point runs (q11 tpch10, q15 l3d small) behind it.
set -u
OUT=~/q17
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q17 started, pid $$"

DEADLINE=$(( $(date +%s) + 24*3600 ))
log "waiting for Q14-COMPLETE (hard deadline 24 h)"
while ! grep -qa "Q14-COMPLETE" ~/q14/queue.log 2>/dev/null; do
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then log "ABORT: q14 unfinished after 24 h"; exit 1; fi
  grep -qa "ABORT:" ~/q14/queue.log 2>/dev/null && { log "q14 exited on an error path"; exit 1; }
  sleep 60
done
log "q14 finished"
for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

OUT=$OUT bash ~/e3_run.sh full 2>&1 | tee -a "$LOG"

python3 - >> "$LOG" 2>&1 <<'PY'
import glob, json, os, statistics as st
fs = sorted(glob.glob(os.path.expanduser("~/q17/e3b_trial*.json")))
rows = [json.load(open(f)) for f in fs]
if not rows:
    print("\nNO TRIALS. Do not report a number."); raise SystemExit
print("\nE3b decomposed, N=%d" % len(rows))
print("  %-9s %10s %11s %16s %8s" % ("trial","election_s","failover_s","client_overhead","loss"))
for i, r in enumerate(rows, 1):
    print("  %-9d %10s %11s %16s %8s" % (i, r.get("election_s"), r.get("failover_s"),
          r.get("client_overhead_s"), "NO" if r.get("no_acked_loss") else "YES"))
def med(k):
    v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
    return st.median(v) if v else None
e, f = med("election_s"), med("failover_s")
print("\n  election median  %s s" % e)
print("  failover median  %s s" % f)
print("  PAPER CLAIMS 0.2-3.3 s")
if e is not None:
    if 0.2 <= e <= 3.3:
        print("  -> election time REPRODUCES the claim. The old figure measured")
        print("     election, not recovery. Report both, with definitions.")
    else:
        print("  -> election time does NOT reproduce the claim either.")
        print("     The old number is unreconstructable; replace it.")
PY
log "Q17-COMPLETE"
