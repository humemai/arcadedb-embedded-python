#!/usr/bin/env bash
set -u
echo "=== SCIPY-CHAIN: waiting for ICDE resume to finish ==="
while pgrep -f "[r]esume_sparse" >/dev/null; do sleep 300; done
pgrep -x ffmpeg >/dev/null && { echo "SCIPY-CHAIN-ABORT ffmpeg"; exit 1; }
cd /home/tk/repos/scipy-bench-repo
echo "=== SCIPY-CHAIN: pull + archive ==="
git fetch -q origin arcadedb-2026 && git checkout -q origin/arcadedb-2026 -- experiments/ || echo "WARN pull failed"
[ -d experiments/results ] && cp -a experiments/results ~/scipy-results-2672-archive-$(date +%Y%m%d) && echo "archived"
cd experiments
echo "=== SCIPY-CHAIN: rebuild arcadedb image (dev1) ==="
bash build_images.sh arcadedb > /tmp/scipy_build.log 2>&1 || { echo "SCIPY-CHAIN-ABORT build"; exit 1; }
V=$(docker run --rm scipy-bench:arcadedb pip show arcadedb-embedded 2>/dev/null | awk "/^Version:/{print \$2}")
echo "image version: $V"
[ "$V" = "26.8.1.dev2" ] || { echo "SCIPY-CHAIN-ABORT wrong version $V"; exit 1; }
echo "=== SCIPY-CHAIN: 180-run ==="
BENCH_DATA=/home/tk/scipy-bench/data python3 -u run.py --datasets tiny,small,medium --reps 5 > results/full_run.log 2>&1
echo "run rc=$?"
echo "=== SCIPY-CHAIN: hybrid showcase (cypher) ==="
docker run --rm --cpuset-cpus 0-7 --memory 8g \
  -v /home/tk/repos/scipy-bench-repo/experiments:/work -w /work \
  -v /home/tk/scipy-bench/data:/data:ro scipy-bench:arcadedb \
  python -u hybrid_showcase.py --data-dir /data/stackoverflow-medium/prepared \
  --vectors-dir /data/stackoverflow-medium/vectors --name stackoverflow-medium --limit 250000 \
  > results/hybrid_dev2_cypher.log 2>&1
echo "showcase rc=0"
echo "SCIPY-CHAIN-COMPLETE"
