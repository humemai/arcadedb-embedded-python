#!/bin/bash
set -u
# Chain behind q81: extend the GAV cost curve to 10M vertices.
#
# #5788 reports four sizes (10k/100k/1M/5M) and the trend is already linear at
# ~1.15 us/vertex, so this is confirmation rather than discovery. It is queued
# because it needs NO new code (GavCost.class is already on mini) and the box is
# otherwise idle, not because the issue is waiting on it.
#
# Deliberately NOT queued: anything needing a harness written on the laptop.
# The laptop is intermittent for the next 12 hours, so only work that is already
# shipped runs unattended.
D=/usr/local/lib/python3.12/site-packages/arcadedb_embedded
DEADLINE=$(( $(date +%s) + 21600 ))
while pgrep -f "runner.py --lanes l3d" >/dev/null; do
  [ "$(date +%s)" -gt "$DEADLINE" ] && { echo "CHAIN-ABORT: q81 still running after 6h"; exit 1; }
  sleep 60
done
echo "q81 clear $(date -Is), starting q82 (GAV cost at 10M)"
cd /home/tk/q79 || exit 1
docker run --rm --name q82 --label icde-debug=1 \
  --cpuset-cpus 0-11 --memory 32g --memory-swap 32g \
  -v /home/tk/q79:/work -w /work icde-bench:arcadedb \
  bash -lc "$D/jre/bin/java -Xmx20g -Xms20g -cp '/work:$D/jars/*' GavCost 10000000" \
  > /home/tk/q79/run_10m.log 2>&1
echo "Q82-DONE rc=$? $(date -Is)"
