#!/bin/bash
# #117: measure what a second pass buys the dense COMPARATORS.
#
# T5 prints ArcadeDB's warm passes beside the comparators' cold one, because
# the two sides came from different protocols:
#   comparators  5 independent builds, each 20 warmups + ONE timed pass
#   ArcadeDB     1 build, then 5 passes of the same shape; table uses 2-5
# ArcadeDB fp32 is 4.424 ms on pass 1 and 0.723 on later ones, and the table
# prints 0.723 next to Qdrant's 1.295. Nobody has ever run a comparator twice
# over one index, so we do not know whether Qdrant and Chroma gain the same
# 4-6x or nothing. Until that is measured, neither the current table nor its
# inverse can be defended.
#
# IMAGES ARE NOT INTERCHANGEABLE, which a first draft of this script got
# wrong and would have lost every cell to an ImportError after a 3.5 h wait:
#   icde-bench:dense   chromadb, lancedb, sqlite-vec, duckdb   (embedded)
#   icde-bench:client  qdrant-client, pymilvus, ...            (needs a SERVER)
# So the embedded three run straight, and Qdrant gets its pinned server
# container started and health-gated first, exactly as runner.py does it.
#
# MEMORY IS ALSO UNMATCHED IN THE PUBLISHED TABLE, found while auditing this.
# The DEEP-10M envelope was raised from 28g/16g to 36g/24g between 2026-07-19
# and 2026-07-20, and only ArcadeDB was re-measured under it:
#   all six comparators   2026-07-19   mem 28g  heap 16g
#   arcadedb emb + srv    2026-07-20   mem 36g  heap 24g
# So T5 gives ArcadeDB 29% more container memory than every competitor at the
# scale where memory decides how much index stays cached, while the protocol
# section claims "identical CPU and memory caps per cell". This run therefore
# fixes BOTH axes at once: comparators get the protocol AND the 36g envelope
# ArcadeDB already has.
#
# Served backends get the envelope SPLIT, not doubled: runner.py gives a
# client_server cell server = 0.75 * total and client = the rest, so the pair
# sums to the same 36g an embedded cell gets in one container. A first draft
# of this script gave Qdrant a 36g server PLUS a 12g client, i.e. 48g against
# ArcadeDB's 36g, which would have been the same defect pointed the other way.
#
# SCOPE, stated because a silent cap reads as coverage:
#   run      lancedb, duckdb_vss, chroma  (embedded, cheap)
#   run      qdrant                       (the specialist ArcadeDB is nearest)
#   SKIP     milvus     17.9 ms, four times ArcadeDB's cold pass; no cache
#            effect reorders it against us
#   SKIP     sqlite-vec 882 ms/query, so five passes is 73 minutes of pure
#            query time to confirm a number three orders off the pace
#
# Chains behind queue60 rather than racing it: guard() only waits while a
# container is up, and q60 has gaps between cells that q61 would drive into.
set -u
exec >> "$HOME/profiling/queue61.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

if pgrep -f "bash ./queue60.sh" > /dev/null 2>&1; then
  say "queue60 is running; waiting for it to finish before touching the box"
  while pgrep -f "bash ./queue60.sh" > /dev/null 2>&1; do sleep 60; done
  say "queue60 finished"
fi
guard

cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
OUT=results/dense_mp
mkdir -p "$OUT"

DENSE_IMG=icde-bench:dense
CLIENT_IMG=icde-bench:client
QDRANT_IMG="qdrant/qdrant@sha256:75eab8c4ba42096724fdcfde8b4de0b5713d529dde32f285a1f86fdcb2c9e50c"

# Contract check per image, before any build.
docker run --rm -v "$PWD:/work" -w /work "$DENSE_IMG" python -c "
import chromadb, lancedb, duckdb
import l3d_dense as L
for k in ('chroma_dense','lancedb_dense','duckdb_vss_dense'):
    assert k in L.BACKENDS, k
import dense_multipass_driver
print('dense image ok')
" || die "dense image cannot run the multipass driver"

docker run --rm -v "$PWD:/work" -w /work "$CLIENT_IMG" python -c "
import qdrant_client
import l3d_dense as L
assert 'qdrant_dense' in L.BACKENDS
import dense_multipass_driver
print('client image ok')
" || die "client image cannot run the multipass driver"

run_embedded() {  # $1 backend, $2 label
  local be=$1 label=$2
  local out="$OUT/mp_${label}.json"
  [ -s "$out" ] && { say "$label present, skipping"; return; }
  guard
  say "starting $label (one build, 5 passes)"
  timeout 21600 docker run --rm --name q61_${label} \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_MP_BACKEND="$be" -e BENCH_MP_SCALE=deep10m \
    -e BENCH_ROLE=engine -e PROBE_OUT="/work/$out" \
    "$DENSE_IMG" python -u dense_multipass_driver.py >/dev/null 2>&1 \
    && say "$label ok" || say "$label FAILED"
}

run_qdrant() {
  local out="$OUT/mp_qdrant.json"
  [ -s "$out" ] && { say "qdrant present, skipping"; return; }
  guard
  docker rm -f q61srv >/dev/null 2>&1
  say "starting qdrant server (pinned digest)"
  docker run -d --name q61srv --cpuset-cpus 0-11 --memory 27g --memory-swap 27g \
    "$QDRANT_IMG" >/dev/null || { say "qdrant server FAILED to start"; return; }
  for i in $(seq 1 60); do
    if docker logs q61srv 2>&1 | grep -qE "Qdrant (HTTP|gRPC) listening|Actix runtime found"; then
      say "qdrant server up"; break
    fi
    sleep 5
  done
  if ! docker logs q61srv 2>&1 | grep -qE "Qdrant (HTTP|gRPC) listening|Actix runtime found"; then
    docker logs q61srv 2>&1 | tail -5; docker rm -f q61srv >/dev/null 2>&1
    say "qdrant never became ready"; return
  fi
  say "starting qdrant (one build, 5 passes)"
  timeout 21600 docker run --rm --name q61_qdrant \
    --network container:q61srv \
    --cpuset-cpus 0-11 --memory 9g --memory-swap 9g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_SERVER_HOST=localhost \
    -e BENCH_MP_BACKEND=qdrant_dense -e BENCH_MP_SCALE=deep10m \
    -e BENCH_ROLE=client -e PROBE_OUT="/work/$out" \
    "$CLIENT_IMG" python -u dense_multipass_driver.py >/dev/null 2>&1 \
    && say "qdrant ok" || say "qdrant FAILED"
  docker rm -f q61srv >/dev/null 2>&1
}

run_embedded lancedb_dense    lancedb
run_embedded duckdb_vss_dense duckvss
run_embedded chroma_dense     chroma
run_qdrant

say "=== result ==="
python3 - <<'PY'
import glob, json, statistics as st
ARCADE = {"arcade-fp32": (4.424, 0.723), "arcade-int8": (3.010, 0.746)}
rows = {}
for fp in sorted(glob.glob("results/dense_mp/mp_*.json")):
    try:
        reps = json.load(open(fp))
    except Exception:
        continue
    name = fp.split("mp_")[1].replace(".json", "")
    cold = [r["p50"] for r in reps if r.get("rep") == 1]
    warm = [r["p50"] for r in reps if r.get("rep", 0) >= 2]
    if cold and warm:
        rows[name] = (cold[0], st.median(warm))

print("  what a second pass buys each engine (one build, five passes)\n")
print(f"  {'engine':12} {'pass1 cold':>11} {'passes2-5':>11} {'gain':>7}")
for k, (c, w) in sorted(rows.items()):
    print(f"  {k:12} {c:11.3f} {w:11.3f} {c/w:6.2f}x")
print("  -- ArcadeDB, same protocol, from the existing overlay --")
for k, (c, w) in ARCADE.items():
    print(f"  {k:12} {c:11.3f} {w:11.3f} {c/w:6.2f}x")

if rows:
    both = dict(rows); both.update(ARCADE)
    print("\n  MATCHED RANKINGS (lower is better):")
    for label, idx in (("cold  (pass 1)", 0), ("warm  (2-5)", 1)):
        board = sorted((v[idx], k) for k, v in both.items())
        print(f"    {label:15} " + "  ".join(f"{k} {v:.2f}" for v, k in board))
    ca = sorted((v[0], k) for k, v in both.items())
    wa = sorted((v[1], k) for k, v in both.items())
    rc = [k for _, k in ca].index("arcade-fp32") + 1
    rw = [k for _, k in wa].index("arcade-fp32") + 1
    print(f"\n  arcade-fp32 ranks {rc} cold and {rw} warm, of {len(both)} measured.")
    if rc == rw:
        print("  Same rank both ways: the operating point does not change the")
        print("  claim, and T5 can keep the warm numbers with the protocol")
        print("  disclosed and the comparators re-run to match.")
    else:
        print("  RANK DEPENDS ON THE OPERATING POINT. The table must lead with")
        print("  one point applied to every engine, and say which.")
    print("\n  NOTE: milvus and sqlite-vec were not re-run (see script header);")
    print("  both sit far enough off the pace that no cache pass reorders them.")
PY
say "QUEUE61-DONE"
