#!/bin/bash
# The one dense arm last night's chain did not produce: qdrant, matched protocol.
#
# WHAT WENT WRONG. queue2's P4 ran
#     run_mp p4_qdrant qdrant_dense dbbench:dense ...
# and it died in two seconds with ModuleNotFoundError: qdrant_client. That was
# my error, not a missing dependency: qdrant-client lives in dbbench:CLIENT
# (build_images.sh line 18), because qdrant is a SERVER backend driven over the
# network, while dbbench:dense is the embedded-library image. The backend also
# needs BENCH_SERVER_HOST and a server container to point it at, neither of
# which P4 supplied. Nothing about the image needs changing.
#
# Recipe copied from queue61, which ran this arm successfully, including the
# memory split: server 27g + client 9g = 36g, the same total envelope the
# embedded arms get (F1). Splitting it any other way would hand qdrant a
# different budget than ArcadeDB and duckdb-vss got last night.
#
# Qdrant's engine has NOT changed, so this is a provenance and protocol re-run,
# not a re-measure of a moved engine -- same argument as chroma and duckvss in
# P4. It matters because the arm is missing entirely, and a dense table without
# the strongest specialist in it is a weaker claim than one with it.
set -u
OUT=~/q4
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "qdrant re-run started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
QDRANT_IMG="qdrant/qdrant@sha256:75eab8c4ba42096724fdcfde8b4de0b5713d529dde32f285a1f86fdcb2c9e50c"
CLIENT_IMG=dbbench:client
DEST="$OUT/mp_qdrant_2681.json"

cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

# Do not start on a busy host: every number here is a published percentile.
docker ps -q | grep -q . && { log "ABORT: foreign containers running"; exit 1; }

# Contract check FIRST. This is exactly what P4 skipped, and skipping it is why
# a two-second failure was only noticed hours later.
docker run --rm -v "$PWD:/work" -w /work "$CLIENT_IMG" python -c "
import qdrant_client
import l3d_dense as L
assert 'qdrant_dense' in L.BACKENDS, 'qdrant_dense missing from BACKENDS'
import dense_multipass_driver
print('client image ok:', qdrant_client.__version__ if hasattr(qdrant_client,'__version__') else 'ver?')
" 2>&1 | tee -a "$LOG" | grep -q "client image ok" \
  || { log "ABORT: $CLIENT_IMG cannot run the multipass driver"; exit 1; }

docker rm -f q4srv >/dev/null 2>&1
log "starting qdrant server (pinned digest, 27g)"
docker run -d --name q4srv --cpuset-cpus 0-11 --memory 27g --memory-swap 27g \
  "$QDRANT_IMG" >/dev/null || { log "ABORT: server failed to start"; exit 1; }

ready=0
for i in $(seq 1 60); do
  if docker logs q4srv 2>&1 | grep -qE "Qdrant (HTTP|gRPC) listening|Actix runtime found"; then
    ready=1; log "qdrant server up after $((i*5))s"; break
  fi
  docker ps -q -f name=q4srv | grep -q . || { log "server DIED"; break; }
  sleep 5
done
if [ $ready -ne 1 ]; then
  docker logs q4srv 2>&1 | tail -8 | tee -a "$LOG"
  docker rm -f q4srv >/dev/null 2>&1
  log "ABORT: qdrant never became ready"
  exit 1
fi

log "START qdrant multipass (one build, 5 passes, deep10m)"
timeout 21600 docker run --rm --name q4_qdrant \
  --network container:q4srv \
  --cpuset-cpus 0-11 --memory 9g --memory-swap 9g \
  -v "$PWD:/work" -w /work -v "$HOME/bench-data:/data:ro" \
  -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
  -e BENCH_SERVER_HOST=localhost \
  -e BENCH_MP_BACKEND=qdrant_dense -e BENCH_MP_SCALE=deep10m \
  -e BENCH_ROLE=client -e PROBE_OUT=/work/results/mp_qdrant_2681.json \
  "$CLIENT_IMG" python -u dense_multipass_driver.py > "$OUT/qdrant.log" 2>&1
rc=$?
log "DONE qdrant rc=$rc"
docker rm -f q4srv >/dev/null 2>&1

if [ -s "$ICDE/results/mp_qdrant_2681.json" ]; then
  cp "$ICDE/results/mp_qdrant_2681.json" "$DEST"
  python3 - "$DEST" >> "$LOG" 2>&1 <<'PY'
import json, statistics as st, sys
d = json.load(open(sys.argv[1]))
w50 = st.median([r["p50"] for r in d[1:]]); w99 = st.median([r["p99"] for r in d[1:]])
print("QDRANT deep10m: build %.1fs  cold p50 %.3f  warm p50 %.3f  (cold/warm %.2fx)"
      % (d[0]["build_s"], d[0]["p50"], w50, d[0]["p50"] / w50))
print("                cold p99 %.3f  warm p99 %.3f  recall@10 %.4f  version %s"
      % (d[0]["p99"], w99, d[0]["recall_at_10"], d[0].get("lib_version")))
PY
else
  log "NO OUTPUT: see $OUT/qdrant.log"
  tail -15 "$OUT/qdrant.log" >> "$LOG" 2>/dev/null
fi

log "QDRANT-COMPLETE"
