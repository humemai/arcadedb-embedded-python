#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "CURVE-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "CURVE-ABORT foreign"; exit 1; }
for MC in 16 32; do
  echo "=== curves mc=$MC $(date -u +%FT%TZ) ==="
  docker run --rm --cpuset-cpus 0-11 --memory 28g --label icde-bench=1 -e ARCADEDB_HEAP=16g \
    -v $PWD:/work -w /work -v /home/tk/icde-data:/data:ro -e BENCH_DENSE_DATA=/data/dense \
    icde-bench:arcadedb python -u probe_dense_curves.py --mc $MC --out /work/results/dense_curves.jsonl \
    >> /tmp/dense_curves.log 2>&1 || { echo "CURVE-FAIL mc=$MC"; tail -5 /tmp/dense_curves.log; }
done
echo "CURVES-COMPLETE"
