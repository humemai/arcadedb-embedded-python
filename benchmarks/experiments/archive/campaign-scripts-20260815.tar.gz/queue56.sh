#!/bin/bash
# #109: replace T5's server-dense disclaimer with a number.
#
# T5 prints a server dense build of 13,349 s and the paper currently has to
# explain it away: that image (build 8bd63ccc8, 2026-07-25 19:58) sits between
# the commit that bounded the HNSW build cache (0d1bca913a, 07-23, which slows
# fp32 builds by re-reading vectors from documents) and the commit that fixed
# it by auto-sizing (5d9f9ff72f, 07-26). So the cell compared two engines and
# labelled the difference "server".
#
# The current SNAPSHOT is build bd0ba0d233, dated 2026-07-31 01:50, which is on
# the far side of the fix. Verified by querying /api/v1/server on the pulled
# image before writing this, not by trusting the tag.
#
# Contract traps this path has hit before, all checked below:
#   - `requests` is NOT in icde-bench:arcadedb, it is in icde-bench:client
#     (queue40 died on the import)
#   - BENCH_SERVER_HOST is required, and needs a server container to point at
#     (queue45 died on the KeyError)
#   - the driver needs the dense dataset mounted and a 24g server heap to match
#     the embedded row it is compared against
set -u
OUT=$HOME/profiling/flame
RES=results/srv109
exec >> "$HOME/profiling/queue56.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
mkdir -p "$RES"

SRV_IMG="arcadedata/arcadedb:26.8.1-SNAPSHOT"
CLIENT_IMG="icde-bench:client"

# 1. the client image must have requests AND be able to import the driver's deps
docker run --rm -v "$PWD:/work" -w /work "$CLIENT_IMG" python -c "
import requests, numpy
import l3d_dense
assert 'arcadedb_dense_server' in l3d_dense.BACKENDS, 'server backend missing'
print('client contract ok: requests', requests.__version__, 'numpy', numpy.__version__)
" || die "client image cannot run the driver"

# 2. the driver file must exist where we will mount it
# On mini the drivers live at the top level of experiments/; the drivers/
# subdirectory is the tracked copy in the repo. Accept either.
SRC=""
for c in srv5413_driver.py drivers/srv5413_driver.py; do [ -f "$c" ] && { SRC="$c"; break; }; done
[ -n "$SRC" ] || die "srv5413_driver.py not found at top level or in drivers/"
say "driver source: $SRC"
cp "$SRC" srv109_driver.py
sed -i 's#/pout/srv5413_#/pout/srv109_#g' srv109_driver.py
grep -q "srv109_" srv109_driver.py || die "output path rewrite failed"

# 3. start the server on the CURRENT image, 24g heap to match the embedded row
docker rm -f srv109 >/dev/null 2>&1
docker run -d --name srv109 --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
  -e ARCADEDB_OPTS_MEMORY="-Xms24g -Xmx24g" \
  -e JAVA_OPTS="-Darcadedb.server.rootPassword=icdebench \
-Darcadedb.server.defaultDatabases=bench[root] \
-Darcadedb.queryMaxHeapElementsAllowedPerOp=5000000" \
  "$SRV_IMG" >/dev/null || die "server failed to start"

for i in $(seq 1 60); do
  v=$(docker run --rm --network container:srv109 "$CLIENT_IMG" \
      python -c "
import requests,sys
try:
    r=requests.get('http://localhost:2480/api/v1/server',auth=('root','icdebench'),timeout=5).json()
    print(r.get('version','?'))
except Exception: sys.exit(1)" 2>/dev/null)
  [ -n "$v" ] && { say "server up: $v"; break; }
  sleep 5
done
[ -n "${v:-}" ] || { docker logs srv109 2>&1 | tail -8; docker rm -f srv109 >/dev/null 2>&1; die "server never answered"; }

# Record what we are actually measuring, before measuring it.
# The 500 that killed the first attempt was a missing `bench` database:
# runner.py creates it via -Darcadedb.server.defaultDatabases, which my first
# JAVA_OPTS omitted. A server that answers /server but has no database looks
# healthy until the first command, so check for the database explicitly.
docker run --rm --network container:srv109 "$CLIENT_IMG" python -c "
import requests, sys
r = requests.get('http://localhost:2480/api/v1/databases',
                 auth=('root','icdebench'), timeout=10).json()
dbs = r.get('result', r)
print('databases:', dbs)
sys.exit(0 if 'bench' in str(dbs) else 1)" || { docker rm -f srv109 >/dev/null 2>&1; die "server has no 'bench' database"; }

echo "$v" > "$RES/server_version.txt"
docker inspect --format '{{index .RepoDigests 0}}' "$SRV_IMG" > "$RES/server_digest.txt" 2>/dev/null
say "digest $(cat $RES/server_digest.txt 2>/dev/null | tail -c 24)"

# 4. run the driver in the CLIENT image, sharing the server's network namespace
#    so BENCH_SERVER_HOST=localhost reaches it.
say "starting DEEP-10M server build (expect hours; the old pre-fix number was 13,349 s)"
timeout 43200 docker run --rm --name srv109run \
  --network container:srv109 \
  --cpuset-cpus 0-11 --memory 12g --memory-swap 12g \
  -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" -v "$OUT:/pout" \
  -e BENCH_SERVER_HOST=localhost -e BENCH_DENSE_DATA=/data/dense \
  -e BENCH_DENSE_M=32 \
  "$CLIENT_IMG" python -u srv109_driver.py 2>&1 | tail -40

docker rm -f srv109 >/dev/null 2>&1

say "=== result ==="
python3 - <<'PY'
import glob, json, os, statistics as st
fs = sorted(glob.glob(os.path.expanduser("~/profiling/flame/srv109_rep*.json")))
if not fs:
    print("  no reps written")
else:
    rows = [json.load(open(f)) for f in fs]
    b = rows[0].get("build_s")
    p50 = st.median([r["p50"] for r in rows if "p50" in r])
    rec = st.median([r["recall_at_10"] for r in rows if "recall_at_10" in r])
    print(f"  n={len(rows)}  build_s={b}  p50={p50}  recall@10={rec}")
    print(f"  server_version={rows[0].get('server_version')}")
    print(f"  conditions: cpuset={rows[0].get('cpuset')} heap={rows[0].get('heap')} "
          f"mem_cap={rows[0].get('mem_cap')}")
    print(f"\n  T5 currently prints 13,349 s for this cell, measured on build")
    print(f"  8bd63ccc8 which predates the auto-sizing fix (5d9f9ff72f).")
    if b:
        print(f"  this run: {b} s  ->  {13349.05/float(b):.2f}x faster than the pre-fix cell")
PY
say "QUEUE56-DONE"
