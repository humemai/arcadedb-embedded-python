#!/bin/bash
# The last hole in T5's dense block: the ArcadeDB SERVER arm under the matched
# one-build/five-pass protocol, so the server row gets a cold column like every
# other row.
#
# TWICE-BURNED NOTE. This arm has now failed twice, both times mine, both times
# the same mistake in a different costume:
#   q2 P4  qdrant  -> ran a SERVER backend on dbbench:dense, which has no client
#                     library and no server container.
#   q5 B2  arcsrv  -> ran a SERVER backend as if it were embedded, so
#                     l3d_dense.py died on os.environ["BENCH_SERVER_HOST"].
# A server backend needs three things and this script supplies all three:
# a server container, a client image that can reach it, and BENCH_SERVER_HOST.
#
# F5, and why the image changed. T5's existing server row was measured against
# arcadedata/arcadedb:26.8.1-SNAPSHOT@sha256:5b98135... which matched the dev2
# wheel. The embedded rows are now the 26.8.1 RELEASE, so the server must be the
# release too or the row compares two engine lines. Pinned by amd64 digest
# rather than by tag, because a tag can be repointed under us.
#
# F1: 27g server + 9g client = 36g, the same total the embedded arms got.
set -u
OUT=~/q6
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "arcadedb server dense re-run started, pid $$"

ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
SRV_IMG="arcadedata/arcadedb:26.8.1@sha256:f54e8d85522f762767899e14cb9b6e39ef435de8216200f058843d41e5930bc9"
CLIENT_IMG=dbbench:client

cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }
docker ps -q | grep -q . && { log "ABORT: foreign containers running"; exit 1; }

# Contract check BEFORE the 60-minute build, not after. This is the check whose
# absence let a two-second failure hide for hours.
docker run --rm -v "$PWD:/work" -w /work "$CLIENT_IMG" python -c "
import requests
import l3d_dense as L
assert 'arcadedb_dense_server' in L.BACKENDS, 'backend missing'
import dense_multipass_driver
print('client image ok')
" 2>&1 | tee -a "$LOG" | grep -q "client image ok" \
  || { log "ABORT: $CLIENT_IMG cannot run the server arm"; exit 1; }

docker rm -f q6srv >/dev/null 2>&1
log "starting arcadedb server (26.8.1 release, digest-pinned, 27g)"
# Server env copied VERBATIM from runner.py's arcadedb_server entry, not
# reconstructed. The first attempt dropped three of its four settings and died
# on HTTP 500 at CREATE VERTEX TYPE, because defaultDatabases is what creates
# the "bench" database the adapter posts to. The others matter too:
#   ARCADEDB_OPTS_MEMORY  heap goes here, NOT in JAVA_OPTS. Setting JAVA_OPTS
#                         also drops the image's ZGC default, which is
#                         deliberate: both deployments then run G1, so the
#                         embedded-vs-server axis isolates transport, not GC.
#   queryMaxHeapElements  the GROUP BY heap guard, needed at this scale.
docker run -d --name q6srv --cpuset-cpus 0-11 --memory 27g --memory-swap 27g \
  -e ARCADEDB_OPTS_MEMORY="-Xms24g -Xmx24g" \
  -e JAVA_OPTS="-Darcadedb.server.rootPassword=dbbenchpass -Darcadedb.server.defaultDatabases=bench[root] -Darcadedb.queryMaxHeapElementsAllowedPerOp=5000000" \
  "$SRV_IMG" >/dev/null || { log "ABORT: server failed to start"; exit 1; }

ready=0
for i in $(seq 1 90); do
  # runner.py's ready_regex, verbatim.
  if docker logs q6srv 2>&1 | grep -qE "HTTP Server started"; then
    ready=1; log "server up after $((i*5))s"; break
  fi
  docker ps -q -f name=q6srv | grep -q . || { log "server DIED"; break; }
  sleep 5
done
if [ $ready -ne 1 ]; then
  docker logs q6srv 2>&1 | tail -10 | tee -a "$LOG"
  docker rm -f q6srv >/dev/null 2>&1
  log "ABORT: server never became ready"; exit 1
fi

# Record what the server actually reports, so the row's provenance is the
# server's own answer and not the tag we asked for.
VER=$(docker run --rm --network container:q6srv "$CLIENT_IMG" python -c "
import requests
r=requests.get('http://localhost:2480/api/v1/server', auth=('root','dbbenchpass'), timeout=30).json()
print(r.get('version','?'))
" 2>/dev/null)
log "server reports version: ${VER:-UNKNOWN}"

# Prove the database exists BEFORE committing to a multi-hour build. The last
# attempt discovered its absence 3 seconds in, which was lucky; at a different
# point in build() it would have burned an hour first.
DBS=$(docker run --rm --network container:q6srv "$CLIENT_IMG" python -c "
import requests
r=requests.get('http://localhost:2480/api/v1/databases', auth=('root','dbbenchpass'), timeout=30).json()
print(','.join(r.get('result',[])))
" 2>/dev/null)
log "server databases: [${DBS:-none}]"
case ",$DBS," in
  *,bench,*) log "gate: database 'bench' exists" ;;
  *) log "ABORT: database 'bench' absent; defaultDatabases did not take"
     docker rm -f q6srv >/dev/null 2>&1; exit 1 ;;
esac

log "START arcadedb_dense_server multipass (one build, 5 passes, deep10m)"
timeout 28800 docker run --rm --name q6_arcsrv \
  --network container:q6srv \
  --cpuset-cpus 0-11 --memory 9g --memory-swap 9g \
  -v "$PWD:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
  -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
  -e BENCH_SERVER_HOST=localhost -e BENCH_SERVER_PORT=2480 \
  -e BENCH_MP_BACKEND=arcadedb_dense_server -e BENCH_MP_SCALE=deep10m \
  -e BENCH_ROLE=client -e PROBE_OUT=/out/mp_arcsrv_2681.json \
  "$CLIENT_IMG" python -u dense_multipass_driver.py > "$OUT/arcsrv.log" 2>&1
rc=$?
log "DONE rc=$rc"
docker rm -f q6srv >/dev/null 2>&1

if [ -s "$OUT/mp_arcsrv_2681.json" ]; then
  python3 - "$OUT/mp_arcsrv_2681.json" >> "$LOG" 2>&1 <<'PY'
import json, statistics as st, sys
d = json.load(open(sys.argv[1]))
w50 = st.median([r["p50"] for r in d[1:]]); w99 = st.median([r["p99"] for r in d[1:]])
print("ARCADEDB SERVER deep10m: build %.1fs  cold p50 %.3f  warm p50 %.3f  (%.2fx)"
      % (d[0]["build_s"], d[0]["p50"], w50, d[0]["p50"]/w50))
print("    cold p99 %.3f  warm p99 %.3f  recall %.4f  version %s"
      % (d[0]["p99"], w99, d[0]["recall_at_10"], d[0].get("engine_version")))
PY
else
  log "NO OUTPUT"; tail -20 "$OUT/arcsrv.log" >> "$LOG" 2>/dev/null
fi

log "ARCSRV-COMPLETE"
