#!/bin/bash
# Wait for the scipy ablations (q3) to finish, then run the qdrant re-run (q4).
# HARD DEADLINE, because a marker-wait with no deadline is a hang that looks
# like patience: if q3 dies without writing ABLATIONS-COMPLETE, this exits and
# says so instead of sitting here forever.
set -u
LOG=~/q4/chain.log
mkdir -p ~/q4
say() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
say "chain armed, waiting on q3 (deadline 3h)"

DEADLINE=$(( $(date +%s) + 10800 ))
while :; do
  if grep -q "ABLATIONS-COMPLETE" ~/q3/queue.log 2>/dev/null; then
    say "q3 complete, starting q4"; break
  fi
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then
    say "DEADLINE: q3 never wrote ABLATIONS-COMPLETE in 3h. Not starting q4."
    tail -5 ~/q3/queue.log 2>/dev/null | tee -a "$LOG"
    exit 1
  fi
  # A dead runner is not a slow runner. If nothing of ours is running AND the
  # marker is absent, q3 died; waiting out the full deadline would waste hours.
  if ! pgrep -f "scipy_ablations.sh" >/dev/null 2>&1; then
    say "q3 process is gone with no completion marker -- it died. Not starting q4."
    tail -5 ~/q3/queue.log 2>/dev/null | tee -a "$LOG"
    exit 1
  fi
  sleep 60
done

exec ~/icde_qdrant.sh
