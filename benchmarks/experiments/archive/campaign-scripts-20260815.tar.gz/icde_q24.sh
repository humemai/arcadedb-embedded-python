#!/bin/bash
# q24: E4 decomposition on 26.8.1. Retry of q23's failed half.
#
# q23 FAILED WITH ModuleNotFoundError: No module named 'requests'. The probe
# needs both `requests` (for the two HTTP arms) and `arcadedb_embedded` (for
# the embedded arm), and no image on this host has both: dbbench:arcadedb has
# the engine, dbbench:client has requests. The original run's launch survives
# nowhere, so this was reconstructed, and that is precisely the risk I flagged
# when writing q23 -- the acceptance check caught it instead of the run
# reporting nothing and looking fine.
#
# requests is installed into the engine image at container start rather than
# swapping images, because the embedded arm must be the SAME wheel the rest of
# the paper measures. Verified interactively: pip install succeeds and both
# imports then resolve against 26.8.1.
set -u
OUT=$HOME/q24; mkdir -p "$OUT"; LOG=$OUT/queue.log
EXP=$HOME/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
IMG=dbbench:arcadedb
log(){ echo "[$(date -Is)] $*" | tee -a "$LOG"; }
die(){ log "ABORT: $*"; exit 1; }
log "q24 started, pid $$"
cd "$EXP" || die "no experiments dir"

VER=$(docker run --rm "$IMG" python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
case "${VER:-}" in "") die "no engine version";; *.dev*) die "F5: $IMG is $VER";; esac
log "gate: $IMG is $VER"
while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 20; done
log "host idle"

mkdir -p "$EXP/results/e4decomp_2681"
log "START e4 decomposition, REPS=15"
timeout 10800 docker run --rm --name q24_e4decomp \
  --cpuset-cpus 0-11 --memory 12g --memory-swap 12g \
  -v "$EXP:/work" -w /work \
  -e REPS=15 -e ARCADEDB_HEAP=6g -e BENCH_ROLE=engine \
  -e OUT=/work/results/e4decomp_2681/decomp_2681.json \
  "$IMG" sh -c 'pip install -q requests >/dev/null 2>&1 && python -u deployment_decomp_probe.py --heap 6g' \
  >"$OUT/e4decomp.log" 2>&1 && log "e4decomp ok" || log "e4decomp FAILED"

log "=== acceptance ==="
python3 - >>"$LOG" 2>&1 <<'PY'
import json, os, re
f = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments/results/e4decomp_2681/decomp_2681.json")
if not os.path.exists(f):
    print("  NO OUTPUT. E4's split stays on the pre-release; do not report it.")
else:
    d = json.load(open(f))
    def vers(o, out=None):
        out = set() if out is None else out
        if isinstance(o, dict):
            for k, v in o.items():
                if isinstance(v, str) and re.search(r"\d+\.\d+\.\d+", v) and any(
                        t in k.lower() for t in ("version", "wheel", "engine", "lib")):
                    out.add(v)
                vers(v, out)
        elif isinstance(o, list):
            for v in o: vers(v, out)
        return out
    v = sorted(vers(d)); arms = sorted(d.get("results", {}))
    print("  versions %s, arms %s, reps %s" % (v, arms, d.get("meta", {}).get("reps")))
    if any(".dev" in x for x in v): print("  REJECT: still pre-release.")
    elif len(arms) < 2: print("  REJECT: fewer than two arms; no split to report.")
    else: print("  ACCEPTED")
PY
log "Q24-COMPLETE"
