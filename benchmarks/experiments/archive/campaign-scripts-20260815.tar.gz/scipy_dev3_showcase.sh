#!/usr/bin/env bash
set -u
pgrep -x ffmpeg >/dev/null && { echo "DEV3-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "DEV3-ABORT foreign-container"; exit 1; }
cd /home/tk/repos/scipy-bench-repo
git fetch -q origin arcadedb-2026 && git checkout -q origin/arcadedb-2026 -- experiments/ || { echo "DEV3-ABORT pull"; exit 1; }
cd experiments
echo "=== DEV3: rebuild arcadedb image ==="
bash build_images.sh arcadedb > /tmp/dev3_build.log 2>&1 || { echo "DEV3-ABORT build"; exit 1; }
V=$(docker run --rm scipy-bench:arcadedb pip show arcadedb-embedded 2>/dev/null | awk "/^Version:/{print \$2}")
echo "image version: $V"
[ "$V" = "26.8.1.dev3" ] || { echo "DEV3-ABORT wrong version $V"; exit 1; }
echo "=== DEV3: showcase full corpus (bidirectional) ==="
docker run --rm --cpuset-cpus 0-7 --memory 8g \
  -v /home/tk/repos/scipy-bench-repo/experiments:/work -w /work \
  -v /home/tk/scipy-bench/data:/data:ro scipy-bench:arcadedb \
  python -u hybrid_showcase.py --data-dir /data/stackoverflow-medium/prepared \
  --vectors-dir /data/stackoverflow-medium/vectors --name stackoverflow-medium --limit 250000 \
  > results/hybrid_dev3_bidi.log 2>&1
echo "showcase rc=$?"
echo "DEV3-SHOWCASE-COMPLETE"
