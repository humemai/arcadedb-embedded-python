#!/bin/bash
# q73 (#124): is the fp32 DEEP-10M COLD latency really ~8.2 ms, or was that one
# unlucky sample?
#
# T5 currently carries 4.424 ms from a dev20 run. q62 on dev23 measured 8.172.
# BOTH are single samples: the protocol is one build plus five passes, and only
# pass 1 is cold, so each run yields exactly one cold observation. An 85% gap
# between two single samples is not a regression, it is two coin flips.
#
# This runs the SAME one-build/five-pass protocol three times on the current
# engine. Three independent builds, therefore three independent cold passes,
# therefore a median and a spread. Whatever T5 ends up saying will have error
# bars behind it for the first time.
#
# Deliberately NOT re-running dev20: comparing across engine lines is what
# produced the stale server-build cell. If the current cold number is stable,
# that is what the paper reports, and the dev20 figure is retired as
# unreproducible rather than defended.
#
# Idle-wait with a hard deadline, because q70 measured questdb while q69 was
# running and produced a story instead of a number.
set -u
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || exit 1
OUT=$HOME/q73; mkdir -p "$OUT"
say(){ echo "[$(date +%T)] $*"; }
die(){ say "FATAL: $*"; exit 1; }

for i in $(seq 1 480); do
  n=$(docker ps -q | wc -l)
  [ "$n" -eq 0 ] && break
  [ "$i" -eq 1 ] && say "waiting for idle ($n container(s))"
  [ "$i" -eq 480 ] && die "busy 8h, not starting"
  sleep 60
done
say "mini idle"

[ -f dense_multipass_driver.py ] || die "driver missing"
VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk "/^Version:/{print \$2}")
[ -n "${VER:-}" ] || die "no engine version"
say "engine $VER, three fp32 builds at deep10m, one cold pass each"

for rep in 1 2 3; do
  out="$OUT/mp_fp32_r${rep}.json"
  [ -s "$out" ] && { say "rep$rep present, skipping"; continue; }
  say "rep$rep: building (expect ~45 min)"
  timeout 43200 docker run --rm --name q73_r${rep} \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_DENSE_QUANT="" -e ARCADEDB_HEAP=24g \
    -e BENCH_MP_BACKEND=arcadedb_dense_embedded -e BENCH_MP_SCALE=deep10m \
    -e BENCH_ROLE=engine -e BENCH_HOST=mini -e PROBE_OUT="/work/$out" \
    icde-bench:arcadedb python -u dense_multipass_driver.py > "$OUT/r${rep}.log" 2>&1 \
    && say "rep$rep ok" || say "rep$rep FAILED rc=$?"
  cp "$out" "$OUT/" 2>/dev/null
done

say "=== cold pass, three independent builds ==="
python3 - <<"PY"
import glob, json, os, statistics as st
cold, warm, builds = [], [], []
for fp in sorted(glob.glob(os.path.expanduser("~/q73/mp_fp32_r*.json"))):
    try: d = json.load(open(fp))
    except Exception: continue
    reps = d if isinstance(d, list) else d.get("reps", [])
    c = [r["p50"] for r in reps if r.get("rep") == 1]
    w = [r["p50"] for r in reps if r.get("rep", 0) >= 2]
    if c: cold.append(c[0])
    if w: warm.append(st.median(w))
    b = [r.get("build_s") for r in reps if r.get("build_s")]
    if b: builds.append(b[0])
if not cold:
    print("  NO COLD SAMPLES. Report nothing."); raise SystemExit
print(f"  n={len(cold)}")
print(f"  cold  median {st.median(cold):7.3f}  all {[round(x,3) for x in cold]}")
if warm: print(f"  warm  median {st.median(warm):7.3f}  all {[round(x,3) for x in warm]}")
if builds: print(f"  build median {st.median(builds):8.1f} s")
print()
print("  T5 today says 4.424 (dev20, single sample). q62 said 8.172 (dev23, single sample).")
print("  If these three cluster, that value replaces the cell and the other is retired.")
print("  If they scatter across both, the cold pass is simply not a stable measurement")
print("  and the honest move is to stop reporting it as one number.")
PY
say "QUEUE73-DONE"
