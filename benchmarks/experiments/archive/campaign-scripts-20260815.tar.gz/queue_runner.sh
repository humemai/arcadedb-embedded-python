#!/usr/bin/env bash
# Self-draining benchmark queue for the ICDE campaign (campaign-scoped tool).
# Jobs: shell scripts in ~/queue/pending, run in lexical order when idle.
# Kill-switch: touch ~/queue/STOP. Teardown at campaign end removes crontab line.
set -u
log() { echo "$(date -u +%FT%TZ) $*" >> "$HOME/queue/queue.log"; }
while true; do
  if [ -e "$HOME/queue/STOP" ]; then
    log "STOP seen, exiting"
    exit 0
  fi
  nc=$(docker ps -q 2>/dev/null | wc -l | tr -dc "0-9")
  np=$(pgrep -f "python3 -u runner[.]py|python3 -u run[.]py|bash build_images[.]sh|python -u l3d_dense|python -u l2_graph|python -u probe_dense|python -u e2_hybrid" 2>/dev/null | wc -l | tr -dc "0-9")
  ff=$(pgrep -x ffmpeg 2>/dev/null | wc -l | tr -dc "0-9")
  if [ "${nc:-0}" = "0" ] && [ "${np:-0}" = "0" ] && [ "${ff:-0}" = "0" ]; then
    job=$(ls "$HOME/queue/pending" 2>/dev/null | sort | head -1)
    if [ -n "$job" ]; then
      mv "$HOME/queue/pending/$job" "$HOME/queue/running/$job"
      log "START $job"
      bash "$HOME/queue/running/$job" > "$HOME/queue/logs/$job.log" 2>&1
      log "END $job rc=$?"
      mv "$HOME/queue/running/$job" "$HOME/queue/done/$job"
    fi
  fi
  sleep 120
done
