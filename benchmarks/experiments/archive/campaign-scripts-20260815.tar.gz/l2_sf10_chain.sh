#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "SF10-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "SF10-ABORT foreign-container"; exit 1; }
echo "=== L2 SF10 campaign $(date -u +%FT%TZ) ==="
BENCH_GRAPH_SOURCE=ldbc BENCH_GRAPH_DATA=/data/ldbc BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l2 --scale sf10 --reps 5 --tier sweep --workers 2 \
  || { echo "retrying serial"; BENCH_GRAPH_SOURCE=ldbc BENCH_GRAPH_DATA=/data/ldbc BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
       python3 -u runner.py --lanes l2 --scale sf10 --reps 5 --tier sweep --workers 1; }
echo "campaign rc=$?"
echo "L2-SF10-COMPLETE"
