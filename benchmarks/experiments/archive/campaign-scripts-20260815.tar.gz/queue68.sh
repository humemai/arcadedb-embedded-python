#!/bin/bash
# queue68: make T5's time-series block one matched, provenanced run.
#
# THE DEFECT (found 2026-08-01, laptop, by reading artifacts not numbers):
# T5's time-series block prints four rows from TWO different runs with
# incompatible provenance.
#
#   ArcadeDB (native TS)      results/ts59/nosettle_r*.json
#                             host=mini cpuset=0-11 heap=8g mem_cap=20g
#                             engine_version=26.8.1.dev23 ts_utc=2026-07-31
#   ArcadeDB (document path)  results/l4_tsbs.jsonl
#   DuckDB                    results/l4_tsbs.jsonl
#   QuestDB                   results/l4_tsbs.jsonl
#                             NOTHING. No host, cpuset, heap, mem_cap,
#                             version or timestamp. Only backend and rep.
#
# The l4 lane was never wired into runner.py -- the placeholder comment
# "l4 timeseries: added as adapters land" is still there at runner.py:285 --
# so it produced no manifest either, and runs.jsonl confirms it: lanes are
# l1, l1tpc, l2, l3d, l3s, e2, and no l4 at all. Nothing was covering for it.
#
# NOT A KNOWN MISMATCH, which matters for how hard to state this. queue59.sh
# pins TS_TAGS=1 with the comment "Schema fidelity: TS_TAGS=1 deliberately",
# and that matches l4_tsbs.py's single host tag. So the two sides probably
# ARE comparable. The problem is that the artifacts cannot demonstrate it,
# cannot say which host or engine version produced the comparator numbers,
# and cannot be extended with more reps later. That is the failure that
# froze T4's 8.84M cell at N=3.
#
# WHAT THIS RUN FIXES: all four rows, one invocation, one host, one cpuset,
# one memory cap, arms rotated per rep so none inherits another's warm page
# cache, and run_conditions() stamped on every row.
#
# CHAINED behind queue67 with a HARD DEADLINE. A marker wait with no deadline
# is not a wait, it is a hang; that cost two watchers six days.
set -u
OUT=$HOME/q68
WORK=$HOME/q68work
mkdir -p "$OUT"
say(){ echo "[$(date +%T)] $*"; }

say "queue68 waiting for QUEUE67-DONE (hard deadline 8h)"
for i in $(seq 1 480); do
  grep -qa "QUEUE68-SKIP-WAIT" "$OUT/override" 2>/dev/null && { say "override"; break; }
  grep -qa "QUEUE67-DONE" ~/queue67.log 2>/dev/null && { say "q67 finished"; break; }
  # q67 exits without its marker on its own deadline/guard paths. Do not wait
  # for a marker that is never coming.
  if grep -qa "DEADLINE:\|GUARD:\|never reached\|DIED before\|NO result file" ~/queue67.log 2>/dev/null; then
    say "q67 exited on an error path; proceeding once mini is idle"
    break
  fi
  if [ "$i" -eq 480 ]; then
    say "DEADLINE: q67 did not finish in 8h; NOT starting"
    exit 1
  fi
  sleep 60
done

n=$(docker ps -q | wc -l)
[ "$n" -eq 0 ] || { say "GUARD: $n container(s) still running, refusing to co-run"; exit 1; }

# ISOLATED staging dir, never mini's checkout: that checkout is 625 commits
# behind with 594 dirty files (#98), and a git operation over a live campaign
# has already cost tracked result rows once.
cd "$WORK" || { say "no $WORK staging dir"; exit 1; }
for f in l4_tsbs.py l4_native_probe.py bench_common.py ts_stride_probe.py; do
  [ -f "$f" ] || { say "$f not staged in $WORK"; exit 1; }
done

LP=/data/tsbs/cpu_influx.lp
CPUS=0-11
MEM=20g
NET=q68net
docker network rm $NET >/dev/null 2>&1
docker network create $NET >/dev/null 2>&1 || { say "cannot create network"; exit 1; }

# BENCH_HOST is passed EXPLICITLY on every arm. run_conditions() used to
# default host to "mini" whether or not it was running there, which is the
# same self-assertion the function exists to prevent; it now reports the real
# hostname, and inside a container that is a random ID. Only the launcher
# knows this is mini, so the launcher says so.
COMMON="--cpuset-cpus $CPUS --memory $MEM --memory-swap $MEM
        -v $WORK:/work -w /work -v $HOME/icde-data:/data:ro
        -e TSBS_LP=$LP -e BENCH_HOST=mini"

run_doc() {  # $1=backend $2=rep  -- the lane script, document path
  local be=$1 rep=$2 img extra=""
  case "$be" in
    arcadedb) img=icde-bench:arcadedb; extra="-e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine" ;;
    duckdb)   img=icde-bench:duckdb;   extra="-e BENCH_ROLE=engine" ;;
    questdb)  img=icde-bench:client;   extra="-e BENCH_ROLE=driver -e QUEST_HOST=q68quest" ;;
  esac
  if [ "$be" = questdb ]; then
    docker rm -f q68quest >/dev/null 2>&1
    docker run -d --name q68quest --network $NET \
      --cpuset-cpus $CPUS --memory $MEM --memory-swap $MEM \
      questdb/questdb:9.1.1 >/dev/null 2>&1
    # Wait for pg-wire rather than sleeping a guessed interval.
    local ok=0
    for _ in $(seq 1 60); do
      docker exec q68quest sh -c 'nc -z 127.0.0.1 8812' >/dev/null 2>&1 && { ok=1; break; }
      docker ps -q -f name=q68quest | grep -q . || break
      sleep 2
    done
    [ "$ok" = 1 ] || { say "  questdb rep$rep NEVER-READY"; docker rm -f q68quest >/dev/null 2>&1; return 1; }
  fi
  timeout 3600 docker run --rm --name q68_${be}_r${rep} --network $NET \
    $COMMON $extra $img \
    python -u l4_tsbs.py --backend "$be" --out "/work/out/${be}_r${rep}.json" \
    >>"$OUT/${be}_r${rep}.log" 2>&1
  local rc=$?
  [ "$be" = questdb ] && docker rm -f q68quest >/dev/null 2>&1
  return $rc
}

run_native() {  # $1=rep -- the native TimeSeries arm, same knobs as queue59
  local rep=$1
  timeout 3600 docker run --rm --name q68_native_r${rep} \
    $COMMON \
    -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=1 \
    -e TS_SETTLE_S=0 -e TS_LAST_AB=1 \
    -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
    -e PROBE_OUT="/work/out/native_r${rep}.json" \
    icde-bench:arcadedb python -u l4_native_probe.py \
    >>"$OUT/native_r${rep}.log" 2>&1
}

mkdir -p "$WORK/out"
say "L4 re-run: 4 arms x 5 reps, cpuset $CPUS, mem $MEM, arms ROTATED per rep"
say "  TS_SETTLE_S=0 on the native arm: T5 prints the UNSETTLED row, because"
say "  nothing else in the block settles and a settled ArcadeDB beside"
say "  unsettled comparators would be a one-sided advantage."

ARMS=(arcadedb duckdb questdb native)
for rep in 1 2 3 4 5; do
  # Rotate the starting arm each rep. Running arm-by-arm to completion is how
  # the dense transport probe produced a 44% transport claim that reordering
  # cut to 7%: whichever arm goes first pays the page-cache and JIT warming
  # for the ones after it.
  off=$(( (rep - 1) % 4 ))
  order=()
  for k in 0 1 2 3; do order+=("${ARMS[$(( (off + k) % 4 ))]}"); done
  say "rep$rep order: ${order[*]}"
  for be in "${order[@]}"; do
    if [ "$be" = native ]; then
      run_native "$rep" && say "  native   rep$rep ok" || say "  native   rep$rep FAILED"
    else
      run_doc "$be" "$rep" && say "  ${be} rep$rep ok" || say "  ${be} rep$rep FAILED"
    fi
  done
done

docker network rm $NET >/dev/null 2>&1
cp -r "$WORK/out" "$OUT/results" 2>/dev/null

say "=== provenance verification: does every row now record its conditions? ==="
python3 - <<'PY'
import glob, json, os
d = os.path.expanduser("~/q68work/out")
files = sorted(glob.glob(os.path.join(d, "*.json")))
if not files:
    print("  NO RESULT FILES. Do not report a number."); raise SystemExit
CK = ("cpuset", "heap", "mem_cap", "host", "ts_utc", "producer", "role")
bad = 0
for fp in files:
    try:
        r = json.load(open(fp))
    except Exception as e:
        print(f"  {os.path.basename(fp)}: UNREADABLE {e}"); bad += 1; continue
    miss = [k for k in CK if r.get(k) in (None, "")]
    ver = r.get("backend_version") or r.get("engine_version")
    if miss or not ver:
        print(f"  {os.path.basename(fp):<22} BAD missing {miss or ''} ver={ver!r}")
        bad += 1
print(f"  {len(files)} files, {bad} incomplete")
if bad == 0:
    print("  Every row records host, cpuset, heap, mem_cap, producer, role,")
    print("  timestamp and the version of the engine IT measured.")

print("\n=== T5 time-series block, one matched run ===")
import statistics as st
def med(rows, k):
    v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
    return st.median(v) if v else float("nan")
groups = {}
for fp in files:
    try: r = json.load(open(fp))
    except Exception: continue
    groups.setdefault(os.path.basename(fp).rsplit("_r", 1)[0], []).append(r)
print(f"  {'arm':<10}{'n':>2} {'ingest pts/s':>14} {'last ms':>9} {'1h ms':>8} {'12h ms':>9}  host/cpuset/ver")
for name, rows in sorted(groups.items()):
    lk = "q_last_unbounded_ms" if any("q_last_unbounded_ms" in r for r in rows) else "q_last_ms"
    r0 = rows[0]
    ver = r0.get("backend_version") or r0.get("engine_version")
    print(f"  {name:<10}{len(rows):>2} {med(rows,'ingest_pts_per_s'):>14,.0f} "
          f"{med(rows,lk):>9.2f} {med(rows,'q_range_ms'):>8.2f} "
          f"{med(rows,'q_global_ms'):>9.2f}  "
          f"{r0.get('host')}/{r0.get('cpuset')}/{ver}")
print("\n  Compare against what T5 prints today (ts59 native + unprovenanced")
print("  l4_tsbs.jsonl): native 1,918,680 pts/s, 0.69 / 4.31 / 29.86 ms;")
print("  duckdb 1,940,570 pts/s, 1.40 / 1.28 / 4.57; questdb 431,306, 0.85 /")
print("  0.77 / 2.22; arcadedb doc path 31,276, 0.52 / 4.80 / 1791.65.")
print("  A large move in a COMPARATOR is the signal to care about: it would")
print("  mean the old rows were measured under conditions we cannot recover.")
PY
say "QUEUE68-DONE"
