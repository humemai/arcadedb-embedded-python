#!/usr/bin/env bash
# q87: re-measure every lane on released 26.8.1 with the FULL instrument.
#
# WHY NOW. Two instrument gaps landed today, and neither can be backfilled
# onto existing rows:
#   - on-disk size, which the campaign plan promised from the start and no
#     lane ever recorded (#149). Index size is half of what makes an index
#     choice a tradeoff, and it is the axis where sparse int8 should show its
#     win.
#   - shmem, so memory can be reported as anon+shmem ("owned") rather than
#     anon alone. Anon captures 26% of PostgreSQL's peak and 98% of
#     SurrealDB's, which is why the 107x memory claim had to be withdrawn
#     (#150). Every memory number in the paper today comes from the
#     anon-only instrument.
#
# A peak and a disk delta cannot be reconstructed after the fact, so the only
# way any table gets these columns is a re-run.
#
# SCOPE. Everything EXCEPT l3s medium (the 8.84M sparse tier), which is
# queued separately as q88 because it alone is 92 of the 153 hours. This
# script is ~41 h and covers nine of the ten published cell families.
# Ordered cheapest-first, so a harness defect surfaces in the first ten
# minutes rather than the tenth hour.
#
# Timings are MEASURED, harvested from this machine's own campaign logs, not
# guessed: l1 1.5 min/cell, l2 0.4-0.9, e2 2.3, l1tpc 8.0, l3s small 12,
# l3d small 5.7, l3d deep10m 26.8.
#
# PROTOCOL. Paper tier throughout: strictly serial, one cell at a time, full
# cpuset 0-11, both containers of a served cell sharing it. The runner
# refuses --tier paper with more than one worker, so this is enforced rather
# than intended.
set -u
S=$HOME/STATUS.txt
R=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$R" || exit 1
say() { echo "[$(date -Is)] $*" >> "$S"; }

# --- WHICH DATASETS. Sourced from the repo, not retyped here.
# The first launch of this script exported none of these and its smoke died in
# argparse on --scale sf1. That crash was the lucky outcome: the lanes that do
# NOT validate their scale would have run green for 41 hours on synthetic
# corpora. Config that lives only in a launcher script is config a launcher
# will forget, so it now lives beside the runner it configures.
source "$R/campaign_env.sh"
campaign_env_check || { say "q87 ABORT: corpora missing, see stderr"; \
                        echo "currently: q87 aborted" >> "$S"; exit 1; }
say "q87 datasets OK under $BENCH_DATA (graph=$BENCH_GRAPH_SOURCE sparse=$BENCH_SPARSE_SOURCE)"

# --- wait for q86. STATUS.txt is APPEND-ONLY HISTORY, so a bare
# `grep "q86 ABORT"` matches an abort from any earlier attempt today and this
# job exits before it starts. That is exactly what happened on the first
# launch: q86 had aborted once, been fixed, and was running fine, and this
# grep killed its successor. Read the LAST q86 line and act on that.
for i in $(seq 1 720); do
  last=$(grep -a "q86 " "$S" 2>/dev/null | tail -1)
  case "$last" in
    *"q86 ALL-DONE"*) break ;;
    *"q86 ABORT"*)    say "q87 not starting: q86 aborted ($last)"; exit 1 ;;
  esac
  sleep 30
done
case "$(grep -a "q86 " "$S" 2>/dev/null | tail -1)" in
  *"q86 ALL-DONE"*) ;;
  *) say "q87 gave up waiting for q86"; exit 1 ;;
esac

if [ -n "$(docker ps -q --filter label=dbbench=1)" ]; then
  say "q87 ABORT: dbbench containers still running"; exit 1
fi
grep -q container_disk_mb runner.py || { say "q87 ABORT: checkout has no disk instrument"; exit 1; }

BK=~/q87-preserve-$(date +%Y%m%dT%H%M%SZ)
mkdir -p "$BK"
cp results/runs.jsonl "$BK/runs.jsonl" 2>/dev/null
cp -r results/raw "$BK/raw" 2>/dev/null
say "q87 preserved runs.jsonl + $(ls "$BK/raw" 2>/dev/null | wc -l) raw rows in $BK"

# --- stage 0: prove the new columns land before committing 41 hours to them.
# l2 sf1 is the cheapest cell on the machine (0.4 min), and it exercises an
# embedded engine and a served one in the same lane.
say "q87 smoke: l2 sf1, rep 9, disk instrument"
python3 -u runner.py --lanes l2 --scale sf1 --reps 9 --only-reps 9 \
  --workloads oltp >> ~/q87.log 2>&1
rc=$?
say "q87 smoke rc=$rc"
[ "$rc" -eq 0 ] || { say "q87 ABORT: smoke failed"; echo "currently: q87 aborted" >> "$S"; exit 1; }

python3 - >> ~/q87.log 2>&1 <<'PYEOF'
import json, os, sys
p = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/"
                       "benchmarks/experiments/results/runs.jsonl")
rows = [json.loads(l) for l in open(p) if l.strip()]
smoke = [r for r in rows if r.get("lane") == "l2" and r.get("scale") == "sf1"
         and r.get("rep") == 9]
by = {}
for r in smoke:
    by[r["backend"]] = r
bad = []
if not by:
    bad.append("no rep-9 sf1 rows at all")
for be, r in sorted(by.items()):
    served = r.get("server_peak_anon_mib") is not None
    print("%s (%s)" % (be, "served" if served else "embedded"))
    print("   disk: baseline srv=%s cli=%s  final srv=%s cli=%s  sum=%s data=%s" % (
        r.get("server_disk_baseline_mb"), r.get("client_disk_baseline_mb"),
        r.get("server_disk_mb"), r.get("client_disk_mb"),
        r.get("disk_mb_sum"), r.get("disk_data_mb")))
    print("   mem : anon=%s shmem=%s owned=%s total=%s" % (
        r.get("peak_anon_mib_sum"), r.get("peak_shmem_mib_sum"),
        r.get("peak_owned_mib_sum"), r.get("peak_mib_sum")))
    if r.get("rc") != 0 or r.get("error"):
        bad.append("%s: rc=%s error=%s" % (be, r.get("rc"), r.get("error")))
    for f in ("disk_mb_sum", "disk_data_mb", "peak_owned_mib_sum",
              "peak_shmem_mib_sum"):
        if r.get(f) is None:
            bad.append("%s: %s is null" % (be, f))
    # A graph engine that loaded SF1 and wrote nothing is not a measurement,
    # it is an instrument reading zero and looking like a result.
    if (r.get("disk_data_mb") or 0) <= 0:
        bad.append("%s: disk_data_mb=%s, so the workload appears to have "
                   "written nothing" % (be, r.get("disk_data_mb")))
    # WHICH CORPUS. LDBC-SNB SF1 is ~3.3M persons-worth of graph; the
    # synthetic fallback at the same scale name is orders of magnitude
    # smaller. Checking the row's own person count is how a silent fallback
    # becomes a failed gate instead of 41 hours of wrong data.
    np_ = r.get("n_persons") or r.get("n_rows") or 0
    if np_ and np_ < 10000:
        bad.append("%s: n_persons=%s at sf1, which is the synthetic corpus, "
                   "not LDBC-SNB" % (be, np_))
if bad:
    print("SMOKE-BAD")
    for b in bad:
        print("   ", b)
    sys.exit(1)
print("SMOKE-OK")
PYEOF
if [ $? -ne 0 ]; then
  say "q87 ABORT: new columns did not land (see ~/q87.log)"
  echo "currently: q87 aborted" >> "$S"; exit 1
fi
say "q87 smoke OK: disk + owned memory land on both topologies"

# --- the campaign, cheapest first
run_lane() {   # lane scale est_hours
  say "q87 $1 $2 START (est ${3}h)"
  python3 -u runner.py --lanes "$1" --scale "$2" --reps 5 >> ~/q87.log 2>&1
  say "q87 $1 $2 rc=$?"
}
run_lane l2    sf1     0.3
run_lane l2    sf10    0.7
run_lane l1    medium  1.3
run_lane e2    e2      1.2
run_lane l3s   tiny    1.8
run_lane l3d   small   3.8
run_lane l1tpc tpch1   6.7
run_lane l3s   small   7.0
run_lane l3d   deep10m 17.9

say "q87 ALL-DONE"
echo "currently: finished" >> "$S"
