#!/bin/bash
set -u
# Overnight queue on mini. Strictly serial: every job here is timing-sensitive,
# so nothing may share the host with anything else.
#
#   q78  1M lifecycle WITH the #5747 patch. Pairs with q77 to give a matched
#        before/after at 1M, which is the number the PR should open with.
#   q79  GAV cost across sizes. Answers two things we cannot currently answer:
#        how the CSR rebuild scales, and how big the CSR actually is, which is
#        what decides whether persisting it to disk is worth doing at all.
#   q80  Vector lifecycle at 3M, to put a fourth point on the close-cost curve
#        (10k, 100k, 1M measured; 3M extends it without the ~45 min a 10M build
#        would cost).
#
# Each stage has its own deadline and each writes its own marker, so a stage
# that overruns stops the queue rather than corrupting the next measurement.

log() { echo "[$(date -Is)] $*"; }

wait_for() {          # wait_for <container-name> <deadline-seconds>
  # Separate assignments on purpose: `local a=$1 b=$2 c=$((...b))` evaluates the
  # arithmetic before b is visible, and under `set -u` that aborts the whole
  # script on the first call. That failure is silent apart from one line in a
  # log nobody reads until morning, which is exactly how a queue does nothing
  # for eight hours.
  local name=$1
  local budget=$2
  local deadline
  deadline=$(( $(date +%s) + budget ))
  while docker ps --format '{{.Names}}' | grep -qE "^${name}$"; do
    if [ "$(date +%s)" -gt "$deadline" ]; then
      log "ABORT: $name still running after ${budget}s"
      return 1
    fi
    sleep 30
  done
  return 0
}

D=/usr/local/lib/python3.12/site-packages/arcadedb_embedded

log "night queue started, pid $$"   # proof of life: an empty log now means dead, not waiting

# ---- q78: 1M lifecycle, patched -------------------------------------------
wait_for q77 21600 || exit 1
log "q77 clear, starting q78 (1M, patched)"
cd /home/tk/q78 || exit 1
P=/work/arcadedb-engine-patched.jar
SRC=$(docker run --rm --cpuset-cpus 0-11 -v /home/tk/q78:/work -w /work icde-bench:arcadedb \
  bash -lc "$D/jre/bin/java -Xlog:class+load=info -cp '$P:/work:$D/jars/*' \
    LifecycleMatrix2 /work/gate /work/gate.jsonl 1000 vector 2>&1 \
  | grep -m1 'com.arcadedb.index.vector.LSMVectorIndex ' | sed 's/.*source: //'")
log "gate: LSMVectorIndex from $SRC"
case "$SRC" in
  *arcadedb-engine-patched.jar*) log "gate ok" ;;
  *) log "GATE FAILED, skipping q78"; SKIP78=1 ;;
esac
if [ -z "${SKIP78:-}" ]; then
  docker run --rm --name q78 --label icde-debug=1 \
    --cpuset-cpus 0-11 --memory 24g --memory-swap 24g \
    -v /home/tk/q78:/work -w /work icde-bench:arcadedb \
    bash -lc "$D/jre/bin/java -Xmx12g -Xms12g -cp '$P:/work:$D/jars/*' \
      LifecycleMatrix2 /work/db /work/lm2_1m_fix.jsonl 1000000 \
      vector,vector2,vector2_half,mixed" > /home/tk/q78/run.log 2>&1
  log "Q78-DONE rc=$?"
fi

# ---- q79: GAV cost across sizes -------------------------------------------
log "starting q79 (GAV cost)"
mkdir -p /home/tk/q79
docker run --rm --name q79 --label icde-debug=1 \
  --cpuset-cpus 0-11 --memory 24g --memory-swap 24g \
  -v /home/tk/q79:/work -w /work icde-bench:arcadedb \
  bash -lc "$D/jre/bin/java -Xmx12g -Xms12g -cp '/work:$D/jars/*' \
    GavCost 10000,100000,1000000,5000000" > /home/tk/q79/run.log 2>&1
log "Q79-DONE rc=$?"
# The engine logs 'CSR built: N nodes, E edges, ... X MB, Y ms' per build, which
# gives build time AND resident size without extra instrumentation.
grep -oE "CSR built:[^\"]{0,140}" /home/tk/q79/run.log | tail -20 > /home/tk/q79/csr_lines.txt || true

# ---- q80: 3M vector lifecycle ---------------------------------------------
log "starting q80 (3M vector lifecycle)"
mkdir -p /home/tk/q80
cp /home/tk/q78/LifecycleMatrix2.class /home/tk/q80/ 2>/dev/null
docker run --rm --name q80 --label icde-debug=1 \
  --cpuset-cpus 0-11 --memory 32g --memory-swap 32g \
  -v /home/tk/q80:/work -w /work icde-bench:arcadedb \
  bash -lc "$D/jre/bin/java -Xmx20g -Xms20g -cp '/work:$D/jars/*' \
    LifecycleMatrix2 /work/db /work/lm2_3m.jsonl 3000000 vector" > /home/tk/q80/run.log 2>&1
log "Q80-DONE rc=$?"

log "NIGHT-QUEUE-COMPLETE"
