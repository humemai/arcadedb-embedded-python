#!/usr/bin/env bash
set -u
echo "waiting for scipy chain..."
sleep 600  # let scipy chain leave its own wait-loop first
while pgrep -f "[s]cipy_dev1_chain" >/dev/null; do sleep 300; done
pgrep -x ffmpeg >/dev/null && { echo "ICDE-REQUEUE-ABORT ffmpeg"; exit 1; }
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
nohup bash resume_sparse.sh >> resume.log 2>&1 &
echo "ICDE-RESUME-RELAUNCHED"
