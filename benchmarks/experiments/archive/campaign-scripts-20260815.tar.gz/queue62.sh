#!/bin/bash
# Third in the chain: put ArcadeDB's DEEP-10M rows on dev23 under the same
# one-build/five-pass protocol queue61 is giving the comparators.
#
# After q61, every dense comparator will have a cold AND a warm number on one
# protocol. ArcadeDB will have both too, but from verify5412b, measured on
# dev20 in July. Leaving it there means the matched comparison everyone
# finally shares is still split across engine lines, which is the defect that
# produced T5's server-build cell (a stale image published as a deployment
# cost). One line, one protocol, or it is not matched.
#
# OPERATING POINTS ARE NOT THE SAME and that is deliberate, matching what T5
# already discloses: fp32 runs at 24 GiB heap, int8 at 16 GiB, because the
# int8 row is the 16 GiB cell and the matched-24 GiB ablation is prose only.
# Getting this wrong would silently re-point the row at a different operating
# point while calling it a version re-measure.
#
# Quantization is now READ from the environment by the driver rather than
# written as a string literal, which is how the dev20 drivers did it and how
# one of them came to stamp a version it was not running.
#
# Expect roughly 2.5 h: fp32 build ~2.7k s, int8 ~6.0k s, five passes each
# costing about a minute.
set -u
exec >> "$HOME/profiling/queue62.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

for prev in queue60 queue61; do
  if pgrep -f "bash ./$prev.sh" > /dev/null 2>&1; then
    say "$prev is running; waiting"
    while pgrep -f "bash ./$prev.sh" > /dev/null 2>&1; do sleep 60; done
    say "$prev finished"
  fi
done
guard

cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
OUT=results/dense_mp
mkdir -p "$OUT"

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
[ -n "${VER:-}" ] || die "no engine version"
say "engine $VER (T5's dense ArcadeDB rows are dev20 today)"

docker run --rm -v "$PWD:/work" -w /work icde-bench:arcadedb python -c "
import l3d_dense as L
assert 'arcadedb_dense_embedded' in L.BACKENDS
import dense_multipass_driver as D
src = open('dense_multipass_driver.py').read()
assert 'BENCH_DENSE_QUANT' in src, 'driver does not record quantization'
print('contract ok')
" || die "driver contract changed"

run_arm() {  # $1 label, $2 heap, $3 quant ("" = fp32)
  local label=$1 heap=$2 quant=$3
  local out="$OUT/mp_arcade_${label}.json"
  [ -s "$out" ] && { say "$label present, skipping"; return; }
  guard
  say "starting arcade $label (heap $heap, quant=${quant:-fp32}); build is the slow part"
  timeout 43200 docker run --rm --name q62_${label} \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e BENCH_DENSE_DATA=/data/dense -e BENCH_DENSE_M=32 \
    -e BENCH_DENSE_QUANT="$quant" -e ARCADEDB_HEAP="$heap" \
    -e BENCH_MP_BACKEND=arcadedb_dense_embedded -e BENCH_MP_SCALE=deep10m \
    -e BENCH_ROLE=engine -e PROBE_OUT="/work/$out" \
    icde-bench:arcadedb python -u dense_multipass_driver.py >/dev/null 2>&1 \
    && say "arcade $label ok" || say "arcade $label FAILED"
}

run_arm fp32 24g ""
run_arm int8 16g "INT8"

say "=== result ==="
python3 - <<'PY'
import glob, json, statistics as st
print("  ArcadeDB DEEP-10M on dev23, one build + five passes\n")
print(f"  {'arm':6} {'quant':5} {'heap':5} {'build_s':>9} {'pass1':>8} {'2-5':>8} {'gain':>6} {'recall':>7}")
for label in ("fp32", "int8"):
    fp = f"results/dense_mp/mp_arcade_{label}.json"
    try:
        reps = json.load(open(fp))
    except Exception:
        print(f"  {label:6} (no result)")
        continue
    cold = [r["p50"] for r in reps if r.get("rep") == 1]
    warm = [r["p50"] for r in reps if r.get("rep", 0) >= 2]
    rec = st.median([r["recall_at_10"] for r in reps if r.get("rep", 0) >= 2])
    r0 = reps[0]
    if cold and warm:
        c, w = cold[0], st.median(warm)
        print(f"  {label:6} {str(r0.get('quantization')):5} "
              f"{str(r0.get('heap_asked')):5} {r0.get('build_s'):9.1f} "
              f"{c:8.3f} {w:8.3f} {c/w:5.2f}x {rec:7.4f}")
print("\n  dev20 for comparison: fp32 4.424 cold / 0.723 warm, build 2.7k")
print("                        int8 3.010 cold / 0.746 warm, build 6.0k")
print("\n  If dev23 reproduces dev20 within noise, T5's dense row can move to")
print("  one line with queue61's comparators and the protocol finally matches")
print("  on both axes. If it does not, the delta is an engine change between")
print("  dev20 and dev23 and belongs in the text, not silently in the cell.")
PY
say "QUEUE62-DONE"
