#!/bin/bash
# q22: TPC-H SF10, OLAP only, N=5. Retry of q21's tabular half.
#
# WHY q21's TPC-H HALF FAILED, all 20 cells, in under a minute. It set
#   BENCH_DATA=$HOME/bench-data/tpch
# and left BENCH_TPC_DATA unset. runner.py mounts $BENCH_DATA at /data, and
# l1_tpc.py defaults BENCH_TPC_DATA to /data/tpch, so the container looked in
# .../tpch/tpch and pyarrow raised on every cell. q19 had it right:
#   BENCH_DATA=$HOME/bench-data ; BENCH_TPC_DATA=/data/tpch
# and I retyped the environment instead of copying the arm that worked. Fixed
# below by copying it.
#
# THE GATE DID NOT CATCH IT, and that is the more useful lesson. q21 asserted
# $HOME/bench-data/tpch/sf10_lineitem.parquet exists, which was true and
# irrelevant: the failure was in what the CONTAINER could see, and a host-side
# check cannot speak to that. This script therefore preflights from inside the
# bench image, with the same mount and the same variables the cells will use.
#
# q21's time-series half SUCCEEDED and is not repeated here: results/ts_2681
# has five reps on 26.8.1, closing the last pre-release cell in the paper.
set -u
OUT=$HOME/q22
mkdir -p "$OUT"
LOG=$OUT/queue.log
EXP=$HOME/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
IMG=dbbench:arcadedb

log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
die() { log "ABORT: $*"; exit 1; }

log "q22 started, pid $$"
cd "$EXP" || die "no experiments dir"

# Copied from q19, which is the arm that actually loaded this corpus.
export BENCH_DATA=$HOME/bench-data
export BENCH_TPC_DATA=/data/tpch
export BENCH_TPC_SF=10
export BENCH_TPC_BATCH_ROWS=2000000

grep -q "if want and wl not in want" runner.py || die "runner ignores --workloads"
grep -q "def lineitem_batches" l1_tpc.py || die "l1_tpc.py is not the streaming loader"
log "gates: runner honours --workloads, streaming loader present"

# ---- CONTAINER-SIDE preflight ----------------------------------------------
# The check q21 needed and did not have: mount exactly as runner.py will and
# ask the image whether the file is where l1_tpc.py will look for it. Also
# read the row count out of the parquet footer, so "the file is visible" and
# "the file is the SF10 one" are both established before 16 hours of cells.
log "preflight: what the container sees at BENCH_TPC_DATA=$BENCH_TPC_DATA"
docker run --rm -v "$BENCH_DATA:/data:ro" -v "$EXP:/work" -w /work \
  -e BENCH_TPC_DATA="$BENCH_TPC_DATA" "$IMG" python -c "
import os, sys, pyarrow.parquet as pq
d = os.environ['BENCH_TPC_DATA']
p = os.path.join(d, 'sf10_lineitem.parquet')
if not os.path.exists(p):
    sys.exit('NOT VISIBLE: %s (dir listing: %s)' % (p, os.listdir(d) if os.path.isdir(d) else 'no such dir'))
n = pq.ParquetFile(p).metadata.num_rows
print('visible: %s, %d rows' % (p, n))
sys.exit(0 if n == 59986052 else 'WRONG CORPUS: %d rows, SF10 is 59986052' % n)
" 2>&1 | tee -a "$LOG"
[ "${PIPESTATUS[0]}" -eq 0 ] || die "container cannot see the SF10 corpus"

VER=$(docker run --rm "$IMG" python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
case "${VER:-}" in
  "")     die "no engine version from $IMG" ;;
  *.dev*) die "F5: $IMG is $VER, a pre-release" ;;
esac
log "gate: $IMG is $VER"

while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 20; done
log "host idle"

# ---- the run ----------------------------------------------------------------
log "START l1tpc tpch10 olap N=5 (4 backends, 20 cells, ~16h expected)"
t0=$(date +%s)
timeout 86400 python3 -u runner.py --lanes l1tpc --scale tpch10 \
    --workloads olap --reps 5 --tier paper \
    > "$OUT/l1tpc_tpch10_olap.log" 2>&1
rc=$?
log "l1tpc tpch10 olap rc=$rc after $(( ($(date +%s)-t0)/60 )) min"
[ $rc -ne 0 ] && tail -25 "$OUT/l1tpc_tpch10_olap.log" >> "$LOG"

# ---- acceptance -------------------------------------------------------------
log "=== acceptance ==="
python3 - >>"$LOG" 2>&1 <<'PY'
import json, os, statistics as st, collections
EXP = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments")
rows = [r for r in (json.loads(l) for l in open(os.path.join(EXP, "results", "runs.jsonl")) if l.strip())
        if r.get("scale") == "tpch10" and r.get("ts_utc", "") >= "2026-08-06T12"]
print("  rows this run: %d" % len(rows))
if not rows:
    print("  NO ROWS. SF10 is still unmeasured; report nothing.")
else:
    for k in sorted({(r["backend"], r["workload"]) for r in rows}, key=str):
        g = [r for r in rows if (r["backend"], r["workload"]) == k]
        ok = [r for r in g if r.get("rc") == 0]
        q1 = [r["q1_ms"] for r in ok if isinstance(r.get("q1_ms"), (int, float))]
        q6 = [r["q6_ms"] for r in ok if isinstance(r.get("q6_ms"), (int, float))]
        print("    %-20s %-5s %d reps, %d ok%s%s" % (
            k[0], k[1], len(g), len(ok),
            ("  q1 %.1f ms" % st.median(q1)) if q1 else "",
            ("  q6 %.1f ms" % st.median(q6)) if q6 else ""))
    bad = [r for r in rows if r.get("rc") != 0]
    if bad:
        print("  FAILED %d: %s" % (len(bad), str(bad[0].get("error"))[:200]))
    nl = {r.get("n_lineitem") for r in rows if r.get("n_lineitem")}
    print("  n_lineitem: %s  (SF10 must be 59986052)" % sorted(nl))
    if nl and nl != {59986052}:
        print("  REJECT: fact table did not fully load.")
PY

log "Q22-COMPLETE"
