#!/usr/bin/env bash
# q84: re-profile the 1M sparse query path on the RELEASE (26.8.1).
#
# WHY. The paper's profiling paragraph -- 3.0% of query CPU in segment-block
# reads, 1.0% in context lookups, 3.5% union -- was collected on 26.8.1.dev23,
# a pre-release build. Everything else in the paper is the release, so that one
# paragraph forces the provenance sentence to carry an exception clause. This
# run is what lets the clause be deleted rather than disclosed (#140).
#
# The image is checked, not assumed: dbbench:arcadedb must report 26.8.1.
set -u
OUT=$HOME/profiling/flame
S=$HOME/STATUS.txt
cd ~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments

ver=$(docker run --rm --entrypoint python dbbench:arcadedb -c \
      'import importlib.metadata as m; print(m.version("arcadedb-embedded"))' 2>/dev/null | tr -d '\r')
if [ "$ver" != "26.8.1" ]; then
  echo "[$(date -Is)] q84 ABORT: image reports '$ver', expected the release 26.8.1" >> "$S"
  exit 1
fi
echo "[$(date -Is)] q84 sparse re-profile START on $ver" >> "$S"

docker rm -f prof_sparse1m >/dev/null 2>&1
docker run -d --name prof_sparse1m --cpuset-cpus 0-11 --memory 32g --memory-swap 32g \
  -v "$PWD:/work" -w /work -v "$HOME/bench-data:/data:ro" \
  -v "$HOME/profiling/async-profiler-4.0-linux-x64:/prof:ro" -v "$OUT:/pout" \
  -e MODE=sparse -e PROFILE_SECS=600 -e BENCH_SPARSE_DATA=/data/bigann \
  -e BENCH_SPARSE_SOURCE=bigann -e ARCADEDB_HEAP=16g \
  dbbench:arcadedb python -u profile_query_driver.py >/dev/null

# Attach ONLY after the query loop starts. Attaching during the build profiles
# the build, which is a different question and was a real bug in an earlier
# version of the dense script.
found=0
for i in $(seq 1 240); do   # up to 1h for the 1M build
  docker logs prof_sparse1m 2>&1 | grep -qa "QUERY-PHASE-START" && { found=1; break; }
  docker ps -q -f name=prof_sparse1m | grep -q . || {
    echo "[$(date -Is)] q84 container DIED before query phase" >> "$S"
    docker logs prof_sparse1m 2>&1 | tail -8 >> "$S"; exit 1; }
  sleep 15
done
[ "$found" -ne 1 ] && { echo "[$(date -Is)] q84 never reached query phase" >> "$S"; exit 1; }

sleep 10
docker exec prof_sparse1m /prof/bin/asprof start -e cpu 1
echo "[$(date -Is)] q84 CPU profiling attached" >> "$S"
sleep 240
docker exec prof_sparse1m /prof/bin/asprof stop -o collapsed -f /pout/sparse_26.8.1_cpu.collapsed 1
echo "[$(date -Is)] q84 CPU profile written" >> "$S"

# Wall-clock pass: same window, different clock, so an I/O or lock stall that
# CPU sampling cannot see would show up here.
docker exec prof_sparse1m /prof/bin/asprof start -e wall -i 10ms 1
sleep 240
docker exec prof_sparse1m /prof/bin/asprof stop -o collapsed -f /pout/sparse_wall_26.8.1.collapsed 1
echo "[$(date -Is)] q84 wall profile written" >> "$S"

docker rm -f prof_sparse1m >/dev/null 2>&1
echo "[$(date -Is)] q84 ALL-DONE" >> "$S"
echo "currently: finished" >> "$S"
