#!/bin/bash
# queue71: does a settle explain the QuestDB gap, or is the gap real?
#
# q70 re-ran questdb with provenance and got numbers ~3x slower on every query
# than the unprovenanced row they replace:
#
#              ingest      last     1h     12h
#   old       431,306      0.85   0.77    2.22   (no host, no cpuset, no date)
#   q70       309,581      2.71   2.47    6.81   (mini, 0-11, N=5, stamped)
#
# DuckDB reproduced within 4% in the same run and native within 5%, so the
# harness is not broadly wrong. Something about questdb specifically differs.
#
# THE HYPOTHESIS, and it accuses my own harness first: q70 creates a FRESH
# QuestDB container per rep and starts querying the moment pg-wire accepts a
# connection. QuestDB absorbs 2.6M rows over ILP and does background work
# afterwards. Querying immediately would measure a server still catching up,
# which would slow queries and not ingest... except ingest ALSO dropped 28%,
# so a pure settle story does not obviously cover both. That is exactly why
# this is worth one controlled run instead of a paragraph of speculation.
#
# ARMS, five reps each, interleaved so neither inherits the other's page cache:
#   settle=0    reproduces q70 exactly, the control
#   settle=30   the same run with 30 s between ingest and first query
#
# READING IT:
#   settle recovers the old numbers  -> q70 measured an unsettled server, the
#     old row stands, and the lane needs a settle for questdb (which reopens
#     the #116 asymmetry: whatever we give one engine we give all of them).
#   settle changes little            -> the gap is not warm-up. Then the old
#     row was measured under conditions we cannot reconstruct and it should be
#     replaced by the provenanced one rather than defended.
#   ingest stays at ~310k either way -> the ingest drop is a separate question
#     from the query drop and must not be explained by one story.
set -u
OUT=$HOME/q71
WORK=$HOME/q68work
mkdir -p "$OUT"
say(){ echo "[$(date +%T)] $*"; }

for i in $(seq 1 480); do
  n=$(docker ps -q | wc -l)
  [ "$n" -eq 0 ] && break
  [ "$i" -eq 1 ] && say "waiting for mini to go idle ($n container(s) up)"
  if [ "$i" -eq 480 ]; then say "DEADLINE: mini busy 8h, not starting"; exit 1; fi
  sleep 60
done
say "mini idle"

cd "$WORK" || { say "no $WORK"; exit 1; }
[ -f l4_tsbs.py ] || { say "l4_tsbs.py not staged"; exit 1; }
grep -q TSBS_SETTLE_S l4_tsbs.py || { say "staged l4_tsbs.py has no settle knob; re-stage it"; exit 1; }

CPUS=0-11
NET=q71net
docker network rm $NET >/dev/null 2>&1; docker network create $NET >/dev/null 2>&1

quest_ready() {
  docker run --rm --network $NET icde-bench:client python -c "
import sys, time, psycopg
for _ in range(90):
    try:
        psycopg.connect('host=q71quest port=8812 dbname=qdb user=admin password=quest',
                        connect_timeout=3).close(); sys.exit(0)
    except Exception: time.sleep(2)
sys.exit(1)" >/dev/null 2>&1
}

run_one() {  # $1=settle seconds  $2=rep
  local settle=$1 rep=$2
  docker rm -f q71quest >/dev/null 2>&1
  docker run -d --name q71quest --network $NET \
    --cpuset-cpus $CPUS --memory 20g --memory-swap 20g \
    questdb/questdb:9.1.1 >/dev/null 2>&1
  if ! quest_ready; then say "  settle=${settle} rep$rep NEVER-READY"; docker rm -f q71quest >/dev/null 2>&1; return 1; fi
  timeout 3600 docker run --rm --name q71_s${settle}_r${rep} --network $NET \
    --cpuset-cpus $CPUS --memory 20g --memory-swap 20g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e TSBS_LP=/data/tsbs/cpu_influx.lp -e BENCH_HOST=mini \
    -e BENCH_ROLE=driver -e QUEST_HOST=q71quest -e TSBS_SETTLE_S=$settle \
    icde-bench:client python -u l4_tsbs.py \
      --backend questdb --out "/work/out71/questdb_s${settle}_r${rep}.json" \
    >>"$OUT/s${settle}_r${rep}.log" 2>&1
  local rc=$?
  docker rm -f q71quest >/dev/null 2>&1
  return $rc
}

mkdir -p "$WORK/out71"
say "questdb settle A/B, 5 reps each, arms interleaved"
for rep in 1 2 3 4 5; do
  # alternate which arm goes first, same reason q68 rotated
  if [ $((rep % 2)) -eq 1 ]; then order="0 30"; else order="30 0"; fi
  for s in $order; do
    run_one "$s" "$rep" && say "  settle=${s}s rep$rep ok" || say "  settle=${s}s rep$rep FAILED"
  done
done
docker network rm $NET >/dev/null 2>&1
cp -r "$WORK/out71" "$OUT/results" 2>/dev/null

say "=== does a settle explain the gap? ==="
python3 - <<'PY'
import glob, json, os, statistics as st, collections
d = os.path.expanduser("~/q68work/out71")
g = collections.defaultdict(list)
for fp in sorted(glob.glob(os.path.join(d, "questdb_s*_r*.json"))):
    try: r = json.load(open(fp))
    except Exception: continue
    g[r.get("settle_s", "?")].append(r)
if not g:
    print("  NO RESULTS. Do not report a number."); raise SystemExit
def med(rs, k):
    v = [r[k] for r in rs if isinstance(r.get(k), (int, float))]
    return st.median(v) if v else float("nan")
print(f"  {'settle':>7}{'n':>3} {'ingest':>11} {'last':>7} {'1h':>7} {'12h':>8}")
for s in sorted(g, key=lambda x: (x is None, x)):
    rs = g[s]
    print(f"  {str(s):>7}{len(rs):>3} {med(rs,'ingest_pts_per_s'):>11,.0f} "
          f"{med(rs,'q_last_ms'):>7.2f} {med(rs,'q_range_ms'):>7.2f} {med(rs,'q_global_ms'):>8.2f}")
print("\n  old unprovenanced row: 431,306 / 0.85 / 0.77 / 2.22")
print("  q70 (settle 0, separate run): 309,581 / 2.71 / 2.47 / 6.81")
print()
print("  If settle=30 lands near the old row, q70 measured an unsettled")
print("  server and the lane owes questdb a settle (and then owes one to")
print("  every other engine too, see #116). If both arms agree, warm-up is")
print("  not the story and the old row is the one that cannot be defended.")
print("  Ingest should be unaffected by a post-ingest sleep either way; if it")
print("  moves, something other than settling differs between the runs.")
PY
say "QUEUE71-DONE"
