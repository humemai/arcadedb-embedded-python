#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "DVSS-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "DVSS-ABORT foreign-container"; exit 1; }
echo "=== DuckDB-VSS dense solo re-measure $(date -u +%FT%TZ) ==="
BENCH_DATA=/home/tk/icde-data BENCH_CPUSET=0-11 \
  python3 -u runner.py --lanes l3d --scale small --reps 5 --backends duckdb_vss_dense --tier paper --workers 1
echo "rc=$?"
echo "DVSS-SOLO-COMPLETE"
