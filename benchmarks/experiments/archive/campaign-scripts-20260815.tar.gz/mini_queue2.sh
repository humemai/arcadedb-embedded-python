#!/bin/bash
# Stable-26.8.1 re-measure chain. NEW FILE, never an edit of a running script
# (bash reads by byte offset, so editing one in place corrupts it mid-run).
#
# ORDER IS BY PAPER RISK, not by duration:
#   P1 scipy arcadedb-only  -- live review PR #1256, and the paper currently
#      cites FOUR different dev wheels across its lanes (dev2 graph, dev3
#      tabular, dev20 vector, dev27 arrow) plus a paragraph explaining the
#      mismatch. One stable run collapses all of it and deletes the caveat.
#   P2 icde dense fp32+int8 -- F5 needs both ArcadeDB arms on one engine line.
#   P3 icde fp32 x2 more    -- #124's cold reproduce needs N>=3.
#   P4 icde comparators     -- provenance only (see below).
#
# ONLY ARCADEDB ARMS ARE RE-RUN. Moving arcadedb-embedded dev20 -> 26.8.1
# changes ArcadeDB rows and nothing else, so chroma/duckdb/sqlite/ladybug keep
# their existing numbers: 180 scipy runs become 75. Same reasoning already
# applied to LanceDB on the icde side.
#
# EXCEPT P4. results/dense_mp/{chroma,duckvss,qdrant}.json carry
# lib_version=None AND engine_version="unknown (PackageNotFoundError)", so
# there is no recoverable version for those rows at all and provenance_check
# now rejects them (it treats an "unknown"-prefixed string as absent). They are
# re-run for provenance, not because their engine changed.
#
# SERIAL, because every cell here is a published absolute or percentile. A
# co-run number cannot be promoted later, so running these in parallel would
# not save the time, it would spend it and force a re-measure.
set -u
LOG=~/q2/queue.log
mkdir -p ~/q2
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "queue2 started, pid $$"      # proof of life: an empty log means dead, not busy

PIN=26.8.1

# ---- P0: gate on the release actually being installable -------------------
# Checks PyPI itself rather than trusting that the tag push worked. A build
# against a missing version silently produces an image on the previous pin.
# RETRIES, because pypi.org/pypi/<pkg>/json is CDN-cached PER EDGE NODE and a
# single point-in-time check is not a reliable gate. Observed 2026-08-04: the
# release was live and fully uploaded (20 wheels), the laptop saw them, and
# mini's request 35 s later returned files=0 from a stale Fastly edge. Seconds
# after that the same command on the same host returned 20. One sample would
# have aborted a whole night's queue over a cache miss.
#
# Also stops conflating "the lookup failed" with "the release does not exist":
# the old form ended in `2>/dev/null || echo 0`, so a curl timeout, a DNS blip
# or a JSON change all reported themselves as "not published".
AVAIL=0
for attempt in 1 2 3 4 5 6 7 8 9 10; do
  RAW=$(curl -sS --max-time 30 https://pypi.org/pypi/arcadedb-embedded/json 2>>"$LOG")
  if [ -z "$RAW" ]; then
    log "P0: attempt $attempt: LOOKUP FAILED (empty response), retrying"
  else
    AVAIL=$(printf '%s' "$RAW" | python3 -c \
      "import sys,json;print(len(json.load(sys.stdin)['releases'].get('$PIN',[])))" 2>>"$LOG")
    case "$AVAIL" in
      ''|*[!0-9]*) log "P0: attempt $attempt: UNPARSEABLE response, retrying"; AVAIL=0 ;;
      *) [ "$AVAIL" -ge 1 ] && break
         log "P0: attempt $attempt: $PIN reports 0 files (stale CDN edge?), retrying" ;;
    esac
  fi
  sleep 30
done
if [ "${AVAIL:-0}" -lt 1 ]; then
  log "ABORT: arcadedb-embedded==$PIN still absent after 10 attempts over 5 min."
  log "       This is now a real absence, not a cache miss. Check the release."
  exit 1
fi
log "P0: PyPI has $PIN ($AVAIL files)"

SCIPY=~/scipy-bench/experiments
ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments

# Bump both pins in place, then REBUILD. sed is on the exact old pin so a
# second run is a no-op rather than a corruption.
sed -i "s/arcadedb-embedded==26\.8\.1\.dev[0-9]*/arcadedb-embedded==$PIN/" \
    "$SCIPY/build_images.sh" "$ICDE/build_images.sh"
log "P0: pins bumped to $PIN"
grep -h "arcadedb-embedded==" "$SCIPY/build_images.sh" "$ICDE/build_images.sh" | sed 's/^/    /' >> "$LOG"

# Image builds MAY run concurrently: a build is not a measurement.
log "P0: building both arcadedb images (concurrent, builds are not measurements)"
( cd "$SCIPY" && ./build_images.sh arcadedb > ~/q2/build_scipy.log 2>&1 ) &
BS=$!
( cd "$ICDE"  && ./build_images.sh arcadedb > ~/q2/build_icde.log  2>&1 ) &
BI=$!
wait $BS; RS=$?
wait $BI; RI=$?
log "P0: builds done scipy=$RS icde=$RI"

# F5 gate: verify what is INSTALLED, not what was asked for.
for img in scipy-bench:arcadedb dbbench:arcadedb; do
  GOT=$(docker run --rm "$img" python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
  log "P0: $img has ${GOT:-NONE}"
  if [ "$GOT" != "$PIN" ]; then log "ABORT: $img is not $PIN"; exit 1; fi
done

# ---- P1: scipy, arcadedb arms only ----------------------------------------
# results/ is gitignored in BOTH repos and holds the only copy of published raw
# data. Archive before the runner writes a line.
STAMP=$(date +%Y-%m-%d_%H%M)
if [ -d "$SCIPY/results" ]; then
  cp -a "$SCIPY/results" "$SCIPY/results_archive_${STAMP}_pre2681"
  log "P1: archived scipy results -> results_archive_${STAMP}_pre2681"
fi
# P1a: CONTROL ARM, and it runs FIRST because it is diagnostic.
#
# Keeping the comparator rows is defensible under F1-F8: a VERSION bump is not
# a resource change, and violation 2's rule ("raising a RESOURCE for one engine
# creates an obligation to re-measure every engine at that tier") is scoped to
# resources, which are untouched here.
#
# What no invariant covers is HOST DRIFT. The comparator rows were measured
# weeks ago; the ArcadeDB rows land tonight. Kernel, docker and thermal state
# could have moved under both, and FAIRNESS.md is silent on it, so it is an
# unaddressed axis rather than a satisfied one.
#
# So re-run ONE untouched comparator and check it reproduces itself. 15 runs to
# justify keeping 105, instead of 105 to replace them blindly. chroma is the
# choice because it is the vector lane's comparator, the lane whose ArcadeDB
# row moved most (dev20 -> stable).
#
# If it does NOT reproduce, the kept rows are not trustworthy and every
# comparator needs re-running. That verdict is logged, not silently absorbed.
log "P1a: START control arm (chroma, unchanged engine, must reproduce itself)"
( cd "$SCIPY" && BENCH_DATA=~/scipy-bench/data \
  timeout 7200 python3 run.py --datasets tiny,small,medium --backends chroma --reps 5 \
  > ~/q2/scipy_control_chroma.log 2>&1 )
log "P1a: DONE control rc=$?"

# The verdict is computed here rather than left for a human to remember. A
# control nobody scores is not a control.
ARCH="$SCIPY/results_archive_${STAMP}_pre2681/runs.jsonl"
python3 - "$ARCH" "$SCIPY/results/runs.jsonl" >> "$LOG" 2>&1 <<'PY'
import json, statistics, sys
old_p, new_p = sys.argv[1], sys.argv[2]
def load(p):
    try:
        return [json.loads(l) for l in open(p) if l.strip()]
    except OSError:
        return []
old, new = load(old_p), load(new_p)
if not old or not new:
    print("F9 CONTROL: INCONCLUSIVE (missing runs.jsonl; old=%d new=%d)" % (len(old), len(new)))
    raise SystemExit
key = lambda r: (r.get("dataset"), r.get("lane"), r.get("workload"))
ident = lambda r: r.get("run_id") or r.get("ts") or json.dumps(r, sort_keys=True)
seen = {ident(r) for r in old}
oldc = [r for r in old if r.get("backend") == "chroma"]
newc = [r for r in new if r.get("backend") == "chroma" and ident(r) not in seen]
if not newc:
    print("F9 CONTROL: INCONCLUSIVE (no new chroma rows found)")
    raise SystemExit
def grp(rows):
    d = {}
    for r in rows:
        v = r.get("q_p50_ms")
        if v is not None:
            d.setdefault(key(r), []).append(v)
    return d
go, gn = grp(oldc), grp(newc)
print("F9 CONTROL (chroma, engine unchanged, must reproduce itself):")
print("  %-34s %-22s %-22s %s" % ("cell", "kept", "re-run", "ratio"))
worst, bad = 1.0, []
for k in sorted(set(go) & set(gn), key=str):
    o, n = go[k], gn[k]
    mo, mn = statistics.median(o), statistics.median(n)
    ratio = mn / mo if mo else float("inf")
    flag = "" if 0.85 <= ratio <= 1.18 else "  <== OUTSIDE BAND"
    if flag:
        bad.append((k, ratio))
    worst = max(worst, ratio, 1 / ratio if ratio else 1)
    print("  %-34s %7.3f [%6.3f-%6.3f] %7.3f [%6.3f-%6.3f] %5.2fx%s"
          % (str(k), mo, min(o), max(o), mn, min(n), max(n), ratio, flag))
if bad:
    print("  VERDICT: FAIL on %d cell(s). Host drift is real; the carried-forward" % len(bad))
    print("           comparator rows are NOT usable and the tier needs a full")
    print("           re-measure. Do not publish a mixed table.")
else:
    print("  VERDICT: PASS. chroma reproduces within band, so keeping the")
    print("           untouched comparator rows beside fresh ArcadeDB rows is")
    print("           evidenced, not assumed. Quote this next to the table.")
PY

log "P1b: START scipy arcadedb-only (5 cells x 3 datasets x 5 reps = 75 runs)"
( cd "$SCIPY" && BENCH_DATA=~/scipy-bench/data \
  timeout 21600 python3 run.py --datasets tiny,small,medium --backends arcadedb --reps 5 \
  > ~/q2/scipy_2681.log 2>&1 )
log "P1b: DONE scipy rc=$?"

# P1c: the transport lane. Every other scipy lane measures an ENGINE; this one
# measures the BINDING, which is the only cost this package actually controls
# and the thing a scientific-Python audience is there for. The paper currently
# says nothing about it: zero mentions of iter_dicts, to_json_list or
# zero-copy, while the measured spread between the obvious API and the fast one
# is 15-17x at >=1k rows.
#
# cpuset 0-7 deliberately, matching run.py's CPUSET, so this table sits under
# the same F1 envelope as the rest of the scipy paper.
#
# Minutes, not hours: one 200k-row document type, no ANN build, no corpus.
log "P1c: START transport lane (binding cost: iter_dicts/to_json_list/to_columns/to_arrow)"
timeout 3600 docker run --rm --name p1c_transport --label dbbench=1 \
  --cpuset-cpus 0-7 --memory 32g --memory-swap 32g \
  -v "$SCIPY:/work" -w /work \
  -e PROBE_ROWS=200000 -e REPS=7 \
  -e PROBE_OUT=/work/results/transport_lane_2681.json \
  scipy-bench:arcadedb python3 transport_lane.py > ~/q2/transport_lane.log 2>&1
log "P1c: DONE transport rc=$?"
# Surface the headline immediately: the ratio table and the nulls verdict are
# the two things that go into the paper, so they belong in the queue log rather
# than only inside a container log nobody opens.
sed -n '/ratios vs to_columns/,$p' ~/q2/transport_lane.log 2>/dev/null | head -20 >> "$LOG"

# ---- P2..P4: icde dense ----------------------------------------------------
OUT=~/q2; HEAP=24g
run_mp() {   # run_mp <name> <backend> <image> <deadline> [extra-env...]
  local name=$1 be=$2 img=$3 dl=$4; shift 4
  local want=""
  for a in "$@"; do case "$a" in PROBE_OUT=*) want="${a#PROBE_OUT=}";; esac; done
  if [ -n "$want" ] && [ -s "$OUT/$(basename "$want")" ]; then
    log "  SKIP  $name (already have $(basename "$want"))"; return 0
  fi
  log "  START $name ($be on $img, deadline ${dl}s)"
  timeout "$dl" docker run --rm --name "$name" --label dbbench=1 \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$ICDE:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
    -e BENCH_DATA=/data -e BENCH_MP_BACKEND="$be" -e BENCH_MP_SCALE=deep10m \
    -e ARCADEDB_HEAP="$HEAP" \
    "$@" "$img" python -u dense_multipass_driver.py > "$OUT/$name.log" 2>&1
  log "  DONE  $name rc=$?"
}

# P2: the two arms F5 needs on one engine line.
# fp32 is asked for by LEAVING BENCH_DENSE_QUANT UNSET. Passing the literal
# "fp32" is what killed q3_fp32_b1..b3 last night; the lane now rejects it in
# the first second, but the correct spelling is still "do not set it".
log "P2: ArcadeDB dense arms on $PIN"
run_mp p2_fp32 arcadedb_dense_embedded dbbench:arcadedb 21600 \
  -e PROBE_OUT=/out/mp_arcade_fp32_2681.json
run_mp p2_int8 arcadedb_dense_embedded dbbench:arcadedb 21600 \
  -e BENCH_DENSE_QUANT=INT8 -e PROBE_OUT=/out/mp_arcade_int8_2681.json

# P3: two more independent fp32 builds so #124's cold pass has N>=3.
log "P3: fp32 cold reproduce, builds 2 and 3 (#124)"
for b in 2 3; do
  run_mp "p3_fp32_b$b" arcadedb_dense_embedded dbbench:arcadedb 21600 \
    -e BENCH_MP_PASSES=3 -e PROBE_OUT="/out/mp_fp32_2681_build$b.json"
done

# P4: comparators, for provenance only (their engines did not change).
log "P4: comparator re-runs for recoverable versions"
run_mp p4_qdrant  qdrant_dense     dbbench:dense 10800 -e PROBE_OUT=/out/mp_qdrant_2681.json
run_mp p4_chroma  chroma_dense     dbbench:dense 10800 -e PROBE_OUT=/out/mp_chroma_2681.json
run_mp p4_duckvss duckdb_vss_dense dbbench:dense 10800 -e PROBE_OUT=/out/mp_duckvss_2681.json

log "QUEUE2-COMPLETE"
