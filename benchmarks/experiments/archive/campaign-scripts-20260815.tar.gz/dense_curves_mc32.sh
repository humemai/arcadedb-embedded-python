#!/usr/bin/env bash
set -u
cd /home/tk/repos/arcadedb-icde/paper-icde/experiments
pgrep -x ffmpeg >/dev/null && { echo "MC32-ABORT ffmpeg"; exit 1; }
docker ps -q | grep -q . && { echo "MC32-ABORT foreign"; exit 1; }
echo "=== curves mc=32 retry heap=40g $(date -u +%FT%TZ) ==="
docker run --rm --name curve-mc32 --cpuset-cpus 0-11 --memory 32g --label icde-bench=1 -e ARCADEDB_HEAP=24g \
  -v $PWD:/work -w /work -v /home/tk/icde-data:/data:ro -e BENCH_DENSE_DATA=/data/dense \
  icde-bench:arcadedb python -u probe_dense_curves.py --mc 32 --out /work/results/dense_curves.jsonl \
  >> /tmp/dense_curves_mc32.log 2>&1 || { echo "MC32-FAIL"; tail -6 /tmp/dense_curves_mc32.log; }
echo "MC32-COMPLETE"
