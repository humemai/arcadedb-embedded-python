#!/usr/bin/env bash
# q88: the 8.84M sparse tier, re-measured with the full instrument.
#
# SPLIT OUT FROM q87 because of what it costs. Measured on this machine at
# 158.7 min/cell; 7 backends x 5 reps is roughly 92 hours, which is 60% of a
# full instrumented pass over every lane. Running it as its own job means
# q87's nine other cell families land in under two days and this one can be
# killed without taking them with it.
#
# WHY RUN IT AT ALL. T4 is the paper's centerpiece and this is its headline
# tier. Disk size is exactly the column where ArcadeDB's int8 posting-weight
# quantization should show a win it currently gets no credit for, since the
# quantization costs us recall in a column we DO print and saves us bytes in
# a column we never measured. Reporting the cost without the benefit has been
# the state of that table since it was written.
#
# Timing caveat, stated because the estimate is the weak part: 158.7 min/cell
# is the mean of only four logged cells. If the real figure is 20% higher
# this job is five days rather than four.
set -u
S=$HOME/STATUS.txt
R=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$R" || exit 1
say() { echo "[$(date -Is)] $*" >> "$S"; }

# --- wait for q87. STATUS.txt is APPEND-ONLY HISTORY, so a bare
# `grep "q87 ABORT"` matches an abort from any earlier attempt today and this
# job exits before it starts. That is exactly what happened on the first
# launch: q87 had aborted once, been fixed, and was running fine, and this
# grep killed its successor. Read the LAST q87 line and act on that.
for i in $(seq 1 2880); do
  last=$(grep -a "q87 " "$S" 2>/dev/null | tail -1)
  case "$last" in
    *"q87 ALL-DONE"*) break ;;
    *"q87 ABORT"*)    say "q88 not starting: q87 aborted ($last)"; exit 1 ;;
  esac
  sleep 60
done
case "$(grep -a "q87 " "$S" 2>/dev/null | tail -1)" in
  *"q87 ALL-DONE"*) ;;
  *) say "q88 gave up waiting for q87"; exit 1 ;;
esac

if [ -n "$(docker ps -q --filter label=dbbench=1)" ]; then
  say "q88 ABORT: dbbench containers still running"; exit 1
fi

say "q88 l3s medium N=5 START (8.84M sparse, est ~92h)"
python3 -u runner.py --lanes l3s --scale medium --reps 5 >> ~/q88.log 2>&1
say "q88 l3s medium rc=$?"
say "q88 ALL-DONE"
echo "currently: finished" >> "$S"
