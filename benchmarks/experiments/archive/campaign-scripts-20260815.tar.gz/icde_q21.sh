#!/bin/bash
# q21: TPC-H SF10 (OLAP only, N=5) then the time-series re-measure on the release.
#
# WHY THIS REPLACES q19. q19 ran l1tpc tpch10 across BOTH workloads at N=5, i.e.
# 40 cells. The first cell took 1h43m, because every rep rebuilds the 60M-row
# lineitem table through the per-row SQL path at ~29k rows/s. That is roughly
# 68 hours against the 12-hour timeout it was given: it would have been killed
# around cell 7, leaving several cells at N=1, which is not a tier.
#
# HALF OF IT WAS UNPUBLISHED ANYWAY. make_paper_tables.tabular_table() takes
# only q1_ms and q6_ms from the l1tpc lane; OLTP and ingest come from lane l1.
# So the entire oltp workload at this scale produces nothing the paper prints.
# Dropping it halves the run and costs the paper nothing. N stays at 5.
#
# Estimated ~16h: the ArcadeDB arms dominate (~1.7h/rep each), DuckDB and
# PostgreSQL are minutes. The timeout is 24h so a slow arm cannot truncate the
# tier the way q19 would have.
#
# THEN THE TS RE-MEASURE, in the same script rather than chained on a marker.
# q20 waited for a "Q19-COMPLETE" line; killing q19 meant that line would never
# appear and q20 would have sat until its deadline. One sequential script has
# no such race, and no window where a docker-idle guard can fire between cells.
set -u
OUT=$HOME/q21
mkdir -p "$OUT"
LOG=$OUT/queue.log
EXP=$HOME/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
IMG=dbbench:arcadedb

log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
die() { log "ABORT: $*"; exit 1; }

log "q21 started, pid $$"
cd "$EXP" || die "no experiments dir"

# ---- gates -----------------------------------------------------------------
# The runner must be the one that HONOURS --workloads. Until today the flag was
# parsed, passed down and then ignored, because build_jobs iterated the lane's
# own workload list instead. A stale runner here would silently run oltp too
# and put us straight back on the 68-hour path, having been told not to.
grep -q "if want and wl not in want" runner.py \
  || die "runner.py does not honour --workloads; deploy the fixed one first"
log "gate: runner.py honours --workloads"

grep -q "def lineitem_batches" l1_tpc.py \
  || die "l1_tpc.py is not the streaming loader; SF10 will OOM"
log "gate: streaming loader present"

for f in sf10_lineitem.parquet sf10_part.parquet; do
  [ -s "$HOME/bench-data/tpch/$f" ] || die "missing corpus $f"
done
log "gate: sf10 corpus present"

VER=$(docker run --rm "$IMG" python -m pip show arcadedb-embedded 2>/dev/null \
      | awk '/^Version:/{print $2}')
case "${VER:-}" in
  "")     die "could not read engine version from $IMG" ;;
  *.dev*) die "F5: $IMG is $VER, a pre-release; the paper names one release" ;;
esac
log "gate: $IMG is $VER"

while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 20; done
log "host idle"

# ---- TPC-H SF10, OLAP only, N=5 --------------------------------------------
log "START l1tpc tpch10 olap N=5 (4 backends, 20 cells)"
t0=$(date +%s)
BENCH_DATA=$HOME/bench-data/tpch \
BENCH_TPC_SF=10 \
BENCH_TPC_BATCH_ROWS=2000000 \
timeout 86400 python3 -u runner.py --lanes l1tpc --scale tpch10 \
    --workloads olap --reps 5 --tier paper \
    > "$OUT/l1tpc_tpch10_olap.log" 2>&1
rc=$?
log "l1tpc tpch10 olap rc=$rc after $(( ($(date +%s)-t0)/60 )) min"
[ $rc -ne 0 ] && tail -25 "$OUT/l1tpc_tpch10_olap.log" >> "$LOG"

# ---- TS on the release ------------------------------------------------------
LP=$HOME/bench-data/tsbs/cpu_influx.lp
RES=$EXP/results/ts_2681
if [ -s "$LP" ]; then
  mkdir -p "$RES"
  log "START native TS probe on $VER, N=5 nosettle"
  for rep in 1 2 3 4 5; do
    while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 20; done
    timeout 3600 docker run --rm --name ts2681_nosettle_r${rep} \
      --cpuset-cpus 0-11 --memory 20g --memory-swap 20g \
      -v "$EXP:/work" -w /work -v "$HOME/bench-data:/data:ro" \
      -e TSBS_LP=/data/tsbs/cpu_influx.lp \
      -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=1 \
      -e TS_SETTLE_S=0 -e TS_LAST_AB=1 \
      -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
      -e PROBE_OUT="/work/results/ts_2681/nosettle_r${rep}.json" \
      "$IMG" python -u l4_native_probe.py >"$OUT/ts_rep${rep}.log" 2>&1 \
      && log "  ts rep$rep ok" || log "  ts rep$rep FAILED"
  done
else
  log "TS SKIPPED: no corpus at $LP"
fi

# ---- acceptance -------------------------------------------------------------
# rc=0 is not the test. SF10 is only real if the fact table actually loaded, and
# the TS row is only usable if it is on the release. Check the artifacts.
log "=== acceptance ==="
python3 - >>"$LOG" 2>&1 <<'PY'
import json, glob, os, statistics as st, collections
EXP = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments")
rows = []
for l in open(os.path.join(EXP, "results", "runs.jsonl")):
    try: r = json.loads(l)
    except Exception: continue
    if r.get("scale") == "tpch10" and r.get("ts_utc", "") >= "2026-08-05T23":
        rows.append(r)
print("  tpch10 rows this run: %d" % len(rows))
if not rows:
    print("  NO ROWS. The SF10 tier is still unmeasured; report nothing.")
else:
    c = collections.Counter((r["backend"], r["workload"]) for r in rows)
    for k in sorted(c, key=str):
        g = [r for r in rows if (r["backend"], r["workload"]) == k]
        ok = [r for r in g if r.get("rc") == 0]
        q1 = [r["q1_ms"] for r in ok if isinstance(r.get("q1_ms"), (int, float))]
        print("    %-20s %-5s %d reps, %d ok%s" % (
            k[0], k[1], len(g), len(ok),
            ("  q1 median %.0f ms" % st.median(q1)) if q1 else ""))
    nl = {r.get("n_lineitem") for r in rows if r.get("n_lineitem")}
    print("  n_lineitem seen: %s  (SF10 must be 59986052)" % sorted(nl))
    if nl and nl != {59986052}:
        print("  REJECT: the fact table did not fully load. Do not report this tier.")
    if any(r.get("workload") == "oltp" for r in rows):
        print("  WARNING: oltp cells present; --workloads was not honoured.")
ts = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(EXP, "results", "ts_2681", "nosettle_r*.json")))]
print("  ts_2681 reps: %d" % len(ts))
if ts:
    v = sorted({str(r.get("engine_version")) for r in ts})
    print("  ts versions: %s" % v)
    if any(".dev" in x for x in v):
        print("  REJECT: TS still pre-release; do not fold into T5.")
    else:
        for f in ("ingest_pts_per_s", "q_last_unbounded_ms", "q_range_ms", "q_global_ms"):
            g = [r[f] for r in ts if isinstance(r.get(f), (int, float))]
            if g:
                print("    %-22s median=%.6g [%.6g -- %.6g]" % (f, st.median(g), min(g), max(g)))
PY

log "Q21-COMPLETE"
