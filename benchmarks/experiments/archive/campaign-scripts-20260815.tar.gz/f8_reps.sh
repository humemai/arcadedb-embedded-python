#!/bin/bash
# F8 with reps. One pass told us nothing separable from noise: 0.84x and 1.14x
# could both be jitter. Three passes give a spread, which is the difference
# between "no engine parallelises a query" and "we measured it once".
set -u
cd ~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments || exit 1
OUT=~/f8; mkdir -p $OUT
BACKENDS="arcadedb_dense_embedded:arcadedb chroma_dense:dense lancedb_dense:dense sqlite_vec_dense:dense duckdb_vss_dense:dense"
for rep in 1 2 3; do
  for cpus in 0 0-11; do
    tag=$(echo "$cpus" | tr -d -)
    for entry in $BACKENDS; do
      be="${entry%%:*}"; img="dbbench:${entry##*:}"
      echo "[$(date -Is)] rep$rep $be cpuset=$cpus"
      timeout 1800 docker run --rm --name "f8r_${be}_${tag}" --label dbbench=1 \
        --cpuset-cpus "$cpus" --memory 24g --memory-swap 24g \
        -v "$PWD:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
        -e BENCH_DATA=/data \
        "$img" python -u l3d_dense.py --backend "$be" --scale tiny \
          --out "/out/r${rep}_${be}_${tag}.json" > "$OUT/r${rep}_${be}_${tag}.log" 2>&1
    done
  done
done
echo "[$(date -Is)] F8-REPS-COMPLETE"
