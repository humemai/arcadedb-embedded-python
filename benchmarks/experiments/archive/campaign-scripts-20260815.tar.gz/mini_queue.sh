#!/bin/bash
# Overnight queue. Strictly serial: every job is timing-sensitive (F2), so
# nothing shares the host with anything else.
#
#   q1  arcade_int8 multipass. The matched dense table's one missing arm.
#   q2  lancedb multipass at the FAIR operating point. Its existing row is at
#       recall 0.7374 while every other arm is 0.95+, measured before
#       f346840045 landed .ef(100)/.nprobes(10).
#   q3  fp32 first-pass reproduce, THREE independent builds. #124 rests on a
#       single sample (4.424 -> 8.172 between dev20 and dev23) and one sample
#       cannot distinguish a regression from jitter. Today's F8 probe made
#       exactly this mistake and three reps fixed it.
#
# F5 GATE: the matched table's fp32 arm was measured on 26.8.1.dev23. An arm
# measured on anything else compares versions while appearing to compare
# quantization, which is the defect that made T5's server build cell wrong. The
# gate aborts rather than silently producing an unusable row -- and dev27 is
# about to hit PyPI, so this is a live hazard, not a hypothetical one.
set -u
cd ~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments || exit 1
OUT=~/q_dense; mkdir -p "$OUT"
log() { echo "[$(date -Is)] $*"; }
HEAP=24g   # runner.py HEAP_BY_SCALE["deep10m"], and what mp_arcade_fp32 recorded
log "queue started, pid $$ (heap=$HEAP, cap=36g)"      # proof of life: an empty log means dead, not busy

EXPECT=26.8.1.dev23
GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null \
        | awk '/^Version:/{print $2}')
log "F5 gate: image has $GOT, matched table needs $EXPECT"
if [ "$GOT" != "$EXPECT" ]; then
  log "GATE FAILED: refusing to run ArcadeDB arms against $GOT"
  ARCADE_OK=0
else
  ARCADE_OK=1
fi

run_mp() {   # run_mp <name> <backend> <image> <deadline> [extra-env...]
  local name=$1 be=$2 img=$3 dl=$4; shift 4
  # Resumable: a completed arm is not re-run, so a relaunch after fixing one
  # stage does not discard the stages that already succeeded.
  local want
  for a in "$@"; do case "$a" in PROBE_OUT=*) want="${a#PROBE_OUT=}";; esac; done
  if [ -n "${want:-}" ] && [ -s "$OUT/$(basename "$want")" ]; then
    log "  SKIP  $name (already have $(basename "$want"))"; return 0
  fi
  log "  START $name ($be on $img, deadline ${dl}s)"
  timeout "$dl" docker run --rm --name "$name" --label dbbench=1 \
    --cpuset-cpus 0-11 --memory 36g --memory-swap 36g \
    -v "$PWD:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
    -e BENCH_DATA=/data -e BENCH_MP_BACKEND="$be" -e BENCH_MP_SCALE=deep10m \
    -e ARCADEDB_HEAP="$HEAP" \
    "$@" "$img" python -u dense_multipass_driver.py > "$OUT/$name.log" 2>&1
  log "  DONE  $name rc=$?"
}

# ---- q1: the missing int8 arm ---------------------------------------------
if [ "$ARCADE_OK" = 1 ]; then
  run_mp q1_int8 arcadedb_dense_embedded dbbench:arcadedb 21600 \
    -e BENCH_DENSE_QUANT=INT8 -e PROBE_OUT=/out/mp_arcade_int8.json
else
  log "  SKIP q1 (F5 gate)"
fi

# ---- q2: LanceDB at the fair operating point ------------------------------
run_mp q2_lance lancedb_dense dbbench:dense 10800 \
  -e PROBE_OUT=/out/mp_lancedb_fair.json

# ---- q3: three independent fp32 builds for #124 ---------------------------
if [ "$ARCADE_OK" = 1 ]; then
  for b in 1 2 3; do
    run_mp "q3_fp32_b$b" arcadedb_dense_embedded dbbench:arcadedb 21600 \
      -e BENCH_DENSE_QUANT=fp32 -e BENCH_MP_PASSES=3 \
      -e PROBE_OUT="/out/mp_fp32_build$b.json"
  done
else
  log "  SKIP q3 (F5 gate)"
fi

log "QUEUE-COMPLETE"
