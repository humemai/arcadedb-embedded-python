#!/bin/bash
# F8: does the 12-CPU envelope advantage some engines at QUERY time?
#
# Every lane pins the same cpuset, which equalises the RESOURCE but not the
# USE of it. An engine that parallelises a single query across 12 threads and
# one that answers on a single thread are both "given 12 CPUs" and are not
# being compared on equal terms. Nothing in FAIRNESS.md checks this, so it has
# never been measured.
#
# Same cell, same data, same queries, twice: pinned to CPU 0 alone, and to
# CPUs 0-11. p50(1cpu)/p50(12cpu) is the per-query parallel speedup. ~1.0 means
# single-threaded per query; well above 1 means the engine is spending the
# whole envelope on one query.
set -u
cd ~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments || exit 1
OUT=~/f8; mkdir -p $OUT
D=/usr/local/lib/python3.12/site-packages/arcadedb_embedded
# backend:image — ArcadeDB ships in its own image, the comparators share dbbench:dense
BACKENDS="arcadedb_dense_embedded:arcadedb chroma_dense:dense lancedb_dense:dense sqlite_vec_dense:dense duckdb_vss_dense:dense"
log() { echo "[$(date -Is)] $*"; }
log "F8 start: query-time parallelism, tiny tier"
for cpus in 0 0-11; do
  tag=$(echo "$cpus" | tr -d '-')
  for entry in $BACKENDS; do
    be="${entry%%:*}"; img="dbbench:${entry##*:}"
    log "  $be ($img) cpuset=$cpus"
    timeout 3600 docker run --rm --name "f8_${be}_${tag}" --label dbbench=1 \
      --cpuset-cpus "$cpus" --memory 24g --memory-swap 24g \
      -v "$PWD:/work" -w /work -v "$HOME/bench-data:/data:ro" -v "$OUT:/out" \
      -e BENCH_DATA=/data \
      "$img" python -u l3d_dense.py --backend "$be" --scale tiny \
        --out "/out/f8_${be}_${tag}.json" > "$OUT/${be}_${tag}.log" 2>&1
    log "    rc=$? -> $OUT/${be}_${tag}.log"
  done
done
log "F8-COMPLETE"
