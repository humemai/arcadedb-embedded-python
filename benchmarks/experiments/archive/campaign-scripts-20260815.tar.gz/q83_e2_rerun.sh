#!/usr/bin/env bash
# E2 re-run on the FIXED harness (task #147).
#
# The previous E2 data is void, in three separate ways:
#   - torn_state was decided by isinstance(state, dict), i.e. by WHICH BACKEND
#     was running, never by a comparison
#   - SurrealDB's writes never landed (record ids were built as
#     product:product:i, so every UPDATE addressed a record that did not exist)
#   - the composed stack's evidence compared a SUM of counters against a COUNT
#     of flagged points, two quantities that diverge with no crash at all
#
# This run uses e2_hybrid.py at b0aad16d57 or later, which computes the verdict,
# aborts an arm whose clean ops moved nothing, and does 40 trials per rep
# instead of 1.
set -u
cd /home/tk/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
S=~/STATUS.txt
HARNESS=$(git -C .. rev-parse --short HEAD)
echo "[$(date -Is)] q83 E2 re-run START harness=${HARNESS}" >> "$S"
rc_total=0
for wl in atomicity hybrid; do
  echo "[$(date -Is)] STAGE e2_${wl} start" >> "$S"
  python3 -u runner.py --lanes e2 --scale e2 --reps 5 --workloads "$wl" >> ~/q83.log 2>&1
  rc=$?
  echo "[$(date -Is)] STAGE e2_${wl} rc=${rc}" >> "$S"
  [ "$rc" -ne 0 ] && rc_total=$rc
done
echo "[$(date -Is)] STAGE ALL-DONE rc=${rc_total}" >> "$S"
echo "currently: finished" >> "$S"
