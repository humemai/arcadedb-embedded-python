#!/bin/bash
# Chain q7 (milvus + sqlite-vec) behind q6 (arcadedb server). Hard deadline plus
# a died-without-a-marker check, so a dead upstream ends this instead of parking.
set -u
LOG=/home/tk/q7/chain.log
mkdir -p /home/tk/q7
say() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
say "chain armed, waiting on q6 (deadline 5h)"
DEADLINE=$(( $(date +%s) + 18000 ))
while :; do
  grep -q "ARCSRV-COMPLETE" /home/tk/q6/queue.log 2>/dev/null && { say "q6 complete, starting q7"; break; }
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then say "DEADLINE: q6 never completed in 5h."; exit 1; fi
  if ! pgrep -f "bash /home/tk/icde_srv.sh" >/dev/null 2>&1; then
    say "q6 process gone with no completion marker."
    tail -5 /home/tk/q6/queue.log 2>/dev/null | tee -a "$LOG"; exit 1
  fi
  sleep 120
done
exec /home/tk/icde_dense_last2.sh
