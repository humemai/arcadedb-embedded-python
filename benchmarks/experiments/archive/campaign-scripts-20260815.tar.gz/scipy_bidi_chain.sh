#!/usr/bin/env bash
set -u
pgrep -x ffmpeg >/dev/null && { echo "BIDI-ABORT ffmpeg"; exit 1; }
L=$(awk "{print int(\$1)}" /proc/loadavg); [ "$L" -gt 3 ] && { echo "BIDI-ABORT load=$L"; exit 1; }
cd /home/tk/repos/scipy-bench-repo
git fetch -q origin arcadedb-2026 && git checkout -q origin/arcadedb-2026 -- experiments/ || { echo "BIDI-ABORT pull"; exit 1; }
cp -a experiments/results ~/scipy-results-predbidi-$(date +%Y%m%d%H%M) && echo archived
cd experiments
echo "=== BIDI: graph lane re-run ==="
BENCH_DATA=/home/tk/scipy-bench/data python3 -u run.py --datasets tiny,small,medium --lanes graph --reps 5 > results/graph_bidi.log 2>&1
echo "graph rc=$?"
echo "=== BIDI: showcase full corpus ==="
docker run --rm --cpuset-cpus 0-7 --memory 8g \
  -v /home/tk/repos/scipy-bench-repo/experiments:/work -w /work \
  -v /home/tk/scipy-bench/data:/data:ro scipy-bench:arcadedb \
  python -u hybrid_showcase.py --data-dir /data/stackoverflow-medium/prepared \
  --vectors-dir /data/stackoverflow-medium/vectors --name stackoverflow-medium --limit 250000 \
  > results/hybrid_dev2_bidi.log 2>&1
echo "showcase rc=$?"
echo "SCIPY-BIDI-COMPLETE"
