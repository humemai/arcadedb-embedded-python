#!/bin/bash
# T5's native time-series row carries three caveats. One run retires all three.
#
# 1. N=3. The caption asserts N=5 for the table; this row is three files. The
#    new caption_n() audit in provenance_check.py now catches that class, but
#    disclosing N=3 is worse than measuring N=5 when the lane costs minutes.
#
# 2. NO CONDITIONS. Its result files record no cpuset, heap or memory cap, so
#    the row cannot be reproduced or extended from its own artifacts. That is
#    exactly why T4's 8.84M cell is permanently stuck at N=3: reps measured
#    under guessed conditions would be worse than an honest N=3. The probe now
#    calls run_conditions(), which READS the container cgroup rather than
#    being told.
#
# 3. FOOTNOTE b. The row's last-point query uses a one-hour recency window
#    because the unbounded form scanned the tag's whole series (208 ms). The
#    caption promises to retire the window since #5414/#5416 landed. Assuming
#    an upstream fix reached this path is how we published a server build cell
#    that was really a stale image, so measure it: TS_LAST_AB=1 runs both
#    forms in the SAME rep, differing only in the WHERE clause.
#
# Schema fidelity: TS_TAGS=1 deliberately. The published row is the one-tag
# arm (the paper says so, and the ten-tag A/B is reported separately). Running
# ten tags here would silently re-measure a different experiment.
set -u
exec >> "$HOME/profiling/queue58.log" 2>&1
say() { echo "[$(date -u +%H:%M:%S)] $*"; }
die() { say "ABORT: $*"; exit 1; }
guard() { while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 30; done; }

guard
cd ~/repos/humemai/arcadedb-icde/paper-icde/experiments || die "no experiments dir"
OUT=results/ts58
mkdir -p "$OUT"

VER=$(docker run --rm icde-bench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
[ -n "${VER:-}" ] || die "no engine version"
say "engine $VER"

# Contract check before the reps, not after. queue39 lost 10/10 cells to a
# flag that did not exist, and q51 lost 5/5 to a grep that never matched.
docker run --rm -v "$PWD:/work" -w /work icde-bench:arcadedb python -c "
import l4_native_probe as p
assert hasattr(p.ArcadeTSNative, 'q_last_unbounded'), 'unbounded arm missing'
assert p.LAST_AB is False, 'LAST_AB should default off'
from bench_common import run_conditions
c = run_conditions(lane='l4n')
assert 'cpuset' in c and 'engine_version' in c, c
print('contract ok: unbounded arm present, run_conditions reads', sorted(c))
" || die "probe contract changed"

[ -f "$HOME/icde-data/tsbs/cpu_influx.lp" ] || die "TSBS lp file missing"

run_rep() {  # $1 rep
  local rep=$1
  guard
  timeout 3600 docker run --rm --name ts58_r${rep} \
    --cpuset-cpus 0-11 --memory 20g --memory-swap 20g \
    -v "$PWD:/work" -w /work -v "$HOME/icde-data:/data:ro" \
    -e TSBS_LP=/data/tsbs/cpu_influx.lp \
    -e TS_PRIMITIVE=1 -e TS_NUMPY=1 -e TS_SHARDS=4 -e TS_TAGS=1 \
    -e TS_SETTLE_S=30 -e TS_LAST_AB=1 \
    -e ARCADEDB_HEAP=8g -e BENCH_ROLE=engine \
    -e PROBE_OUT="/work/$OUT/ts58_r${rep}.json" \
    icde-bench:arcadedb python -u l4_native_probe.py >/dev/null 2>&1 \
    && say "rep$rep ok" || say "rep$rep FAILED"
}

for rep in 1 2 3 4 5; do run_rep "$rep"; done

say "=== result ==="
python3 - <<'PY'
import glob, json, statistics as st
rows = []
for fp in sorted(glob.glob("results/ts58/ts58_r*.json")):
    try:
        rows.append(json.load(open(fp)))
    except Exception:
        pass
if not rows:
    raise SystemExit("  no reps written")

def med(k):
    v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
    return st.median(v) if v else None

print(f"  n={len(rows)}  engine={rows[0].get('engine_version')}")
print(f"  conditions: cpuset={rows[0].get('cpuset')} heap={rows[0].get('heap')} "
      f"mem_cap={rows[0].get('mem_cap')} role={rows[0].get('role')}")
print(f"  ingest   {med('ingest_pts_per_s'):>12,.0f} pts/s")
for k, was in (("q_last_ms", 4.16), ("q_range_ms", 7.33), ("q_global_ms", 29.56)):
    m = med(k)
    print(f"  {k:14} {m:8.2f} ms   (T5 prints {was} from the dev21 N=3 row)")

w, u = med("q_last_ms"), med("q_last_unbounded_ms")
if w and u:
    print(f"\n  last-point, paired in-rep A/B:")
    print(f"    windowed (1h)  {w:8.2f} ms   <- what T5 reports today")
    print(f"    unbounded      {u:8.2f} ms   <- what footnote b wants to use")
    print(f"    ratio {u/w:.2f}x")
    if u / w <= 1.25:
        print("    -> the window buys nothing measurable. #5414/#5416 reached")
        print("       this path; retire the workaround and report unbounded.")
    elif u > 100:
        print("    -> still scanning the series (was 208 ms). The fix did NOT")
        print("       reach this path; keep the window and say so, and take")
        print("       the repro upstream.")
    else:
        print(f"    -> partial: {u/w:.2f}x. Neither retire nor ignore; report")
        print("       both and state the operating point.")
PY
say "QUEUE58-DONE"
