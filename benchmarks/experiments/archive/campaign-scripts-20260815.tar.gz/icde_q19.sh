#!/bin/bash
# q19: TPC-H SF10, the tier that has never been measured.
#
# WHY IT FAILED BEFORE: l1_tpc.py did pq.read_table(...).to_pandas() on the
# whole fact table. 6,001,215 rows at SF1 is fine; ~60M at SF10 was OOM-killed
# in every one of thirty cells, at ~8 GiB anon RSS beside a pinned 16g heap in
# a 32g cap. The harness then reported success, which is fixed separately
# (74a71c4e0f).
#
# THE LOADER NOW STREAMS row groups. Validated at SF1 against the prior
# whole-table numbers before being trusted here:
#   arcadedb oltp  2364.6 vs prior 2171.9 2429.1 2310.1 2084.3   inside spread
#   duckdb   oltp   106.7 vs prior  101.6  104.6  104.5  101.4   inside spread
#   n_lineitem     6,001,215 exact on both
#   arcadedb build 243.28 vs prior 244.34 241.73 242.38          no-op
#
# ONE DISCLOSED CHANGE: DuckDB's build went 2.4s -> ~9.5s, because one bulk
# CREATE TABLE AS became a create plus per-row-group INSERT. It is NOT a
# published number: T2 takes only q1_ms/q6_ms from this lane, ingest and OLTP
# come from l1, and claims_check has no l1tpc entry at all. If l1tpc build ever
# becomes a claim, DuckDB needs its native read_parquet path first.
set -u
OUT=~/q19
mkdir -p "$OUT"
LOG=$OUT/queue.log
log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
log "q19 started, pid $$"
ICDE=~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
cd "$ICDE" || { log "ABORT: no $ICDE"; exit 1; }

for _ in $(seq 1 60); do docker ps -q | grep -q . || break; sleep 30; done

export BENCH_DATA=$HOME/bench-data
export BENCH_TPC_DATA=/data/tpch
export BENCH_TPC_SF=10
ls "$BENCH_DATA"/tpch/sf10_*.parquet >/dev/null 2>&1 || { log "ABORT: no sf10 parquet"; exit 1; }
grep -q "lineitem_batches" l1_tpc.py || { log "ABORT: loader is not the streaming one"; exit 1; }
GOT=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
log "F5 gate: dbbench:arcadedb has ${GOT:-NONE}"
[ "$GOT" = "26.8.1" ] || { log "ABORT: image is not 26.8.1"; exit 1; }

t0=$(date +%s)
log "START l1tpc tpch10, N=5, all four backends"
timeout 43200 python3 runner.py --lanes l1tpc --scale tpch10 \
    --backends "arcadedb_embedded,arcadedb_server,duckdb" \
    --reps 5 --tier paper --workers 0 > "$OUT/l1tpc_tpch10.log" 2>&1
rc=$?; el=$(( $(date +%s) - t0 ))
[ $rc -eq 0 ] && log "DONE  tpch10 rc=$rc ${el}s" || { log "FAIL  tpch10 rc=$rc ${el}s"; tail -20 "$OUT/l1tpc_tpch10.log" >> "$LOG"; }

python3 - >> "$LOG" 2>&1 <<'PY'
import json, glob, os, collections, statistics as st
R = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments/results/raw")
g = collections.defaultdict(list)
for p in glob.glob(os.path.join(R, "l1tpc_*_tpch10_r*.json")):
    try: j = json.load(open(p))
    except Exception: continue
    g[(j.get("backend"), j.get("workload"))].append(j)
print("\nq19: TPC-H SF10 (~60M lineitem rows)")
if not g:
    print("  NO ROWS. The tier is still unmeasured; do not report anything.")
print("  %-22s %-5s %2s %12s %10s %10s" % ("backend","wl","N","n_lineitem","q1_ms","q6_ms"))
for k in sorted(g, key=lambda x: str(x)):
    rs = g[k]
    def med(f):
        v=[r[f] for r in rs if isinstance(r.get(f),(int,float))]
        return st.median(v) if v else float("nan")
    print("  %-22s %-5s %2d %12s %10.1f %10.1f" % (
        k[0], k[1], len(rs), rs[0].get("n_lineitem"), med("q1_ms"), med("q6_ms")))
print("\n  SF1 for comparison: lineitem 6,001,215. SF10 should be ~59,986,052.")
PY
log "Q19-COMPLETE"
