#!/bin/bash
# Re-measure Elasticsearch with index-time pruning OFF, so T4 stops printing a
# recall that is an artefact of a default tuned for a different model.
#
# WHAT WE FOUND. ES 9.1 turned token pruning on by default for every new
# sparse_vector field, with thresholds Elastic states were chosen from tests on
# ELSERv2. Our corpus is SPLADE-cocondenser. Our own history measures the cost,
# same harness and same corpus throughout:
#
#     ES 9.0.0 (predates the default)   recall@10  0.991 - 0.9985
#     ES 9.4.1 (pruning on)             recall@10  0.725 - 0.929
#
# Qdrant and Milvus retrieve exactly and score ~0.99 on the same queries. So
# the pruned rows compare an approximate Elasticsearch against exact
# competitors, and would print 0.75 next to their 0.99 -- which reads as
# "Elasticsearch is bad at sparse retrieval" and is not what it means.
#
# THE ACCEPTANCE IS THE POINT. The whole reason for this run is that a number
# looked wrong, so it is not enough to produce a new number and trust it. Each
# tier is compared against the EXACT competitors measured in the same campaign
# at the same tier. If Elasticsearch does not come back into their band, the
# pruning default was not the whole story, and the run says so instead of
# quietly handing over another figure nobody checked.
set -u
EXP=$HOME/repos/humemai/arcadedb-embedded-python/benchmarks/experiments
OUT=$HOME/qfix6; mkdir -p "$OUT"
LOG=$OUT/queue.log
ST=$HOME/STATUS.txt

log() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }
die() { log "ABORT: $*"; exit 1; }

log "qfix6 started, pid $$"

# ---- wait for qfix4 --------------------------------------------------------
DEADLINE=$(( $(date +%s) + 24*3600 ))
while ! grep -q "QFIX4-COMPLETE" "$HOME/qfix4/queue.log" 2>/dev/null; do
  [ "$(date +%s)" -ge "$DEADLINE" ] && die "qfix4 never completed in 24h"
  sleep 60
done
log "qfix4 complete"
while [ "$(docker ps -q | wc -l)" -gt 0 ]; do
  [ "$(date +%s)" -ge "$DEADLINE" ] && die "containers still running at deadline"
  sleep 20
done
log "host idle"

# ---- swap in the adapter, only now -----------------------------------------
# NOT copied from the laptop earlier on purpose: qfix4's es_medium stage starts
# a fresh container per rep, and a mid-stage swap would have given that stage
# pruned and unpruned reps under one name. The file waits here until its own
# stage is over.
[ -s "$HOME/l3_sparse.py.pending" ] || die "no staged adapter at ~/l3_sparse.py.pending"
cp "$EXP/l3_sparse.py" "$OUT/l3_sparse.py.before"
cp "$HOME/l3_sparse.py.pending" "$EXP/l3_sparse.py"
grep -q 'index_options' "$EXP/l3_sparse.py" || die "swapped adapter has no index_options"
log "adapter swapped in (previous copy kept at $OUT/l3_sparse.py.before)"

VER=$(docker run --rm dbbench:arcadedb python -m pip show arcadedb-embedded 2>/dev/null | awk '/^Version:/{print $2}')
case "${VER:-}" in "") die "no engine version";; *.dev*) die "F5: $VER is a pre-release";; esac
log "gate: engine $VER"

export BENCH_DATA=$HOME/bench-data
export BENCH_SPARSE_SOURCE=bigann
export BENCH_SPARSE_DATA=/data/bigann
[ -d "$BENCH_DATA/bigann" ] || die "no bigann corpus"
log "gate: bigann corpus present"
date -Is > "$OUT/started_at"

cd "$EXP" || die "no experiments dir"

stage() {  # scale, timeout
  local scale=$1 tmo=$2
  while [ "$(docker ps -q | wc -l)" -gt 0 ]; do sleep 20; done
  log "STAGE es_${scale} START"
  local t0=$(date +%s)
  timeout "$tmo" python3 -u runner.py --lanes l3s --scale "$scale" --tier paper \
    --backends elasticsearch_sparse --reps 5 >"$OUT/es_$scale.log" 2>&1
  local rc=$?
  log "STAGE es_${scale} $( [ $rc -eq 0 ] && echo OK || echo "FAILED rc=$rc" ) after $(( ($(date +%s)-t0)/60 ))min"
  [ $rc -ne 0 ] && tail -12 "$OUT/es_$scale.log" >>"$LOG"
  docker ps --format '{{.Names}}' | grep -E '^(cli|srv)-' | while read n; do docker rm -f "$n" >/dev/null 2>&1; done
}

stage tiny   7200
stage small  21600
stage medium 86400

log "=== acceptance: does Elasticsearch rejoin the exact engines? ==="
python3 - <<'PY' | tee -a "$LOG"
import json, os, statistics as st, collections
EXP = os.path.expanduser("~/repos/humemai/arcadedb-embedded-python/benchmarks/experiments")
cut = open(os.path.expanduser("~/qfix6/started_at")).read().strip()
rows = []
for l in open(os.path.join(EXP, "results", "runs.jsonl")):
    l = l.strip()
    if not l: continue
    try: r = json.loads(l)
    except Exception: continue
    if r.get("lane") == "l3s" and r.get("rc") == 0 and r.get("recall_at_10") is not None:
        rows.append(r)

EXACT = ("qdrant_sparse", "milvus_sparse")   # exact sparse retrieval, the bar
bad = False
print("  %-8s %-24s %-22s %s" % ("scale", "Elasticsearch (unpruned)", "exact engines", "verdict"))
for sc in ("tiny", "small", "medium"):
    es = [r for r in rows if r.get("backend") == "elasticsearch_sparse"
          and r.get("scale") == sc and str(r.get("ts_utc", "")) >= cut]
    ex = [r for r in rows if r.get("backend") in EXACT and r.get("scale") == sc]
    if not es:
        print("  %-8s NO ROWS" % sc); bad = True; continue
    if not ex:
        print("  %-8s %-24s (no exact engine to compare)" % (sc, "%.4f" % st.median([r["recall_at_10"] for r in es])))
        continue
    me = st.median([r["recall_at_10"] for r in es])
    mx = st.median([r["recall_at_10"] for r in ex])
    pruned = sorted({str(r.get("es_prune")) for r in es})
    gap = mx - me
    ok = gap <= 0.03 and len(es) >= 5
    if not ok: bad = True
    print("  %-8s %-24s %-22s %s"
          % (sc, "%.4f (n=%d, prune=%s)" % (me, len(es), ",".join(pruned)),
             "%.4f (n=%d)" % (mx, len(ex)),
             "in band" if ok else "STILL %.1f pts BELOW" % (gap * 100)))

print()
if bad:
    print("  NOT RESOLVED. Pruning was not the whole story, or a tier is short.")
    print("  Do NOT publish these recall figures for Elasticsearch until the")
    print("  remaining gap is explained -- an unexplained 0.7x for a mature")
    print("  search engine is far more likely to be our harness than its engine.")
else:
    print("  RESOLVED. Elasticsearch is back within 3 points of the exact")
    print("  engines at every tier, which is where ES 9.0.0 sat before the 9.1")
    print("  pruning default. T4 can print these beside Qdrant and Milvus, with")
    print("  the override disclosed.")
PY

log "QFIX6-COMPLETE"
{ echo "qfix6 (Elasticsearch pruning override) finished $(date -Is)"; echo; tail -25 "$LOG"; } > "$ST"
